; (function ($) {
    var lax_scroll_effect = function ($scope, $) {        
        $($scope).each(function(){
          window.onload = function() {
              lax.setup({
                  breakpoints: { small: 768, large: 1025 }
              }) // init
              const updateLax = () => {
                  lax.update(window.scrollY)
                  window.requestAnimationFrame(updateLax)
              }
              window.requestAnimationFrame(updateLax)
          }
        })
    }
    // Run this code under Elementor.
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-portfolio-addons.default', lax_scroll_effect);
        elementorFrontend.hooks.addAction('frontend/element_ready/image.default', lax_scroll_effect);
    });
}(jQuery));