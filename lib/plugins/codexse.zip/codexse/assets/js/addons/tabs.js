(function($) {
    $(window).on('elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-tabs-addons.default', function($scope) {
            var tabsContainer = $scope.find('.codexse-tabs-container');

            if (tabsContainer.length > 0) {
                tabsContainer.each(function() {
                    var container = $(this),
                        tabsNav = container.find('.codexse-tabs-nav'),
                        tabsContent = container.find('.codexse-tab-content');

                    // Handle tab click event
                    tabsNav.find('a').on('click', function(e) {
                        e.preventDefault();

                        var tab = $(this),
                            tabId = tab.attr('href');

                        if (tabId && tabId !== '#') {
                            // Remove active class from all tabs and tab content
                            tabsNav.find('li').removeClass('active');
                            tabsContent.removeClass('active');

                            // Add active class to clicked tab and corresponding tab content
                            tab.parent().addClass('active');
                            container.find(tabId).addClass('active');
                        }
                    });
                });
            }
        });
    });
})(jQuery);