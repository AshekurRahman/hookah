;
(function ($) {

    var testimonial_section_1 = function ($scope, $) {
        var slider_elem = $scope.find('.testimonial_slider_1,.testimonial_slider_2').eq(0);
        /*====== Testimonial-Slider ======*/
        var Slider_Navigation = new Swiper(slider_elem.find(".testimonial-navigate-slide"), {
            loop: true,
            speed: 1000,
            spaceBetween: 30,
            slidesPerView: 3,
            watchSlidesVisibility: true,
            watchSlidesProgress: true,
        });
        var Slider_Photo = new Swiper(slider_elem.find(".testimonial-photo-slide"), {
            loop: true,
            speed: 1000,
            spaceBetween: 0,
            slidesPerView: 1,
            watchSlidesVisibility: true,
            watchSlidesProgress: true,
            navigation: {
                nextEl: ".testimonial-navigation .next",
                prevEl: ".testimonial-navigation .prev",
            },
            thumbs: {
                swiper: Slider_Navigation,
            },
        });
        var Slider_Content = new Swiper(slider_elem.find(".testimonial-content-slide"), {
            loop: true,
            speed: 1000,
            spaceBetween: 30,
            slidesPerView: 1,
            watchSlidesVisibility: true,
            watchSlidesProgress: true,
            thumbs: {
                swiper: Slider_Navigation,
            },
        });

        Slider_Photo.controller.control = Slider_Navigation;
        Slider_Photo.controller.control = Slider_Content;
        Slider_Content.controller.control = Slider_Navigation;
        Slider_Content.controller.control = Slider_Photo;
    }

    var carousel_controler = function ($scope, $) {
        var slider_elem = $scope.find('.swiper-container').eq(0);
        if (slider_elem.length > 0) {
            settings = slider_elem.data('settings');
            var slpaginate = false;
            var slloop = settings['slloop'];
            var sleffect = settings['sleffect'];
            var slautolaydelay = settings['slautolaydelay'];
            var slanimation_speed = settings['slanimation_speed'];
            var coverflow_rotate = settings['coverflow_rotate'] ? parseInt(settings['coverflow_rotate']) : 0;
            var coverflow_stretch = settings['coverflow_stretch'] ? parseInt(settings['coverflow_stretch']) : 0;
            var coverflow_depth = settings['coverflow_depth'] ? parseInt(settings['coverflow_depth']) : 0;
            var coverflow_shadow = settings['coverflow_shadow'] == 'yes' ? true : false;

            var sl_navi_switch = settings['sl_navi_switch'];
            var sl_navi_target = settings['sl_navi_target'];
            var sl_pagi_switch = settings['sl_pagi_switch'];
            var sl_pagi_target = settings['sl_pagi_target'];

            var sldisplay_columns = parseInt(settings['sldisplay_columns']);
            var slcenter = settings['slcenter'];
            var sldirection = settings['sldirection'] ? settings['sldirection'] : 'horizontal';
            var slcenter_padding = parseInt(settings['slcenter_padding']);
            
            var client_images = settings['client_images'];
            var image_pagination_sw = settings['image_pagination_sw'];
            var image_pagination_id = settings['image_pagination_id'];
            if(image_pagination_sw){
                slpaginate = {
                    el: '#'+image_pagination_id,
                    bulletClass: 'bullet',
                    bulletActiveClass: 'active',
                    clickable: true,
                    renderBullet: function (index, className) {
                        return '<span class="carousel__item ' + className + '">' + (client_images[index]) + '</span>';
                    }
                };
            } else if (settings['slpaginate']) {
                 if (settings['slpaginatetype'] == 'progress') {
                    slpaginate = {
                        el: (sl_pagi_switch == true && sl_pagi_target != null ? '#slider-pagination-' + sl_pagi_target + ' .codexse-pagination' : $scope.find('.swiper-pagination')),
                        clickable: true,
                        type: 'bullets',
                        renderBullet: function (i) {
                            return `<span class="dot swiper-pagination-bullet" ><svg><circle style="animation-duration: ${slautolaydelay / 1000}s;" cx="11" cy="11" r="10"></circle></svg></span>`;
                        }
                    };
                } else if (settings['slpaginatetype'] == 'number') {
                    slpaginate = {
                        el: (sl_pagi_switch == true && sl_pagi_target != null ? '#slider-pagination-' + sl_pagi_target + ' .codexse-pagination' : $scope.find('.swiper-pagination')),
                        clickable: true,
                        renderBullet: function (index, className) {
                            var number = (index + 1 < 10) ? '0' + (index + 1) : (index + 1);
                            return '<span class="' + className + '">' + number + '</span>';
                        },
                    };
                } else {
                    slpaginate = {
                        el: (sl_pagi_switch == true && sl_pagi_target != null ? '#slider-pagination-' + sl_pagi_target + ' .codexse-pagination' : $scope.find('.swiper-pagination')),
                        clickable: true,
                    };
                }
            }

            var laptop_width = parseInt(settings['laptop_width']);
            var tablet_width = parseInt(settings['tablet_width']);
            var mobile_width = parseInt(settings['mobile_width']);
            var laptop_padding = parseInt(settings['laptop_padding']);
            var tablet_padding = parseInt(settings['tablet_padding']);
            var mobile_padding = parseInt(settings['mobile_padding']);
            var laptop_display_columns = parseInt(settings['laptop_display_columns']);
            var tablet_display_columns = parseInt(settings['tablet_display_columns']);
            var mobile_display_columns = parseInt(settings['mobile_display_columns']);
            

            var swiperOptions = {
                loop: slloop,
                speed: slanimation_speed,
                centeredSlides: slcenter,
                slidesPerView: sldisplay_columns,
                spaceBetween: slcenter_padding,
                direction: sldirection,
                effect: sleffect, // More Options: 'slide' | 'fade' | 'cube' | 'coverflow' | 'flip' 
                coverflowEffect: {
                    rotate: coverflow_rotate,
                    stretch: coverflow_stretch,
                    depth: coverflow_depth,
                    modifier: 1,
                    slideShadows: coverflow_shadow,
                },
                cubeEffect: {
                    slideShadows: coverflow_shadow, // Disable shadows
                },
                flipEffect: {
                    slideShadows: coverflow_shadow, // Disable shadows
                },
                autoplay: {
                    delay: slautolaydelay,
                    disableOnInteraction: false
                },
                navigation: {
                    prevEl: (sl_navi_switch == true && sl_navi_target != null ? '#slider-navigation-' + sl_navi_target + ' .prev-action' : $scope.find('.swiper-navigation .swiper-prev')),
                    nextEl: (sl_navi_switch == true && sl_navi_target != null ? '#slider-navigation-' + sl_navi_target + ' .next-action' : $scope.find('.swiper-navigation .swiper-next')),
                },
                pagination: slpaginate,
                breakpoints: {
                    [mobile_width]: {
                        slidesPerView: mobile_display_columns,
                        spaceBetween: mobile_padding,
                    },
                    [tablet_width]: {
                        slidesPerView: tablet_display_columns,
                        spaceBetween: tablet_padding,
                    },
                    [laptop_width]: {
                        slidesPerView: laptop_display_columns,
                        spaceBetween: laptop_padding,
                    },
                },
            };
            var swiper = new Swiper(slider_elem, swiperOptions);
        }
    }

    // Run this code under Elementor.
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-carousel-addons.default', carousel_controler);
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-project-addons.default', carousel_controler);
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-news-addons.default', carousel_controler);
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-testimonial-addons.default', carousel_controler);
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-testimonial-section-1.default', testimonial_section_1);
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-testimonial-section-2.default', testimonial_section_1);
        elementorFrontend.hooks.addAction('frontend/element_ready/codexse-product-addons.default', carousel_controler);
    });
}(jQuery));