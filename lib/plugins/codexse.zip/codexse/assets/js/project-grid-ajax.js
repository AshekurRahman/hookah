jQuery(document).ready(function($) {
    $('.category__filter .category__button').click(function() {
        $('.category__filter .category__button').removeClass('active');
        $(this).addClass('active');
        var category = $(this).data('category');
        $.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'filter_projects',
                category: category
            },
            success: function(response) {
                $('.project__grid').html(response);
            }
        });
    });
});
