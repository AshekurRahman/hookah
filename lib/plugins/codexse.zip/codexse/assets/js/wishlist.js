
jQuery(document).ready(function($) {
    // Add to Wishlist
    $(document).on('click', '.wishlist-button', function() {
        var this_button = $(this);
        var productId = this_button.data('product-id');
        // Add a loading class
        this_button.removeClass('added');
        this_button.addClass('loading');

        $.ajax({
            type: 'POST',
            url: wishlist_ajax.ajaxurl, // Use the defined 'ajaxurl' variable
            data: {
                action: 'add_to_wishlist',
                product_id: productId
            },
            success: function(response) {
                // Handle the response (e.g., display a success message)
                this_button.removeClass('loading');
                this_button.addClass('added');
            },
            complete: function() {
                // Remove the loading class when the request is complete
                this_button.removeClass('loading');
                this_button.addClass('added');
            }
        });
    });

    // Remove from Wishlist
    $(document).on('click', '.remove-from-wishlist', function(e) {
        e.preventDefault();
        var product_id = $(this).data('product-id');
        var this_button = $(this);
        $.ajax({
            type: 'POST',
            url: wishlist_ajax.ajaxurl, // Use the defined 'ajaxurl' variable
            data: {
                action: 'remove_from_wishlist',
                product_id: product_id
            },
            success: function(response) {
                // Handle success (e.g., remove the row from the table)
                if (response == 'success') {
                    this_button.closest('.cart__product_item').remove();
                }
            },
        });
    });




});
