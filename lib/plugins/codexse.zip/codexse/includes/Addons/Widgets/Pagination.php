<?php                                                                                                                                                               
namespace Elementor;                                                                                                                                                
                                                                                                                                                                    
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly                                                                                                    
                                                                                                                                                                    
class Codexse_Elementor_Widget_Pagination extends Widget_Base {                                                                                                       
                                                                                                                                                                    
    public function get_name() {                                                                                                                                    
        return 'codexse-pagination-addons';                                                                                                                           
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_title() {                                                                                                                                   
        return __( 'Pagination', 'codexse-addons' );                                                                                                                  
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_icon() {                                                                                                                                    
        return 'codexse-icon eicon-navigation-horizontal';                                                                                                                    
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_categories() {                                                                                                                              
        return [ 'codexse-addons' ];                                                                                                                                
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_style_depends() {                                                                                                                           
        return [                                                                                                                                                    
            'swiper',                                                                                                                                                 
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_script_depends() {                                                                                                                          
        return [                                                                                                                                                    
            'swiper-slider',                  
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function register_controls() {
        $this->start_controls_section(
            'slider_pagination',
            [
                'label' => __( 'Slider Pagination', 'codexse' ),
            ]
        );
        
            $this->add_control(
                 'slider_target_id',
                 [
                     'label'     => __( 'Pagination ID', 'codexse' ),
                     'type'      => Controls_Manager::TEXT,
                     'title' => __( 'Copy this Id and paste at slider "Target ID" field.', 'codexse' ),
                     'default' => uniqid(),
                 ]
             );
             
             $this->add_control(                                                                                                                                     
                'slpaginatetype',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Paginate Type', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'progress',                                                                                                                           
                    'options' => [                                                                                                                                
                        'progress'  => __( 'Circle Progress', 'codexse' ),                                                                                                         
                        'number'  => __( 'Number', 'codexse' ),                                                                                                
                        'dots'  => __( 'Dots', 'codexse' )                                                                                               
                    ],
                ]                                                                                                                                                   
            );   

            $this->add_control(                                                                                                                                     
                'slpaginatenumstyle',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Number Style', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'one',                                                                                                                           
                    'options' => [                                                                                                                                
                        'one'  => __( 'Style one', 'codexse' ),                                                                                                   
                        'two'  => __( 'Style two', 'codexse' ),                                                                                                   
                        'three'  => __( 'Style three', 'codexse' ),                                                                                                
                    ],                                                                                           
                    'condition'=>[                                                                                                                         
                        'slpaginatetype' => 'number',
                    ]
                ]                                                                                                                                                   
            );     
            
        $this->end_controls_section();
        
        // post Style Tab section
        $this->start_controls_section(
            'tab_area_style_section',
            [
                'label' => __( 'Area Style', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'tab_tab_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}}' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        ); 
        $this->add_responsive_control(
            'tab_tab_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}}' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        
        );  
        
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'tab_tab_border',
                'label' => __( 'Border', 'core' ),
                'selector' => '{{WRAPPER}}',
                'separator' =>'before',
            ]
        );

        $this->add_responsive_control(
            'tab_tab_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}}' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'tab_tab_shadow',
                'label' => __( 'Box Shadow', '' ),
                'selector' => '{{WRAPPER}}',
                'separator' =>'before',
            ]
        );
        
         $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'tab_tab_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}}',
                'separator' =>'before',
            ]
        );
        $this->end_controls_section(); // post section style end                        
        // Tab Style Tab section
        $this->start_controls_section(
            'tab_tab_section',
            [
                'label' => __( 'Tab Menu', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_responsive_control(
            'tab_menu_align',
            [
                'label' => __( 'Alignment', 'codexse' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __( 'Left', 'codexse' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'codexse' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'flex-end' => [
                        'title' => __( 'Right', 'codexse' ),
                        'icon' => 'fa fa-align-right',
                    ],
                    'space-between' => [
                        'title' => __( 'Justified', 'codexse' ),
                        'icon' => 'fa fa-align-justify',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination' => 'display: flex; justify-content: {{VALUE}};',
                ],
                'default' => 'center'
            ]
        );
        $this->add_responsive_control(
            'tab_menu_width',
            [
                'label' => __( 'Width', 'codexse' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'vw' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 9999,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'tab_menu_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        $this->add_responsive_control(
            'tab_menu_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'tab_menu_area_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .codexse-pagination',
            ]
        );
        $this->add_responsive_control(
            'tab_menu_area_radius',
            [
                'label' => esc_html__( 'Box Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'tab_menu_area_shadow',
                'selector' => '{{WRAPPER}} .codexse-pagination',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'tab_menu_area_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .codexse-pagination',
            ]
        );
        
        $this->add_control(
            'tab_menu_list_title_sc',
            [
                'label'     => __( 'Tab Menu Item Style', 'codexse' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->start_controls_tabs('box_tab_style_tab');
        
        $this->start_controls_tab( 'box_tab_normal',
            [
                'label' => __( 'Normal', 'codexse' ),
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'tab_tab_typography',
                'selector' => '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet',
            ]
        );
        $this->add_control(
            'tab_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet' => 'color: {{VALUE}};'
                ],
            ]
        );
         $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'tab_bg_color',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet',
                'separator' =>'before',
            ]
        );
        $this->add_responsive_control(
            'tab_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'tab_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );  
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'tab_menu_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet',
            ]
        );
        $this->add_responsive_control(
            'tab_menu_border_radius',
            [
                'label' => esc_html__( 'Box Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_control(
            'tab_item_transition',
            [
                'label' => __( 'Transition Duration', 'codexse' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0.3,
                ],
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'tab_item_width',
            [
                'label' => __( 'Width', 'codexse' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'vw' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 9999,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'tab_item_height',
            [
                'label' => __( 'Height', 'codexse' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'vw' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 9999,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'tab_item_line_height',
            [
                'label' => __( 'Line Height', 'codexse' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'vw' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 9999,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet' => 'line-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'tab_item_shadow',
                'label' => __( 'Box Shadow', '' ),
                'selector' => '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet',
                'separator' =>'before',
            ]
        );
        $this->end_controls_tab(); // Hover Style Tab end
        $this->start_controls_tab( 'tab_items_hover',
            [
                'label' => __( 'Hover', 'codexse' ),
            ]
        );    
        
        $this->add_control(
            'hover_tab_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet:hover' => 'color: {{VALUE}};'
                ],
            ]
        );
        
         $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'hover_tab_bg_color',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet:hover',
                'separator' =>'before',
            ]
        );
        
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'tab_menu_active_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet:hover',
            ]
        );
        
        
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'tab_item_active_shadow',
                'label' => __( 'Box Shadow', '' ),
                'selector' => '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet:hover',
                'separator' =>'before',
            ]
        );
        $this->end_controls_tab(); // Hover Style Tab end
      
        $this->start_controls_tab( 'tab_items_active',
            [
                'label' => __( 'Active', 'codexse' ),
            ]
        );    
        
        $this->add_control(
            'active_tab_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'color: {{VALUE}};'
                ],
            ]
        );
        
         $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'active_tab_bg_color',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet.swiper-pagination-bullet-active',
                'separator' =>'before',
            ]
        );
        
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'tab_menu_active_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet.swiper-pagination-bullet-active',
            ]
        );
        
        
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'tab_item_active_shadow',
                'label' => __( 'Box Shadow', '' ),
                'selector' => '{{WRAPPER}} .codexse-pagination .swiper-pagination-bullet.swiper-pagination-bullet-active',
                'separator' =>'before',
            ]
        );
        $this->end_controls_tab(); // Hover Style Tab end
        $this->end_controls_tabs();// Box Style tabs end
        $this->end_controls_section();                                                                                                           
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function render( $instance = [] ) {
        $settings   = $this->get_settings_for_display();
        $html_output = '';
        $this->add_render_attribute( 'codexse_pagination_attr', 'class', 'codexse-custom-pagination' );
        $this->add_render_attribute( 'codexse_pagination_attr', 'class', 'pagination-type-'.$settings['slpaginatetype'] );
        $this->add_render_attribute( 'codexse_pagination_attr', 'class', 'number-type-'.$settings['slpaginatenumstyle'] );
        $this->add_render_attribute( 'codexse_pagination_attr', 'id', 'slider-pagination-'.$settings['slider_target_id'] );
        $html_output .= '<div '.$this->get_render_attribute_string( 'codexse_pagination_attr' ).'>';
            $html_output .= '<div class="codexse-pagination"></div>';
        $html_output .= '</div>';
        echo $html_output;
    }      
    
}                                                                                                                                                                   
                                                                                                                                                                    
