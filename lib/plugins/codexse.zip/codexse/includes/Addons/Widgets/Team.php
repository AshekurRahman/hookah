<?php                                                                                                                                                               
namespace Elementor;                                                                                                                                                
                                                                                                                                                                    
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly                                                                                                    
                                                                                                                                                                    
class Codexse_Elementor_Widget_Team extends Widget_Base {                                                                                                       
                                                                                                                                                                    
    public function get_name() {                                                                                                                                    
        return 'codexse-team-addons';                                                                                                                           
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_title() {                                                                                                                                   
        return __( 'Team', 'codexse' );                                                                                                                  
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_icon() {                                                                                                                                    
        return 'codexse-icon eicon-person';                                                                                                                    
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_categories(){
        return ["codexse-addons"];
    }                                                                                                                                                           
                                                                                                                                                                    
    public function get_style_depends() {                                                                                                                           
        return [                                                                                                                                                    
            'swiper',                                                                                                                                        
            'codexse-carousel',
            'codexse-team'                                                                                                                
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_script_depends() {                                                                                                                          
        return [                                                                                                                                                    
            'swiper-slider',                                                                                                                                        
            'codexse-carousel',                                                                                                                                     
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function register_controls() {                                                                                                                        
                                                                                                                                                                    
        $this->start_controls_section(                                                                                                                              
            'team_content',                                                                                                                                      
            [                                                                                                                                                       
                'label' => __( 'Team', 'codexse' ),                                                                                                      
            ]                                                                                                                                                       
        );                                                                                                                                                               
                                                                                                                                                                    
            $repeater = new Repeater();                                                                                                                                                     
            $repeater->add_control(                                                                                                                                 
                'team_image',                                                                                                                                    
                [                                                                                                                                                   
                    'label' => __( 'Image', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::MEDIA,                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $repeater->add_group_control(                                                                                                                           
                Group_Control_Image_Size::get_type(),                                                                                                               
                [                                                                                                                                                   
                    'name' => 'team_imagesize',                                                                                                                  
                    'default' => 'large',                                                                                                                           
                    'separator' => 'none',                                                                                                                          
                ]                                                                                                                                                   
            );                                                                                                            
            $repeater->add_control(                                                                                                                                 
                'team_name',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Name', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXT,                                                                                                            
                    'placeholder' => __('Enter type your client name.','codexse'),                                                                                      
                ]                                                                                                                                                   
            );                                                                                                                          
            $repeater->add_control(                                                                                                                                 
                'team_position',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Position', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXT,                                                                                                            
                    'placeholder' => __('Enter type your client position.','codexse'),                                                                                      
                ]                                                                                                                                                   
            );           
            
            $repeater->add_control(                                                                                                                                 
                'team_desc',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Description', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXTAREA,                                                                                
                ]                                                                                                                                                   
            );    
            
            $repeater->add_control(
              'email_address',
                [
                    'label' => esc_html__( 'Email Address', 'codexse' ),
                    'type' => Controls_Manager::TEXT,
                    'placeholder' => 'example@example.com',
                    'label_block' => true,
                ]
            );
            
            $repeater->add_control(
                'phone_number',
                [
                    'label' => esc_html__( 'Phone', 'codexse' ),
                    'type' => Controls_Manager::TEXT,
                    'label_block' => true,
                ]
            );
            
            $repeater->add_control(
                'whatsapp_number',
                [
                    'label' => esc_html__( 'Whatsapp Number', 'codexse' ),
                    'type' => Controls_Manager::TEXT,
                    'label_block' => true,
                ]
            );
          
            
                                                                                                                                                                      
            $this->add_control(                                                                                                                                     
                'team_list',                                                                                                                               
                [                                                                                                                                                   
                    'type'    => Controls_Manager::REPEATER,                                                                                                        
                    'fields'  => $repeater->get_controls(),                                                                                                         
                    'default' => [                                                                                                                                  
                                                                                                                                                                    
                        [                                                                                                                                           
                            'team_desc'        => __('All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.','codexse'),                                                                   
                            'team_name'        => __('Helena Paitora','codexse'),                                                                   
                            'team_position'        => __('Digital Marketer','codexse'),                                                                
                        ],                                                                                                                              
                        [                                                                                                                                           
                            'team_desc'        => __('All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.','codexse'),                                                                   
                            'team_name'        => __('Jason Kink','codexse'),                                                                   
                            'team_position'        => __('Digital Marketer','codexse'),                                                                
                        ],                                                                                                                              
                        [                                                                                                                                           
                            'team_desc'        => __('All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.','codexse'),                                                                   
                            'team_name'        => __('Irfan Raza','codexse'),                                                                   
                            'team_position'        => __('Digital Marketer','codexse'),                                                                
                        ],                                                                                                                                          
                                                                                                                                                                    
                    ],                                                                                                                                              
                    'title_field' => '{{{ team_name }}}',                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                         
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slider_on',                                                                                                                                        
                [                                                                                                                                                   
                    'label'         => __( 'Slider', 'codexse' ),                                                                                            
                    'type'          => Controls_Manager::SWITCHER,                                                                                                  
                    'label_on'      => __( 'On', 'codexse' ),                                                                                                
                    'label_off'     => __( 'Off', 'codexse' ),                                                                                               
                    'return_value'  => 'yes',                                                                                                                       
                    'default'       => 'yes',                                                                                                                       
                ]                                                                                                                                                   
            );
            $this->add_control(
                'item_column',
                [
                    'label' => __( 'Column', 'codexse' ),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        '1grid' => [
                            'title' => __( 'One Column', 'codexse' ),
                            'icon' => 'icon-grid-1',
                        ],
                        '2grid' => [
                            'title' => __( 'Two Columns', 'codexse' ),
                            'icon' => 'icon-grid-2',
                        ],
                        '3grid' => [
                            'title' => __( 'Three Columns', 'codexse' ),
                            'icon' => 'icon-grid-3',
                        ],
                        '4grid' => [
                            'title' => __( 'Four Columns', 'codexse' ),
                            'icon' => 'icon-grid-4',
                        ],
                    ],
                    'default' => '3grid',
                    'toggle' => true,
                    'condition' => [
                        'slider_on!' => 'yes',
                    ]
                ]
            );
        
            $this->add_control(
                'grid_space',
                [
                    'label' => esc_html__( 'Grid Space', 'codexse' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'g-4',
                    'options' => [
                        'g-1'  => __( 'One', 'codexse' ),
                        'g-2'  => __( 'Two', 'codexse' ),
                        'g-3'  => __( 'Three', 'codexse' ),
                        'g-4'  => __( 'Four', 'codexse' ),
                        'g-5'  => __( 'Five', 'codexse' ),
                    ],
                    'condition' => [
                        'slider_on!' => 'yes',
                    ]
                ]
            );

            $this->add_control(
                'masonry',
                [
                    'label'         => __( 'Masonry', 'codexse' ),
                    'type'          => Controls_Manager::SWITCHER,
                    'label_on'      => __( 'On', 'codexse' ),
                    'label_off'     => __( 'Off', 'codexse' ),
                    'return_value'  => 'yes',
                    'default'       => 'no',
                    'condition' => [
                        'slider_on!' => 'yes',
                    ]
                ]
            );

                                                                                                                                                                    
        $this->end_controls_section();                                                                                                                              
                                                                                                                                                                    
        $this->start_controls_section(                                                                                                                              
            'slider_option',                                                                                                                                        
            [                                                                                                                                                       
                'label' => esc_html__( 'Slider Option', 'codexse' ),                                                                                                
                'condition'=>[                                                                                                                                      
                    'slider_on'=>'yes',                                                                                                                             
                ]                                                                                                                                                   
            ]                                                                                                                                                       
        );                                                                                                                                                          
            $this->add_control(                                                                                                                                     
                'sl_navigation',                                                                                                                                    
                [                                                                                                                                                   
                    'label' => esc_html__( 'Arrow', 'codexse' ),                                                                                                    
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slider_custom_arrow',                                                                                                                              
                [                                                                                                                                                   
                    'label' => esc_html__( 'Custom Arrow', 'codexse' ),                                                                                             
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                 'slider_target_id',                                                                                                                                
                 [                                                                                                                                                  
                     'label'     => __( 'Arrows ID', 'codexse' ),                                                                                                   
                     'type'      => Controls_Manager::TEXT,                                                                                                         
                     'title' => __( 'Take arrow id from "Custom Navigation" addons and paste here!', 'codexse' ),                                                   
                     'condition' => [                                                                                                                               
                        'slider_custom_arrow' => 'yes',                                                                                                            
                        'sl_navigation'=>'yes',                                                                                                                     
                     ]                                                                                                                                              
                 ]                                                                                                                                                  
             );                                                                                                                                                     
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sl_nav_prev_icon',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Previus Icon', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::ICON,                                                                                                               
                    'default' => 'fa fa-angle-left',                                                                                                                
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                        'slider_custom_arrow!'=>'yes',                                                                                                              
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sl_nav_next_icon',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Next Arrow', 'codexse' ),                                                                                                       
                    'type' => Controls_Manager::ICON,                                                                                                               
                    'default' => 'fa fa-angle-right',                                                                                                               
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                        'slider_custom_arrow!'=>'yes',                                                                                                              
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slpaginate',                                                                                                                                       
                [                                                                                                                                                   
                    'label' => esc_html__( 'Paginate', 'codexse' ),                                                                                                 
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sleffect',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Effect', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'slide',                                                                                                                           
                    'options' => [                                                                                                                                  
                        'slide'  => __( 'Slide', 'codexse' ),                                                                                                       
                        'fade'  => __( 'Fade', 'codexse' ),                                                                                                         
                        'cube'  => __( 'Cube', 'codexse' ),                                                                                                         
                        'coverflow'  => __( 'Coverflow', 'codexse' ),                                                                                               
                        'flip'  => __( 'Flip', 'codexse' ),                                                                                                         
                    ],                                                                                                                                              
                ]                                                                                                                                                   
            );   

            $this->add_control(                                                                                                                                     
                'coverflow_option_heading',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Coverflow Options', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'before',   
                    'condition' => [
                        'sleffect' => 'coverflow',
                    ]                                                                                                                      
                ]                                                                                                                                                   
            );            
                                                                                                                                                                                
            $this->add_control(                                                                                                                                     
                'coverflow_rotate',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Rotate', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 360,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 0,      
                    'condition' => [
                        'sleffect' => 'coverflow',
                    ]                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                                                   
            $this->add_control(                                                                                                                                     
                'coverflow_stretch',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Stretch', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 9999,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 0,      
                    'condition' => [
                        'sleffect' => 'coverflow',
                    ]                                                                                                                                 
                ]                                                                                                                                                   
            );              
                                                                                                                                                                     
            $this->add_control(                                                                                                                                     
                'coverflow_depth',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Depth', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 9999,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 0,      
                    'condition' => [
                        'sleffect' => 'coverflow',
                    ],                                                                                                                                          
                ]                                                                                                                                                   
            );                                                                                                                                                                  
            $this->add_control(                                                                                                                                     
                'coverflow_shadow',                                                                                                                                           
                [                                                                                                                                                   
                    'label' => esc_html__( 'Shadow', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                   
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slloop',                                                                                                                                           
                [                                                                                                                                                   
                    'label' => esc_html__( 'Loop', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );  

            $this->add_control(                                                                                                                                     
                'slautolay',                                                                                                                                        
                [                                                                                                                                                   
                    'label' => esc_html__( 'Autoplay', 'codexse' ),                                                                                                 
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slautolaydelay',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Autoplay Delay', 'codexse'),                                                                                                     
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 6500,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slcenter',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Center', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sldisplay_columns',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 1,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slcenter_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slanimation_speed',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Slide Speed', 'codexse'),                                                                                                        
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 1000,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                   
            $this->add_control(                                                                                                                                     
                'sldirection',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Direction', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'horizontal',                                                                                                                           
                    'options' => [                                                                                                                                  
                        'horizontal'  => __( 'horizontal', 'codexse' ),                                                                                                       
                        'vertical'  => __( 'vertical', 'codexse' ),                                                                                                       
                    ],                                                                                                                                              
                ]                                                                                                                                                   
            );        
        
            $this->add_responsive_control(
                'slider_height',
                [
                    'label' => __( 'Height', 'codexse' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%', 'vh', 'vw' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                        'vh' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                        'vw' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .swiper-container' => 'height: {{SIZE}}{{UNIT}};',
                    ],
                    'condition' => [
                        'sldirection' => 'vertical',
                    ]
                ]
            );                                                                                                                                                  
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_laptop',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Laptop', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Laptop Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to laptop.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 1200,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 3,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_tablet',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Tablet', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Tablet Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to tablet.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 992,                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 2,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 768,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_mobile',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Mobile Phone', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Mobile Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to mobile.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 768,                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 4,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 1,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );
                                                                                                                                                                   
            $this->add_control(
                'image_pagination_sw',
                [
                    'label' => esc_html__( 'Image Pagination', 'codexse' ),
                    'type' => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );
            
            $this->add_control(
                'image_pagination_id',
                [
                    'label'     => __( 'Pagination ID', 'codexse' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => rand(),
                    'title'     => __( 'Extract the arrow ID from this location and insert it into an HTML code addon "<div id="id_name_here"></div>"', 'codexse' ),
                    'condition' => [
                        'image_pagination_sw' => 'yes',
                    ]
                ]
            );
        $this->end_controls_section();                                                                      
                                                                                                                                                                    
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function render( $instance = [] ) {      
        $column = "col-lg-4 col-md-6";                                                                                                   
        $settings   = $this->get_settings_for_display();                                                                       

        $client = [];
        foreach ( $settings['team_list'] as $item ):
            if(Group_Control_Image_Size::get_attachment_image_html( $item, 'team_imagesize', 'team_image' )){
                $client[] = Group_Control_Image_Size::get_attachment_image_html( $item, 'team_imagesize', 'team_image' );
            }else{
                $client[] = '<img src="'.CODEXSE_ASSETS.'/images/user_placeholder.jpg" alt="" />';
            }
        endforeach;
        if( $settings['slider_on'] == 'yes' ){                                                                                                                      
            $this->add_render_attribute( 'wrapper_attributes', 'class', 'swiper-container' );                                                                       
            $slider_settings = [                                                                                                                                    
                'sleffect' => $settings['sleffect'],                                                                                                                
                'sldirection' => $settings['sldirection'],                                                                                                                
                'slloop' => ('yes' === $settings['slloop']),                                                                                               
                'slpaginate' => ('yes' === $settings['slpaginate']),                                                                                                               
                'slautolay' => ('yes' === $settings['slautolay']),                                                                                                  
                'slautolaydelay' => absint($settings['slautolaydelay']), 
                'slanimation_speed' => absint($settings['slanimation_speed']),   
                'coverflow_rotate' => absint($settings['coverflow_rotate']),    
                'coverflow_stretch' => absint($settings['coverflow_stretch']),    
                'coverflow_depth' => absint($settings['coverflow_depth']),                                                                                                   
                'coverflow_shadow' => $settings['coverflow_shadow'],              
                'slcustom_arrow' => ('yes' === $settings['slider_custom_arrow']),                                                                                   
                'sltarget_id' => $settings['slider_target_id'],                                                                                                     
                'sldisplay_columns' => $settings['sldisplay_columns'],                                                                                              
                'slcenter' => ('yes' === $settings['slcenter']),                                                                                           
                'slcenter_padding' => $settings['slcenter_padding'],                                                                                                
                'laptop_width' => $settings['sllaptop_width'],                                                                                                      
                'laptop_padding' => $settings['sllaptop_padding'],                                                                                                  
                'laptop_display_columns' => $settings['sllaptop_display_columns'],                                                                                  
                'tablet_width' => $settings['sltablet_width'],                                                                                                      
                'tablet_padding' => $settings['sltablet_padding'],                                                                                                  
                'tablet_display_columns' => $settings['sltablet_display_columns'],                                                                                  
                'mobile_width' => $settings['slmobile_width'],                                                                                                      
                'mobile_padding' => $settings['slmobile_padding'],                                                                                                  
                'mobile_display_columns' => $settings['slmobile_display_columns'],                                                                                                            
                'image_pagination_sw' => ('yes' === $settings['image_pagination_sw']),                                                                           
                'image_pagination_id' => $settings['image_pagination_id'],      
                'client_images' => $client,                                                                                                     
            ];                                                                                                                                                      
            $this->add_render_attribute( 'wrapper_attributes', 'data-settings', wp_json_encode( $slider_settings ) );                                               
        }else {
            $this->add_render_attribute( 'wrapper_attributes', 'class', ['row', esc_attr($settings['grid_space'])] );
            if($settings['masonry'] == 'yes'){
                $this->add_render_attribute( 'wrapper_attributes', 'class', 'masonry_lists' );
            }
            switch ($settings['item_column']) {
                case "1grid":
                    $column = "col-lg-12";
                    break;
                case "2grid":
                    $column = "col-lg-6 col-md-12";
                    break;
                case "3grid":
                    $column = "col-lg-4 col-md-6";
                    break;
                default:
                    $column = "col-xl-3 col-lg-4 col-md-6";
            }
        }
        echo '<div '.$this->get_render_attribute_string( "wrapper_attributes" ).' >';                                                                               
            if($settings['slider_on'] == 'yes'){
                echo '<div class="swiper-wrapper">';                                                                                                                        
                    foreach ( $settings['team_list'] as $item ):
                        echo '<div class="swiper-slide elementor-repeater-item-'.$item['_id'].'">';    
                        echo $this->post__content($item);                                                                                                                                 
                        echo '</div>';                                                                                                                                      
                    endforeach;                                                                                                                                             
                echo '</div>';
                echo $this->slider__tools($settings);
            }else {                                                                                        
                foreach ( $settings['team_list'] as $item ):   
                    echo '<div class="'.$column.' elementor-repeater-item-'.$item['_id'].'">';  
                        echo $this->post__content($item);
                    echo '</div>';
                endforeach;
            }            
        echo '</div>';                                                                                                                                              
    }
    
    protected function post__content($item) {
        $output = '<div class="team__item">';
        
        // Check if there's a team image, if not, use a placeholder
        $output .= '<div class="team__photo">';
            if (Group_Control_Image_Size::get_attachment_image_html($item, 'team_imagesize', 'team_image')) {
                $output .= Group_Control_Image_Size::get_attachment_image_html($item, 'team_imagesize', 'team_image');
            } else {
                $output .= '<img src="' . CODEXSE_ASSETS . '/images/user_placeholder.jpg" alt="" />';
            }
        $output .= '</div>';
        
        // Display team name and position
        $output .= '<div class="team__header">';
            if (!empty($item['team_name'])) {
                $output .= '<h4 class="team__name">' . esc_html($item['team_name']) . '</h4>';
            }
            if (!empty($item['team_position'])) {
                $output .= '<span class="team__position">' . esc_html($item['team_position']) . '</span>';
            }
        $output .= '</div>';
        
        // Additional hover content (name, position, description, social links)
        $output .= '<div class="team__hover__content">';
            $output .= '<div class="team__content__header">';
                if (!empty($item['team_name'])) {
                    $output .= '<h4 class="team__name">' . esc_html($item['team_name']) . '</h4>';
                }
                if (!empty($item['team_position'])) {
                    $output .= '<span class="team__position">' . esc_html($item['team_position']) . '</span>';
                }
            $output .= '</div>';
            if (!empty($item['team_desc'])) {
                $output .= '<div class="team__desc">' . esc_html($item['team_desc']) . '</div>';
            }
            $output .= '<div class="team__social">';
              if (!empty($item['email_address'])) {
                  $output .= '<a href="mailto:' . $item['email_address'] . '" class="social__link"><i class="fa-regular fa-envelope"></i></a>';
              }
              if (!empty($item['phone_number'])) {
                  $output .= '<a href="tel:' . $item['phone_number'] . '" class="social__link"><i class="fa-regular fa-phone"></i></a>';
              }
              if (!empty($item['whatsapp_number'])) {
                  $output .= '<a href="https://wa.me/' . esc_attr($item['whatsapp_number']) . '" class="social__link"><i class="fa-brands fa-whatsapp"></i></a>';
              }
            $output .= '</div>';
            
        $output .= '</div>';
        
        $output .= '</div>'; // Close team__item div
        
        return $output;
    }

    protected function slider__tools($settings){                                                                                             
        if( $settings['sl_navigation'] == 'yes' && $settings['slider_custom_arrow'] != 'yes' ){                                                                       
            echo '<div class="swiper-navigations" >';                                                                                                                
                echo '<div class="swiper-navigation swiper-prev"><i class="'.esc_attr($settings['sl_nav_prev_icon']).'" ></i></div>';                                    
                echo '<div class="swiper-navigation swiper-next"><i class="'.esc_attr($settings['sl_nav_next_icon']).'" ></i></div>';                                    
            echo '</div>';                                                                                                                                          
        }                                                                                                                                                           
        if( $settings['slpaginate'] == 'yes' ){                                                                                                                      
            echo '<div class="swiper-pagination"></div>';                                                                                                           
        }     
    }
    



                                                                                                                                                                    
}                                                                                                                                                                   
                                                                                                                                                                    
