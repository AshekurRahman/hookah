<?php                                                                                                                                                               
namespace Elementor;                                                                                                                                                
                                                                                                                                                                    
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly                                                                                                    
                                                                                                                                                                    
class Codexse_Elementor_Widget_Portfolio extends Widget_Base {                                                                                                       
                                                                                                                                                                    
    public function get_name() {                                                                                                                                    
        return 'codexse-portfolio-addons';                                                                                                                           
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_title() {                                                                                                                                   
        return __( 'Portfolio', 'codexse' );                                                                                                                  
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_icon() {                                                                                                                                    
        return 'codexse-icon eicon-posts-carousel';                                                                                                                    
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_categories() {                                                                                                                              
        return [ 'codexse-addons' ];                                                                                                                                
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_style_depends() {                                                                                                                           
        return [                                                                                                                                                    
            'swiper',                                                                                                                                        
            'codexse-carousel',                                                                                                                                  
            'codexse-portfolio'                                                                                                                                      
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_script_depends() {                                                                                                                          
        return [                                                                                                                                                    
            'swiper-slider',                                                                                                                                        
            'codexse-carousel',                                                                                                                                     
            'codexse-lax',                                                                                                                                     
            'codexse-lax-active',                                                                                                                                     
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function register_controls() {
        
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Portfolio Settings', 'codexse' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        
            $this->add_control(
                'slider_on',
                [
                    'label'         => __( 'Slider', 'codexse' ),
                    'type'          => Controls_Manager::SWITCHER,
                    'label_on'      => __( 'On', 'codexse' ),
                    'label_off'     => __( 'Off', 'codexse' ),
                    'return_value'  => 'yes',
                    'default'       => 'no',
                ]
            );
        
        
            $this->add_control(
                'item_column',
                [
                    'label' => __( 'Column', 'codexse' ),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        '1grid' => [
                            'title' => __( 'One Column', 'codexse' ),
                            'icon' => 'icon-grid-1',
                        ],
                        '2grid' => [
                            'title' => __( 'Two Columns', 'codexse' ),
                            'icon' => 'icon-grid-2',
                        ],
                        '3grid' => [
                            'title' => __( 'Three Columns', 'codexse' ),
                            'icon' => 'icon-grid-3',
                        ],
                        '4grid' => [
                            'title' => __( 'Four Columns', 'codexse' ),
                            'icon' => 'icon-grid-4',
                        ],
                    ],
                    'default' => '3grid',
                    'toggle' => true,
                    'condition' => [
                        'slider_on!' => 'yes',
                    ]
                ]
            );
        
            $this->add_control(
                'grid_space',
                [
                    'label' => esc_html__( 'Grid Space', 'codexse' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'g-4',
                    'options' => [
                        'g-1'  => __( 'One', 'codexse' ),
                        'g-2'  => __( 'Two', 'codexse' ),
                        'g-3'  => __( 'Three', 'codexse' ),
                        'g-4'  => __( 'Four', 'codexse' ),
                        'g-5'  => __( 'Five', 'codexse' ),
                    ],
                    'condition' => [
                        'slider_on!' => 'yes',
                    ]
                ]
            );

            $this->add_control(
                'masonry',
                [
                    'label'         => __( 'Masonry', 'codexse' ),
                    'type'          => Controls_Manager::SWITCHER,
                    'label_on'      => __( 'On', 'codexse' ),
                    'label_off'     => __( 'Off', 'codexse' ),
                    'return_value'  => 'yes',
                    'default'       => 'no',
                    'condition' => [
                        'slider_on!' => 'yes',
                    ]
                ]
            );
            $this->add_control(
                'post_style',
                [
                    'label' => __( 'Grid Style', 'codexse' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'style1',
                    'options' => [
                        'style1'  => esc_html__( 'Style One', 'codexse' ),
                        'style2' => esc_html__( 'Style Two', 'codexse' ),
                        'style3' => esc_html__( 'Style Three', 'codexse' ),
                        'style4' => esc_html__( 'Style Four', 'codexse' ),
                        'style5' => esc_html__( 'Style Five', 'codexse' ),
                    ],
                ]
            );
        
            $this->add_control(
                'post_categories',
                [
                    'label' => esc_html__( 'Categories', 'codexse' ),
                    'type' => Controls_Manager::SELECT2,
                    'label_block' => true,
                    'multiple' => true,
                    'options' => codexse_get_taxonomies('category'),
                ]
            );
            $this->add_control(
                'title_list',
                [
                    'label' => esc_html__( 'Title', 'codexse' ),
                    'type' => Controls_Manager::SELECT2,
                    'multiple' => true,
                    'options' => codexse_get_title('portfolio'),
                    'separator'=>'before',
                ]
            );
            $this->add_control(
                'post_limit',
                [
                    'label' => __('Limit', 'codexse'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 10,
                    'separator'=>'before',
                ]
            );

            $this->add_control(
                'custom_order',
                [
                    'label' => esc_html__( 'Custom order', 'codexse' ),
                    'type' => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );

            $this->add_control(
                'postorder',
                [
                    'label' => esc_html__( 'Order', 'codexse' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'DESC',
                    'options' => [
                        'DESC'  => esc_html__('Descending','codexse'),
                        'ASC'   => esc_html__('Ascending','codexse'),
                    ],
                    'condition' => [
                        'custom_order!' => 'yes',
                    ]
                ]
            );

            $this->add_control(
                'orderby',
                [
                    'label' => esc_html__( 'Orderby', 'codexse' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'none',
                    'options' => [
                        'none'          => esc_html__('None','codexse'),
                        'ID'            => esc_html__('ID','codexse'),
                        'date'          => esc_html__('Date','codexse'),
                        'name'          => esc_html__('Name','codexse'),
                        'title'         => esc_html__('Title','codexse'),
                        'comment_count' => esc_html__('Comment count','codexse'),
                        'rand'          => esc_html__('Random','codexse'),
                    ],
                    'condition' => [
                        'custom_order' => 'yes',
                    ]
                ]
            );

            $this->add_control(
                'show_thumb',
                [
                    'label' => esc_html__( 'Thumbnail', 'codexse' ),
                    'type' => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );   
            $this->add_control(
                'thumbnail_size',
                [
                    'label' => esc_html__( 'Image Size', 'codexse' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'thumbnail' => esc_html__('Thumbnail','codexse'),
                        'medium' => esc_html__('Medium','codexse'),
                        'large' => esc_html__('Large','codexse'),
                        'full' => esc_html__('Full','codexse'),
                    ],
                    'default' => 'large',
                    'condition' => [
                        'show_thumb' => 'yes',
                    ]
                ]
            );
             $this->add_control(
                'show_title',
                [
                    'label' => esc_html__( 'Title', 'codexse' ),
                    'type' => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );

            $this->add_control(
                'title_length',
                [
                    'label' => __( 'Title Length', 'codexse' ),
                    'type' => Controls_Manager::NUMBER,
                    'step' => 1,
                    'default' => 5,
                    'condition'=>[
                        'show_title'=>'yes',
                    ]
                ]
            );
            $this->add_control(
                'title_line',
                [
                    'label' => __( 'Title Column', 'codexse' ),
                    'type' => Controls_Manager::NUMBER,
                    'step' => 1,
                    'selectors' => [
                        '{{WRAPPER}} .post-box .title a' => '-webkit-line-clamp: {{VALUE}};line-clamp: {{VALUE}};',
                    ],
                    'condition'=>[
                        'show_title' => 'yes',
                    ]
                ]
            );

            $this->add_control(
                'show_content',
                [
                    'label' => esc_html__( 'Description', 'codexse' ),
                    'type' => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );

            $this->add_control(
                'content_length',
                [
                    'label' => __( 'Description Length', 'codexse' ),
                    'type' => Controls_Manager::NUMBER,
                    'step' => 1,
                    'default' => 50,
                    'condition'=>[
                        'show_content'=>'yes',
                    ]
                ]
            );

            $this->add_control(
                'show_button',
                [
                    'label' => esc_html__( 'Show Button', 'codexse' ),
                    'type' => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );

            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Button Text', 'codexse' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __( 'Read More', 'codexse' ),
                    'placeholder' => __( 'Read More', 'codexse' ),
                    'label_block'=>true,
                    'condition'=>[
                        'show_button'=>'yes',
                    ]
                ]
            );

            $this->add_control(
                'button_icon_type',
                [
                    'label' => __('Button Icon','codexse'),
                    'type' =>Controls_Manager::CHOOSE,
                    'options' =>[
                        'img' =>[
                            'title' =>__('Image','codexse'),
                            'icon' =>'eicon-image-bold',
                        ],
                        'icon' =>[
                            'title' =>__('Icon','codexse'),
                            'icon' =>'eicon-icon-box',
                        ],
                        'none' =>[
                            'title' =>__('None','codexse'),
                            'icon' =>'eicon-warning',
                        ],
                    ],
                    'default' => 'none',
                ]
            );

            $this->add_control(
                'button_img',
                [
                    'label' => __('Image','codexse'),
                    'type'=>Controls_Manager::MEDIA,
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                    'condition' => [
                        'button_icon_type' => 'img',
                    ]
                ]
            );

            $this->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name' => 'button_img_size',
                    'default' => 'large',
                    'separator' => 'none',
                    'condition' => [
                        'button_icon_type' => 'img',
                    ]
                ]
            );

            $this->add_control(
                'button_icon',
                [
                    'label'       => __( 'Icon', 'codexse' ),
                    'type'        => Controls_Manager::ICONS,
                    'label_block' => true,
                    'condition' => [
                        'button_icon_type' => 'icon',
                    ]
                ]
            );
        
            $this->add_responsive_control(
                'area_width',
                [
                    'label' => __( 'Width', 'codexse' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%', 'vw', 'vh', 'em' ],                                                                                               
                    'condition'=>[                                                                                                                                      
                        'slider_on'=>'yes',                                                                                                                             
                    ],       
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .swiper-wrapper' => 'width: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );  

            $this->add_responsive_control(
                'area_height',
                [
                    'label' => __( 'Height', 'codexse' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%', 'vw', 'vh', 'em' ],                                                                                               
                    'condition'=>[                                                                                                                                      
                        'slider_on'=>'yes',                                                                                                                             
                    ],       
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .swiper-wrapper' => 'height: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            
                                                                                                                                                                   
            $this->add_control(                                                                                                                                     
                'lax_scroll_active',                                                                                                                                    
                [                                                                                                                                                   
                    'label' => esc_html__( 'Lax Scroll', 'codexse' ),                                                                                                    
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
             
        $this->end_controls_section(); 
                                                                                                                                                               
        $this->start_controls_section(                                                                                                                              
            'slider_option',                                                                                                                                        
            [                                                                                                                                                       
                'label' => esc_html__( 'Slider Option', 'codexse' ),                                                                                                
                'condition'=>[                                                                                                                                      
                    'slider_on'=>'yes',                                                                                                                             
                ]                                                                                                                                                   
            ]                                                                                                                                                       
        );                                                                                                                                                          
            $this->add_control(                                                                                                                                     
                'sl_navigation',                                                                                                                                    
                [                                                                                                                                                   
                    'label' => esc_html__( 'Arrow', 'codexse' ),                                                                                                    
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slider_custom_arrow',                                                                                                                              
                [                                                                                                                                                   
                    'label' => esc_html__( 'Custom Arrow', 'codexse' ),                                                                                             
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                 'slider_target_id',                                                                                                                                
                 [                                                                                                                                                  
                     'label'     => __( 'Arrows ID', 'codexse' ),                                                                                                   
                     'type'      => Controls_Manager::TEXT,                                                                                                         
                     'title' => __( 'Take arrow id from "Custom Navigation" addons and paste here!', 'codexse' ),                                                   
                     'condition' => [                                                                                                                               
                        'slider_custom_arrow' => 'yes',                                                                                                            
                        'sl_navigation'=>'yes',                                                                                                                     
                     ]                                                                                                                                              
                 ]                                                                                                                                                  
             );                                                                                                                                                     
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sl_nav_prev_icon',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Previus Icon', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::ICON,                                                                                                               
                    'default' => 'fa fa-angle-left',                                                                                                                
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                        'slider_custom_arrow!'=>'yes',                                                                                                              
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sl_nav_next_icon',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Next Arrow', 'codexse' ),                                                                                                       
                    'type' => Controls_Manager::ICON,                                                                                                               
                    'default' => 'fa fa-angle-right',                                                                                                               
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                        'slider_custom_arrow!'=>'yes',                                                                                                              
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slpaginate',                                                                                                                                       
                [                                                                                                                                                   
                    'label' => esc_html__( 'Paginate', 'codexse' ),                                                                                                 
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sleffect',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Effect', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'slide',                                                                                                                           
                    'options' => [                                                                                                                                  
                        'slide'  => __( 'Slide', 'codexse' ),                                                                                                       
                        'fade'  => __( 'Fade', 'codexse' ),                                                                                                         
                        'cube'  => __( 'Cube', 'codexse' ),                                                                                                         
                        'coverflow'  => __( 'Coverflow', 'codexse' ),                                                                                               
                        'flip'  => __( 'Flip', 'codexse' ),                                                                                                         
                    ],                                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                     
            $this->add_control(                                                                                                                                     
                'sldirection',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Direction', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'horizontal',                                                                                                                           
                    'options' => [                                                                                                                                  
                        'horizontal'  => __( 'Horizontal', 'codexse' ),                                                                                                       
                        'vertical'  => __( 'Vertical', 'codexse' ),                                                                                                
                    ],                                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slloop',                                                                                                                                           
                [                                                                                                                                                   
                    'label' => esc_html__( 'Loop', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
            $this->add_control(                                                                                                                                     
                'slautolay',                                                                                                                                        
                [                                                                                                                                                   
                    'label' => esc_html__( 'Autoplay', 'codexse' ),                                                                                                 
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slautolaydelay',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Autoplay Delay', 'codexse'),                                                                                                     
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 6500,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slcenter',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Center', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sldisplay_columns',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 3,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slcenter_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slanimation_speed',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Slide Speed', 'codexse'),                                                                                                        
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 1000,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_laptop',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Laptop', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Laptop Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to laptop.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 1200,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 3,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_tablet',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Tablet', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Tablet Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to tablet.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 992,                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 2,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 768,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_mobile',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Mobile Phone', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Mobile Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to mobile.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 768,                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 4,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 1,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
        $this->end_controls_section();
        
        
        // blog Style tab section
        $this->start_controls_section(
            'box_style_section',
            [
                'label' => __( 'Single Card', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->start_controls_tabs('box_style_tab');
        $this->start_controls_tab( 'box_style_normal',
			[
				'label' => __( 'Normal', 'codexse' ),
			]
		);
        
        $this->add_responsive_control(
            'box_style_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .post-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'box_style_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .post-box .content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'box_style_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .post-box',
            ]
        );

        $this->add_responsive_control(
            'box_style_text_align',
            [
                'label' => __( 'Alignment', 'codexse' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'codexse' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'codexse' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'codexse' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'codexse' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .post-box' => 'text-align: {{VALUE}};',
                ],
                'default' => 'left',
                'separator' =>'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'box_style_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .post-box',
            ]
        );
        $this->add_responsive_control(
            'box_style_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .post-box' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_style_box_shadow',
                'label' => __( 'Box Shadow', 'codexse' ),
                'selector' => '{{WRAPPER}} .post-box',
            ]
        );

        
        $this->add_control(
			'box_style_box_transform',
			[
				'label' => __( 'Transform', 'codexse' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'translateY(0)',
				'selectors' => [
					'{{WRAPPER}} .post-box' => 'transform: {{VALUE}}',
				],
			]
		);
        
		$this->add_control(
			'box_style_transition',
			[
				'label' => __( 'Transition Duration', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0.3,
				],
				'range' => [
					'px' => [
						'max' => 3,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .post-box' => 'transition-duration: {{SIZE}}s',
				],
			]
		);        
             
		$this->add_responsive_control(
			'coumn_width',
			[
				'label' => __( 'Column Width', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],                
                'condition' =>[
                    'slider_on!' => 'yes',
                ],
				'selectors' => [
					'{{WRAPPER}} .post-gird-row .post-column' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		); 
		$this->end_controls_tab();

             
        // Hover Style tab Start
        $this->start_controls_tab(
            'box_style_hover',
            [
                'label' => __( 'Hover', 'codexse' ),
            ]
        );
                
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'box_style_hover_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .post-box:hover',
            ]
        );
        
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'box_style_border_hover',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .post-box:hover',
            ]
        );
        $this->add_responsive_control(
            'box_style_hover_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .post-box:hover' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_style_box_hover_shadow',
                'label' => __( 'Box Shadow', 'codexse' ),
                'selector' => '{{WRAPPER}} .post-box:hover',
            ]
        );
        $this->add_control(
			'box_style_hover_transform',
			[
				'label' => __( 'Transform', 'codexse' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'translateY(0)',
				'selectors' => [
					'{{WRAPPER}} .post-box:hover' => 'transform: {{VALUE}}',
				],
			]
		);
        
        $this->end_controls_tab(); // Hover Style tab end        
        $this->end_controls_tabs();// Box Style tabs end  
        $this->end_controls_section(); // blog Box section style end
        
        // blog Style tab section
        $this->start_controls_section(
            'box_thumbnail_section',
            [
                'label' => __( 'Thumbnail', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_thumb' => 'yes',
                ]
            ]
        );
        
        $this->start_controls_tabs('box_thumbnail_style_tab');
        
        $this->start_controls_tab( 'box_thumbnail_normal',
			[
				'label' => __( 'Normal', 'codexse' ),
			]
		);        
        
		$this->add_responsive_control(
			'thumbnail_width',
			[
				'label' => __( 'Width', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .post-box .post_media' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);        
		$this->add_responsive_control(
			'thumbnail_height',
			[
				'label' => __( 'Height', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .post-box .post_media' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'thumbnail_line_height',
			[
				'label' => __( 'Line Height', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .post-box .post_media' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);        
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'thumbnail_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .post-box .post_media',
            ]
        );
         $this->add_responsive_control(
            'thumbnail_floting',
            [
                'label' => __( 'Float Icon', 'codexse' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'codexse' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'none' => [
                        'title' => __( 'None', 'codexse' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'codexse' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .post-box .post_media' => 'float: {{VALUE}};',
                ],
                'default' => 'none',
                'separator' =>'before',
            ]
        );
                
        $this->add_responsive_control(
            'thumbnail_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .post-box .post_media' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'thumbnail_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .post-box .post_media' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'thumbnail_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .post-box .post_media',
            ]
        );
        $this->add_responsive_control(
            'thumbnail_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
                'selectors' => [
                    '{{WRAPPER}} .post-box .post_media' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'thumbnail_shadow',
                'label' => __( 'Box Shadow', 'codexse' ),
                'selector' => '{{WRAPPER}} .post-box .post_media',
            ]
        );        
        $this->add_control(
			'box_thumbnail_transition',
			[
				'label' => __( 'Transition Duration', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0.3,
				],
				'range' => [
					'px' => [
						'max' => 3,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .post-box .post_media' => 'transition-duration: {{SIZE}}s',
				],
			]
		);
        $this->end_controls_tab(); // Hover Style tab end
        $this->start_controls_tab( 'box_thumbnail_hover',
			[
				'label' => __( 'Hover', 'codexse' ),
			]
		);        
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'hover_thumbnail_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .post-box:hover .post_media',
            ]
        );               
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'hover_thumbnail_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .post-box:hover .post_media',
            ]
        );
        $this->add_responsive_control(
            'hover_thumbnail_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
                'selectors' => [
                    '{{WRAPPER}} .post-box:hover .post_media' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'hover_thumbnail_shadow',
                'label' => __( 'Box Shadow', 'codexse' ),
                'selector' => '{{WRAPPER}} .post-box:hover .post_media',
            ]
        );        
        
        $this->end_controls_tab(); // Hover Style tab end
        $this->end_controls_tabs();// Box Style tabs end  
        $this->end_controls_section();        
        
        
        $this->start_controls_section(
            'title_style_section',
            [
                'label' => __( 'Title', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition'=>[
                    'show_title'=>'yes',
                ]
            ]
        );
            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Color', 'codexse' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .post-box .title a' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'title_hover_color',
                [
                    'label' => __( 'Hover Color', 'codexse' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .post-box .title a:hover' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'title_typography',
                    'label' => __( 'Typography', 'codexse' ),
                    'selector' => '{{WRAPPER}} .post-box .title',
                ]
            );

            $this->add_responsive_control(
                'title_margin',
                [
                    'label' => __( 'Margin', 'codexse' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .post-box .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_padding',
                [
                    'label' => __( 'Padding', 'codexse' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .post-box .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section();
        
        $this->start_controls_section(
            'content_style_section',
            [
                'label' => __( 'Description', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition'=>[
                    'show_content'=>'yes',
                ]
            ]
        );
            $this->add_control(
                'content_color',
                [
                    'label' => __( 'Color', 'codexse' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .post-box .desc' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'content_typography',
                    'label' => __( 'Typography', 'codexse' ),
                    'selector' => '{{WRAPPER}} .post-box .desc',
                ]
            );

            $this->add_responsive_control(
                'content_margin',
                [
                    'label' => __( 'Margin', 'codexse' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .post-box .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'content_padding',
                [
                    'label' => __( 'Padding', 'codexse' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .post-box .desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section();
        
        $this->start_controls_section(
            'readmore_style_section',
            [
                'label' => __( 'Read More', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition'=>[
                    'show_button'=>'yes',
                ]
            ]
        );
            
            $this->start_controls_tabs('readmore_style_tabs');

                $this->start_controls_tab(
                    'readmore_style_normal_tab',
                    [
                        'label' => __( 'Normal', 'codexse' ),
                    ]
                );

                    $this->add_control(
                        'readmore_color',
                        [
                            'label' => __( 'Color', 'codexse' ),
                            'type' => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .post-box .content .read-more' => 'color: {{VALUE}}',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Typography::get_type(),
                        [
                            'name' => 'readmore_typography',
                            'label' => __( 'Typography', 'codexse' ),
                            'selector' => '{{WRAPPER}} .post-box .content .read-more',
                        ]
                    );

                    $this->add_responsive_control(
                        'readmore_margin',
                        [
                            'label' => __( 'Margin', 'codexse' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors' => [
                                '{{WRAPPER}} .post-box .content .read-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'readmore_padding',
                        [
                            'label' => __( 'Padding', 'codexse' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors' => [
                                '{{WRAPPER}} .post-box .content .read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Background::get_type(),
                        [
                            'name' => 'readmore_background',
                            'label' => __( 'Background', 'codexse' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .post-box .content .read-more',
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border::get_type(),
                        [
                            'name' => 'readmore_border',
                            'label' => __( 'Border', 'codexse' ),
                            'selector' => '{{WRAPPER}} .post-box .content .read-more',
                        ]
                    );

                    $this->add_responsive_control(
                        'readmore_border_radius',
                        [
                            'label' => esc_html__( 'Border Radius', 'codexse' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'selectors' => [
                                '{{WRAPPER}} .post-box .content .read-more' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                            ],
                        ]
                    );

                $this->end_controls_tab(); 

                $this->start_controls_tab(
                    'readmore_style_hover_tab',
                    [
                        'label' => __( 'Hover', 'codexse' ),
                    ]
                );
                    $this->add_control(
                        'readmore_hover_color',
                        [
                            'label' => __( 'Color', 'codexse' ),
                            'type' => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .post-box .content .read-more:hover' => 'color: {{VALUE}}',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Background::get_type(),
                        [
                            'name' => 'readmore_hover_background',
                            'label' => __( 'Background', 'codexse' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .post-box .content .read-more:hover',
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border::get_type(),
                        [
                            'name' => 'readmore_hover_border',
                            'label' => __( 'Border', 'codexse' ),
                            'selector' => '{{WRAPPER}} .post-box .content .read-more:hover',
                        ]
                    );

                    $this->add_responsive_control(
                        'readmore_hover_border_radius',
                        [
                            'label' => esc_html__( 'Border Radius', 'codexse' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'selectors' => [
                                '{{WRAPPER}} .post-box .content .read-more:hover' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                            ],
                        ]
                    );

                $this->end_controls_tab(); 

            $this->end_controls_tabs();

        $this->end_controls_section();
        
        
        // Style Slider arrow style start
        $this->start_controls_section(
            'slider_arrow_style',
            [
                'label'     => __( 'Arrow', 'codexse' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' =>[
                    'slider_on' => 'yes',
                    'sl_navigation'  => 'yes',
                ],
            ]
        );
        
            $this->start_controls_tabs( 'slider_arrow_style_tabs' );

                // Normal tab Start
                $this->start_controls_tab(
                    'slider_arrow_style_normal_tab',
                    [
                        'label' => __( 'Normal', 'codexse' ),
                    ]
                );

                    $this->add_control(
                        'slider_arrow_color',
                        [
                            'label' => __( 'Color', 'codexse' ),
                            'type' => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'color: {{VALUE}};',
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'slider_arrow_gap',
                        [
                            'label' => __( 'Arrow Gap', 'codexse' ),
                            'type' => Controls_Manager::SLIDER,
                            'size_units' => [ 'px' ],
                            'range' => [
                                'px' => [
                                    'min' => -100,
                                    'max' => 100,
                                    'step' => 1,
                                ]
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow.swiper-prev' => 'left: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow.swiper-next' => 'right: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_arrow_fontsize',
                        [
                            'label' => __( 'Font Size', 'codexse' ),
                            'type' => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 100,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'font-size: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Background::get_type(),
                        [
                            'name' => 'slider_arrow_background',
                            'label' => __( 'Background', 'codexse' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .swiper-navigation .swiper-arrow',
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border::get_type(),
                        [
                            'name' => 'slider_arrow_border',
                            'label' => __( 'Border', 'codexse' ),
                            'selector' => '{{WRAPPER}} .swiper-navigation .swiper-arrow',
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_border_radius',
                        [
                            'label' => esc_html__( 'Border Radius', 'codexse' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'selectors' => [
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_arrow_width',
                        [
                            'label' => __( 'Width', 'codexse' ),
                            'type' => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'width: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_arrow_height',
                        [
                            'label' => __( 'Height', 'codexse' ),
                            'type' => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_arrow_line_height',
                        [
                            'label' => __( 'Line Height', 'codexse' ),
                            'type' => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'line-height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_arrow_padding',
                        [
                            'label' => __( 'Padding', 'codexse' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                            'separator' =>'before',
                        ]
                    );

                $this->end_controls_tab(); // Normal tab end

                // Hover tab Start
                $this->start_controls_tab(
                    'slider_arrow_style_hover_tab',
                    [
                        'label' => __( 'Hover', 'codexse' ),
                    ]
                );

                    $this->add_control(
                        'slider_arrow_hover_color',
                        [
                            'label' => __( 'Color', 'codexse' ),
                            'type' => Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow:hover' => 'color: {{VALUE}};',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Background::get_type(),
                        [
                            'name' => 'slider_arrow_hover_background',
                            'label' => __( 'Background', 'codexse' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .swiper-navigation .swiper-arrow:hover',
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border::get_type(),
                        [
                            'name' => 'slider_arrow_hover_border',
                            'label' => __( 'Border', 'codexse' ),
                            'selector' => '{{WRAPPER}} .swiper-navigation .swiper-arrow:hover',
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_arrow_hover_border_radius',
                        [
                            'label' => esc_html__( 'Border Radius', 'codexse' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'selectors' => [
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow:hover' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                            ],
                        ]
                    );

                $this->end_controls_tab(); // Hover tab end

            $this->end_controls_tabs();

        $this->end_controls_section(); // Style Slider arrow style end

        // Style Pagination button tab section
        $this->start_controls_section(
            'post_slider_pagination_style_section',
            [
                'label' => __( 'Pagination', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition'=>[
                    'slider_on' => 'yes',
                    'slpaginate'=>'yes',
                ]
            ]
        );
            
            $this->start_controls_tabs('pagination_style_tabs');
            $this->add_responsive_control(
                'pagination_alignment',
                [
                    'label' => __( 'Alignment', 'codexse' ),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => __( 'Left', 'codexse' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => __( 'Center', 'codexse' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => __( 'Right', 'codexse' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .swiper-pagination-bullet' => 'text-align: {{VALUE}};'
                    ],
                    'separator' =>'before',
                ]
            );
                $this->start_controls_tab(
                    'pagination_style_normal_tab',
                    [
                        'label' => __( 'Normal', 'codexse' ),
                    ]
                );

                    $this->add_responsive_control(
                        'slider_pagination_height',
                        [
                            'label' => __( 'Height', 'codexse' ),
                            'type' => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_responsive_control(
                        'slider_pagination_width',
                        [
                            'label' => __( 'Width', 'codexse' ),
                            'type' => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Background::get_type(),
                        [
                            'name' => 'pagination_background',
                            'label' => __( 'Background', 'codexse' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .swiper-pagination-bullet',
                        ]
                    );

                    $this->add_responsive_control(
                        'pagination_margin',
                        [
                            'label' => __( 'Margin', 'codexse' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-pagination-bullet' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Border::get_type(),
                        [
                            'name' => 'pagination_border',
                            'label' => __( 'Border', 'codexse' ),
                            'selector' => '{{WRAPPER}} .swiper-pagination-bullet',
                        ]
                    );

                    $this->add_responsive_control(
                        'pagination_border_radius',
                        [
                            'label' => esc_html__( 'Border Radius', 'codexse' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'selectors' => [
                                '{{WRAPPER}} .swiper-pagination-bullet' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'pagination_opacity',
                        [
                            'label' => __( 'Opacity (%)', 'codexse' ),
                            'type' => Controls_Manager::SLIDER,
                            'default' => [
                                'size' => 0.1,
                            ],
                            'range' => [
                                'px' => [
                                    'max' => 1,
                                    'step' => 0.01,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-pagination-bullet' => 'opacity: {{SIZE}}',
                                
                            ],
                        ]
                    ); 
                $this->end_controls_tab(); // Normal Tab end

                $this->start_controls_tab(
                    'pagination_style_active_tab',
                    [
                        'label' => __( 'Active', 'codexse' ),
                    ]
                );
                    
                    $this->add_group_control(
                        Group_Control_Background::get_type(),
                        [
                            'name' => 'pagination_hover_background',
                            'label' => __( 'Background', 'codexse' ),
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .swiper-pagination-bullet:hover, {{WRAPPER}} .swiper-pagination-bullet.swiper-pagination-bullet-active',
                        ]
                    );
                    $this->add_responsive_control(
                        'slider_pagination_active_width',
                        [
                            'label' => __( 'Width', 'codexse' ),
                            'type' => Controls_Manager::SLIDER,
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                    'step' => 1,
                                ],
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'width: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                    );
                    $this->add_responsive_control(
                        'pagination_active_opacity',
                        [
                            'label' => __( 'Opacity (%)', 'codexse' ),
                            'type' => Controls_Manager::SLIDER,
                            'default' => [
                                'size' => 1,
                            ],
                            'range' => [
                                'px' => [
                                    'max' => 1,
                                    'step' => 0.01,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'opacity: {{SIZE}}',
                                
                            ],
                        ]
                    ); 

                $this->end_controls_tab(); // Hover Tab end
            $this->end_controls_tabs();
        $this->end_controls_section();
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function render( $instance = [] ) {
        $column = $button_icon = $data = '';
        $settings = $this->get_settings_for_display();

        
        $custom_order_ck    = $this->get_settings_for_display('custom_order');
        $orderby            = $this->get_settings_for_display('orderby');
        $postorder          = $this->get_settings_for_display('postorder');
        
        // Query
        $args = array(
            'post_type'             => 'portfolio',
            'post_status'           => 'publish',
            'post__in'              => $settings['title_list'],
            'ignore_sticky_posts'   => 1,
            'posts_per_page'        => !empty( $settings['post_limit'] ) ? $settings['post_limit'] : 3,
            'order'                 => $postorder
        );
        // Custom Order
        if( $custom_order_ck == 'yes' ){
            $args['orderby']    = $orderby;
        }
        if( !empty($settings['post_categories']) ){
            $get_categories = $settings['post_categories'];
        }else{
            $get_categories = '';
        }        
        $post_cats = str_replace(' ', '', $get_categories);
        if (  !empty( $get_categories ) ) {
            if( is_array($post_cats) and count($post_cats) > 0 ){
                $field_name = is_numeric( $post_cats[0] ) ? 'term_id' : 'slug';
                $args['tax_query'] = array(
                    array(
                        'taxonomy' => 'category',
                        'terms' => $post_cats,
                        'field' => $field_name,
                        'include_children' => false
                    )
                );
            }
        }
        $post = new \WP_Query( $args );

        if($settings['lax_scroll_active'] == 'yes'){
            $this->add_render_attribute( 'wrapper_attributes', 'data-lax-preset', 'blurIn fadeIn zoomIn' );
            $this->add_render_attribute( 'wrapper_attributes', 'class', 'lax' );
        }

        if( $settings['slider_on'] == 'yes' ){                                                                                                                      
            $this->add_render_attribute( 'wrapper_attributes', 'class', 'swiper-container' );                                                                       
            $slider_settings = [                                                                                                                                    
                'sleffect' => $settings['sleffect'],                                                                                                                
                'sldirection' => $settings['sldirection'],                                                                                                                
                'slloop' => ('yes' === $settings['slloop']),                                                                                                        
                'slautolay' => ('yes' === $settings['slautolay']),                                                                                                  
                'slautolaydelay' => absint($settings['slautolaydelay']),                                                                                            
                'slanimation_speed' => absint($settings['slanimation_speed']),                                                                                      
                'slcustom_arrow' => ('yes' === $settings['slider_custom_arrow']),                                                                                   
                'sltarget_id' => $settings['slider_target_id'],                                                                                                     
                'sldisplay_columns' => $settings['sldisplay_columns'],                                                                                              
                'slcenter' => ('yes' === $settings['slcenter']),                                                                                                    
                'slcenter_padding' => $settings['slcenter_padding'],                                                                                                
            ];                                                                                                                                                      
            $slider_responsive_settings = [                                                                                                                         
                'laptop_width' => $settings['sllaptop_width'],                                                                                                      
                'laptop_padding' => $settings['sllaptop_padding'],                                                                                                  
                'laptop_display_columns' => $settings['sllaptop_display_columns'],                                                                                  
                'tablet_width' => $settings['sltablet_width'],                                                                                                      
                'tablet_padding' => $settings['sltablet_padding'],                                                                                                  
                'tablet_display_columns' => $settings['sltablet_display_columns'],                                                                                  
                'mobile_width' => $settings['slmobile_width'],                                                                                                      
                'mobile_padding' => $settings['slmobile_padding'],                                                                                                  
                'mobile_display_columns' => $settings['slmobile_display_columns'],                                                                                  
            ];                                                                                                                                                      
            $slider_settings = array_merge( $slider_settings, $slider_responsive_settings );                                                                        
            $this->add_render_attribute( 'wrapper_attributes', 'data-settings', wp_json_encode( $slider_settings ) );                                               
        }else {
            $this->add_render_attribute( 'wrapper_attributes', 'class', ['row g-3 g-md-4', esc_attr($settings['grid_space'])] );
            if($settings['masonry'] == 'yes'){
                $this->add_render_attribute( 'wrapper_attributes', 'class', 'masonrys' );
            }
            switch ($settings['item_column']) {
                case "1grid":
                    $column = "col-lg-12";
                    break;
                case "2grid":
                    $column = "col-lg-6 col-md-12";
                    break;
                case "3grid":
                    $column = "col-4";
                    break;
                default:
                    $column = "col-xl-3 col-lg-4 col-md-6";
            }
        }
        
        $this->add_render_attribute( 'wrapper_attributes', 'class', $settings['post_style'] );
        
        if($post->have_posts()){
            echo '<div '.$this->get_render_attribute_string( "wrapper_attributes" ).' >';                                                                               
            if($settings['slider_on'] == 'yes'){
                echo '<div class="swiper-wrapper">';                                                                                                                        
                    while ( $post->have_posts() ) {
                        $post->the_post();        
                        echo '<div class="swiper-slide">';
                            echo '<div class="portfolio-addon-item">';
                                if ( has_post_thumbnail() && $settings['show_thumb'] == true) {
                                    echo '<figure class="thumb">';
                                    echo '<a href="'.get_the_permalink().'">'.get_the_post_thumbnail('', $settings['thumbnail_size']).'</a>';
                                    echo '</figure>';
                                }
                                echo '<div class="content">';
                                    if($settings['show_title'] == 'yes'){
                                        echo '<h3 class="title"><a href="'.get_the_permalink().'">'. wp_trim_words( get_the_title(), $settings['title_length'], ' ' ).'</a></h3>';
                                    }         
                                    if($settings['show_content'] == 'yes'){
                                        echo '<div class="excerpt">'.wpautop(wp_trim_words( get_the_content(), $settings['content_length'], ' ' )).'</div>';
                                    }                               
                                    if( $settings['show_button'] == 'yes' ):
                                        if( $settings['button_icon_type'] == 'img' and !empty(Group_Control_Image_Size::get_attachment_image_html( $settings, 'button_img', 'button_img_size' )) ){
                                            $button_icon = '<div class="icon">'.Group_Control_Image_Size::get_attachment_image_html( $settings, 'button_img', 'button_img_size' ).'</div>';
                                        }elseif( $settings['button_icon_type'] == 'icon' && !empty($settings['button_icon']['value']) ){
                                            $button_icon = sprintf( '<div class="icon" >%1$s</div>', Codexse_Icon_manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ) );
                                        }
                                        echo '<a class="read-more" href="'.get_the_permalink().'">'.$settings['button_text'].$button_icon.'</a>';
                                    endif;   
                                echo '</div>';
                            echo '</div>';                        
                        echo '</div>';                        
                    }
                    wp_reset_postdata();                                                                                                                                        
                echo '</div>';                                                                                                                                              
                if( $settings['sl_navigation'] == true && $settings['slider_custom_arrow'] != true ){                                                                       
                    echo '<div class="swiper-navigation" >';                                                                                                                
                        echo '<div class="swiper-arrow swiper-prev"><i class="'.esc_attr($settings['sl_nav_prev_icon']).'" ></i></div>';                                    
                        echo '<div class="swiper-arrow swiper-next"><i class="'.esc_attr($settings['sl_nav_next_icon']).'" ></i></div>';                                    
                    echo '</div>';                                                                                                                                          
                }                                                                                                                                                           
                if( $settings['slpaginate'] == true ){                                                                                                                      
                    echo '<div class="swiper-pagination"></div>';                                                                                                           
                }           
            }else {                                                                                        
                while ( $post->have_posts() ) {
                    $post->the_post();        
                    echo '<div class="'.$column.'">';   
                        echo '<div class="portfolio-addon-item">';
                            if ( has_post_thumbnail() && $settings['show_thumb'] == true) {
                                echo '<figure class="thumb">';
                                    echo '<a href="'.get_the_permalink().'">'.get_the_post_thumbnail('', $settings['thumbnail_size']).'</a>';
                                echo '</figure>';
                            }
                            echo '<div class="content">';
                                if($settings['show_title'] == 'yes'){
                                    echo '<h3 class="title"><a href="'.get_the_permalink().'">'. wp_trim_words( get_the_title(), $settings['title_length'], ' ' ).'</a></h3>';
                                }         
                                if($settings['show_content'] == 'yes'){
                                    echo '<div class="excerpt">'.wpautop(wp_trim_words( get_the_content(), $settings['content_length'], ' ' )).'</div>';
                                }                               
                                if( $settings['show_button'] == 'yes' ):
                                    if( $settings['button_icon_type'] == 'img' and !empty(Group_Control_Image_Size::get_attachment_image_html( $settings, 'button_img', 'button_img_size' )) ){
                                        $button_icon = '<div class="icon">'.Group_Control_Image_Size::get_attachment_image_html( $settings, 'button_img', 'button_img_size' ).'</div>';
                                    }elseif( $settings['button_icon_type'] == 'icon' && !empty($settings['button_icon']['value']) ){
                                        $button_icon = sprintf( '<div class="icon" >%1$s</div>', Codexse_Icon_manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ) );
                                    }
                                    echo '<a class="read-more" href="'.get_the_permalink().'">'.$settings['button_text'].$button_icon.'</a>';
                                endif;   
                            echo '</div>';                        
                        echo '</div>';                        
                    echo '</div>';                        
                }
            }            
        echo '</div>';
        }else {
            get_template_part( 'components/post-formats/post', 'none' );
        }    
    }                                                                                                                                                               
                                                                                                                                                                    
}