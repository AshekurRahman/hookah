<?php                                                                                                                                                               
namespace Elementor;                                                                                                                                                
                                                                                                                                                                    
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly                                                                                                    
                                                                                                                                                                    
class Codexse_Elementor_Widget_Testimonial extends Widget_Base {                                                                                                       
                                                                                                                                                                    
    public function get_name() {                                                                                                                                    
        return 'codexse-testimonial-addons';                                                                                                                           
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_title() {                                                                                                                                   
        return __( 'Testimonial', 'codexse' );                                                                                                                  
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_icon() {                                                                                                                                    
        return 'codexse-icon eicon-testimonial-carousel';                                                                                                                    
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_categories(){
        return ["codexse-addons"];
    }                                                                                                                                                           
                                                                                                                                                                    
    public function get_style_depends() {                                                                                                                           
        return [                                                                                                                                                    
            'swiper',                                                                                                                                        
            'codexse-carousel',
            'codexse-testimonial'                                                                                                                
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_script_depends() {                                                                                                                          
        return [                                                                                                                                                    
            'swiper-slider',                                                                                                                                        
            'codexse-carousel',                                                                                                                                     
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function register_controls() {                                                                                                                        
                                                                                                                                                                    
        $this->start_controls_section(                                                                                                                              
            'testimonial_content',                                                                                                                                      
            [                                                                                                                                                       
                'label' => __( 'Testimonial', 'codexse' ),                                                                                                      
            ]                                                                                                                                                       
        );                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'boxstyle',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Style', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'style1',                                                                                                                           
                    'options' => [                                                                                                                                  
                        'style1'  => __( 'Style 1', 'codexse' ),                                                                                                       
                        'style2'  => __( 'Style 2', 'codexse' ),                                                                                                       
                        'style3'  => __( 'Style 3', 'codexse' ),                                                                                                       
                        'style4'  => __( 'Style 4', 'codexse' ),                                                                                                       
                        'style5'  => __( 'Style 5', 'codexse' ),                                                                                                       
                        'style6'  => __( 'Style 6', 'codexse' ),                                                                                                       
                    ],                                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                         
                                                                                                                                                                    
            $repeater = new Repeater();           
            
            $repeater->add_control(                                                                                                                                 
                'testimonial_description',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Description', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXTAREA,                                                                                                            
                    'placeholder' => __('Enter type your client feedback massage.','codexse'),                                                                                      
                ]                                                                                                                                                   
            );                                                                                                                       
            $repeater->add_control(                                                                                                                                 
                'testimonial_name',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Name', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXT,                                                                                                            
                    'placeholder' => __('Enter type your client name.','codexse'),                                                                                      
                ]                                                                                                                                                   
            );                                                                                                                       
            $repeater->add_control(                                                                                                                                 
                'testimonial_position',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Position', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXT,                                                                                                            
                    'placeholder' => __('Enter type your client position.','codexse'),                                                                                      
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $repeater->add_control(                                                                                                                                 
                'testimonial_image',                                                                                                                                    
                [                                                                                                                                                   
                    'label' => __( 'Image', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::MEDIA,                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $repeater->add_group_control(                                                                                                                           
                Group_Control_Image_Size::get_type(),                                                                                                               
                [                                                                                                                                                   
                    'name' => 'testimonial_imagesize',                                                                                                                  
                    'default' => 'large',                                                                                                                           
                    'separator' => 'none',                                                                                                                          
                ]                                                                                                                                                   
            );  
            
            $repeater->add_control(
                "rating_switch", 
                [
                    "label" => __("Show rating star", "codexse"),
                    "type" => Controls_Manager::SWITCHER,
                    "default" => "no",
                    "label_on" => __("Show", "codexse"),
                    "label_off" => __("Hide", "codexse"),
                ]
            );

            $repeater->add_control(
                "rating", 
                [
                    "label" => __("Rating", "codexse"),
                    "type" => Controls_Manager::SLIDER,
                    "default" => ["size" => 3],
                    "range" => ["px" => ["max" => 5, "step" => 0.1]],
                    "condition" => ["rating_switch" => "yes"],
                ]
            );                                                                                                              
            $repeater->add_control(                                                                                                                                 
                'testimonial_interval',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Time intervals', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXT,                                                                                                            
                    'placeholder' => __('Enter type your rating intervals.','codexse'),    
                    "condition" => ["rating_switch" => "yes"],                                                                                  
                ]                                                                                                                                                   
            ); 
                                                                                                                                                                               
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'testimonial_list',                                                                                                                               
                [                                                                                                                                                   
                    'type'    => Controls_Manager::REPEATER,                                                                                                        
                    'fields'  => $repeater->get_controls(),                                                                                                         
                    'default' => [                                                                                                                                  
                                                                                                                                                                    
                        [                                                                                                                                           
                            'testimonial_description'        => __('All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over words, combined with a handful of model sentence structures, to generate which looks reasonable.','codexse'),                                                                   
                            'testimonial_name'        => __('Helena Paitora','codexse'),                                                                   
                            'testimonial_position'        => __('Digital Marketer','codexse'),                                                                
                        ],                                                                                                                              
                        [                                                                                                                                           
                            'testimonial_description'        => __('All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over words, combined with a handful of model sentence structures, to generate which looks reasonable.','codexse'),                                                                   
                            'testimonial_name'        => __('Jason Kink','codexse'),                                                                   
                            'testimonial_position'        => __('Digital Marketer','codexse'),                                                                
                        ],                                                                                                                              
                        [                                                                                                                                           
                            'testimonial_description'        => __('All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over words, combined with a handful of model sentence structures, to generate which looks reasonable.','codexse'),                                                                   
                            'testimonial_name'        => __('Irfan Raza','codexse'),                                                                   
                            'testimonial_position'        => __('Digital Marketer','codexse'),                                                                
                        ],                                                                                                                                          
                                                                                                                                                                    
                    ],                                                                                                                                              
                    'title_field' => '{{{ testimonial_name }}}',                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                         
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slider_on',                                                                                                                                        
                [                                                                                                                                                   
                    'label'         => __( 'Slider', 'codexse' ),                                                                                            
                    'type'          => Controls_Manager::SWITCHER,                                                                                                  
                    'label_on'      => __( 'On', 'codexse' ),                                                                                                
                    'label_off'     => __( 'Off', 'codexse' ),                                                                                               
                    'return_value'  => 'yes',                                                                                                                       
                    'default'       => 'yes',                                                                                                                       
                ]                                                                                                                                                   
            );        
            
            
        
            $this->add_control(
                'item_column',
                [
                    'label' => __( 'Column', 'codexse' ),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        '1grid' => [
                            'title' => __( 'One Column', 'codexse' ),
                            'icon' => 'icon-grid-1',
                        ],
                        '2grid' => [
                            'title' => __( 'Two Columns', 'codexse' ),
                            'icon' => 'icon-grid-2',
                        ],
                        '3grid' => [
                            'title' => __( 'Three Columns', 'codexse' ),
                            'icon' => 'icon-grid-3',
                        ],
                        '4grid' => [
                            'title' => __( 'Four Columns', 'codexse' ),
                            'icon' => 'icon-grid-4',
                        ],
                    ],
                    'default' => '3grid',
                    'toggle' => true,
                    'condition' => [
                        'slider_on!' => 'yes',
                    ]
                ]
            );
        
            $this->add_control(
                'grid_space',
                [
                    'label' => esc_html__( 'Grid Space', 'codexse' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'g-4',
                    'options' => [
                        'g-1'  => __( 'One', 'codexse' ),
                        'g-2'  => __( 'Two', 'codexse' ),
                        'g-3'  => __( 'Three', 'codexse' ),
                        'g-4'  => __( 'Four', 'codexse' ),
                        'g-5'  => __( 'Five', 'codexse' ),
                    ],
                    'condition' => [
                        'slider_on!' => 'yes',
                    ]
                ]
            );

            $this->add_control(
                'masonry',
                [
                    'label'         => __( 'Masonry', 'codexse' ),
                    'type'          => Controls_Manager::SWITCHER,
                    'label_on'      => __( 'On', 'codexse' ),
                    'label_off'     => __( 'Off', 'codexse' ),
                    'return_value'  => 'yes',
                    'default'       => 'no',
                    'condition' => [
                        'slider_on!' => 'yes',
                    ]
                ]
            );

                                                                                                                                                                    
        $this->end_controls_section();                                                                                                                              
                                                                                                                                                                    
        $this->start_controls_section(                                                                                                                              
            'slider_option',                                                                                                                                        
            [                                                                                                                                                       
                'label' => esc_html__( 'Slider Option', 'codexse' ),                                                                                                
                'condition'=>[                                                                                                                                      
                    'slider_on'=>'yes',                                                                                                                             
                ]                                                                                                                                                   
            ]                                                                                                                                                       
        );                                                                                                                                                          
            $this->add_control(                                                                                                                                     
                'sl_navigation',                                                                                                                                    
                [                                                                                                                                                   
                    'label' => esc_html__( 'Arrow', 'codexse' ),                                                                                                    
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slider_custom_arrow',                                                                                                                              
                [                                                                                                                                                   
                    'label' => esc_html__( 'Custom Arrow', 'codexse' ),                                                                                             
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                 'slider_target_id',                                                                                                                                
                 [                                                                                                                                                  
                     'label'     => __( 'Arrows ID', 'codexse' ),                                                                                                   
                     'type'      => Controls_Manager::TEXT,                                                                                                         
                     'title' => __( 'Take arrow id from "Custom Navigation" addons and paste here!', 'codexse' ),                                                   
                     'condition' => [                                                                                                                               
                        'slider_custom_arrow' => 'yes',                                                                                                            
                        'sl_navigation'=>'yes',                                                                                                                     
                     ]                                                                                                                                              
                 ]                                                                                                                                                  
             );                                                                                                                                                     
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sl_nav_prev_icon',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Previus Icon', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::ICON,                                                                                                               
                    'default' => 'fa fa-angle-left',                                                                                                                
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                        'slider_custom_arrow!'=>'yes',                                                                                                              
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sl_nav_next_icon',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Next Arrow', 'codexse' ),                                                                                                       
                    'type' => Controls_Manager::ICON,                                                                                                               
                    'default' => 'fa fa-angle-right',                                                                                                               
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                        'slider_custom_arrow!'=>'yes',                                                                                                              
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slpaginate',                                                                                                                                       
                [                                                                                                                                                   
                    'label' => esc_html__( 'Paginate', 'codexse' ),                                                                                                 
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sleffect',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Effect', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'slide',                                                                                                                           
                    'options' => [                                                                                                                                  
                        'slide'  => __( 'Slide', 'codexse' ),                                                                                                       
                        'fade'  => __( 'Fade', 'codexse' ),                                                                                                         
                        'cube'  => __( 'Cube', 'codexse' ),                                                                                                         
                        'coverflow'  => __( 'Coverflow', 'codexse' ),                                                                                               
                        'flip'  => __( 'Flip', 'codexse' ),                                                                                                         
                    ],                                                                                                                                              
                ]                                                                                                                                                   
            );   

            $this->add_control(                                                                                                                                     
                'coverflow_option_heading',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Coverflow Options', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'before',   
                    'condition' => [
                        'sleffect' => 'coverflow',
                    ]                                                                                                                      
                ]                                                                                                                                                   
            );            
                                                                                                                                                                                
            $this->add_control(                                                                                                                                     
                'coverflow_rotate',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Rotate', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 360,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 0,      
                    'condition' => [
                        'sleffect' => 'coverflow',
                    ]                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                                                   
            $this->add_control(                                                                                                                                     
                'coverflow_stretch',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Stretch', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 9999,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 0,      
                    'condition' => [
                        'sleffect' => 'coverflow',
                    ]                                                                                                                                 
                ]                                                                                                                                                   
            );              
                                                                                                                                                                     
            $this->add_control(                                                                                                                                     
                'coverflow_depth',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Depth', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 9999,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 0,      
                    'condition' => [
                        'sleffect' => 'coverflow',
                    ],                                                                                                                                          
                ]                                                                                                                                                   
            );                                                                                                                                                                  
            $this->add_control(                                                                                                                                     
                'coverflow_shadow',                                                                                                                                           
                [                                                                                                                                                   
                    'label' => esc_html__( 'Shadow', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                   
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slloop',                                                                                                                                           
                [                                                                                                                                                   
                    'label' => esc_html__( 'Loop', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );  

            $this->add_control(                                                                                                                                     
                'slautolay',                                                                                                                                        
                [                                                                                                                                                   
                    'label' => esc_html__( 'Autoplay', 'codexse' ),                                                                                                 
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slautolaydelay',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Autoplay Delay', 'codexse'),                                                                                                     
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 6500,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slcenter',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Center', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sldisplay_columns',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 1,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slcenter_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slanimation_speed',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Slide Speed', 'codexse'),                                                                                                        
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 1000,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                   
            $this->add_control(                                                                                                                                     
                'sldirection',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Direction', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'horizontal',                                                                                                                           
                    'options' => [                                                                                                                                  
                        'horizontal'  => __( 'horizontal', 'codexse' ),                                                                                                       
                        'vertical'  => __( 'vertical', 'codexse' ),                                                                                                       
                    ],                                                                                                                                              
                ]                                                                                                                                                   
            );        
        
            $this->add_responsive_control(
                'slider_height',
                [
                    'label' => __( 'Height', 'codexse' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%', 'vh', 'vw' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                        'vh' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                        'vw' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .swiper-container' => 'height: {{SIZE}}{{UNIT}};',
                    ],
                    'condition' => [
                        'sldirection' => 'vertical',
                    ]
                ]
            );                                                                                                                                                  
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_laptop',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Laptop', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Laptop Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to laptop.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 1200,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 3,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_tablet',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Tablet', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Tablet Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to tablet.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 992,                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 2,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 768,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_mobile',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Mobile Phone', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Mobile Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to mobile.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 768,                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 4,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 1,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );
                                                                                                                                                                   
            $this->add_control(
                'image_pagination_sw',
                [
                    'label' => esc_html__( 'Image Pagination', 'codexse' ),
                    'type' => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );
            
            $this->add_control(
                'image_pagination_id',
                [
                    'label'     => __( 'Pagination ID', 'codexse' ),
                    'type'      => Controls_Manager::TEXT,
                    'default'   => rand(),
                    'title'     => __( 'Extract the arrow ID from this location and insert it into an HTML code addon "<div id="id_name_here"></div>"', 'codexse' ),
                    'condition' => [
                        'image_pagination_sw' => 'yes',
                    ]
                ]
            );
                                                                                                                                                             
                 
        $this->end_controls_section();                                                                                                                              
                                                                                                                                                                    

        // Feature Style tab section
        $this->start_controls_section(
            'codexse_testimonial_style_section',
            [
                'label' => __( 'Single Item', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->start_controls_tabs('testimonial_item_style_tab');
        $this->start_controls_tab( 'testimonial_item_normal',
			[
				'label' => __( 'Normal', 'codexse' ),
			]
		);
        
        $this->add_responsive_control(
            'testimonial_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'testimonial_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'testimonial_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .testimonial-item',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'testimonial_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item',
            ]
        );
        $this->add_responsive_control(
            'testimonial_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item, {{WRAPPER}} .testimonial-item:before,{{WRAPPER}} .testimonial-item:after' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'testimonial_item_shadow',
                'label' => __( 'Box Shadow', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item',
            ]
        );

        
        $this->add_control(
			'testimonial_item_transform',
			[
				'label' => __( 'Transform', 'codexse' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'translateY(0)',
				'selectors' => [
					'{{WRAPPER}} .testimonial-item' => 'transform: {{VALUE}}',
				],
			]
		);
        
		$this->add_control(
			'testimonial_item_transition',
			[
				'label' => __( 'Transition Duration', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0.3,
				],
				'range' => [
					'px' => [
						'max' => 3,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item' => 'transition-duration: {{SIZE}}s',
				],
			]
		);
		$this->end_controls_tab();

             
        // Hover Style tab Start
        $this->start_controls_tab(
            'testimonial_item_hover',
            [
                'label' => __( 'Hover', 'codexse' ),
            ]
        );
        
        
              
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'testimonial_hover_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .testimonial-item:hover',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'testimonial_border_hover',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item:hover',
            ]
        );
        $this->add_responsive_control(
            'testimonial_hover_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item:hover' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'testimonial_item_hover_shadow',
                'label' => __( 'Box Shadow', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item:hover',
            ]
        );
        $this->add_control(
			'testimonial_item_hover_transform',
			[
				'label' => __( 'Transform', 'codexse' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'translateY(0)',
				'selectors' => [
					'{{WRAPPER}} .testimonial-item:hover' => 'transform: {{VALUE}}',
				],
			]
		);

        $this->add_responsive_control(
            'testimonial_hover_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->end_controls_tab(); // Hover Style tab end        
        $this->end_controls_tabs();// Box Style tabs end  
        $this->end_controls_section(); // Feature Box section style end
                                       
        
        
        // Icon Box Style tab section
        $this->start_controls_section(
            'box_content_section',
            [
                'label' => __( 'Description', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs('box_content_style_tab');
        
        $this->start_controls_tab( 'box_content_normal',
			[
				'label' => __( 'Normal', 'codexse' ),
			]
		);        
        
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'icon_box_content_typography',
                'selector' => '{{WRAPPER}} .testimonial-item .description',
            ]
        );
        $this->add_control(
            'content_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .description' => 'color: {{VALUE}};',
                ],
            ]
        );
                
        $this->add_responsive_control(
            'content_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
		$this->add_control(
			'icon_box_content_transition',
			[
				'label' => __( 'Transition Duration', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0.3,
				],
				'range' => [
					'px' => [
						'max' => 3,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .description' => 'transition-duration: {{SIZE}}s',
				],
			]
		);
        
        $this->end_controls_tab(); // Hover Style tab end
         
        $this->start_controls_tab( 'content_hover_tab',
			[
				'label' => __( 'Hover', 'codexse' ),
			]
		);        
        
        $this->add_control(
            'content_hover_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .description:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_tab(); // Hover Style tab end
        $this->start_controls_tab( 'box_content_hover_tab',
			[
				'label' => __( 'Box Hover', 'codexse' ),
			]
		);        
        
        $this->add_control(
            'box_hover_content_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item:hover .description' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_tab(); // Hover Style tab end
        $this->end_controls_tabs();// Box Style tabs end 
        
        
        
        $this->start_controls_tabs('description_before_after_tabs');
        
        $this->start_controls_tab( 'description_before_tab',
			[
				'label' => __( 'Before', 'codexse' ),
			]
		);        
        $this->add_control(
            'before_icon_type',
            [
                'label' => __('Icon Type','codexse'),
                'type' =>Controls_Manager::CHOOSE,
                'options' =>[
                    'img' =>[
                        'title' =>__('Image','codexse'),
                        'icon' =>'eicon-image-bold',
                    ],
                    'icon' =>[
                        'title' =>__('Icon','codexse'),
                        'icon' =>'eicon-icon-box',
                    ],
                    'text' =>[
                        'title' =>__('Text','codexse'),
                        'icon' =>'eicon-animation-text',
                    ],
                ],
                'default' => 'icon',
            ]
        );

        $this->add_control(
            'before_image',
            [
                'label' => __('Image','codexse'),
                'type'=>Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'before_icon_type' => 'img',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'before_image_size',
                'default' => 'large',
                'separator' => 'none',
                'condition' => [
                    'before_icon_type' => 'img',
                ]
            ]
        );

        $this->add_control(
            'before_font_icon',
            [
                'label'       => __( 'Icon', 'codexse' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => true,
                'condition' => [
                    'before_icon_type' => 'icon',
                ]
            ]
        );

        $this->add_control(
            'before_text_icon',
            [
                'label' => __( 'Text', 'codexse' ),
                'type'=>Controls_Manager::TEXT,
				'default' => __( '"','codexse' ),
				'condition' => [
					'before_icon_type' => 'text'
				]
            ]
        );


		$this->add_responsive_control(
			'before_icon_width',
			[
				'label' => __( 'Width', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .before-icon' => 'width: {{SIZE}}{{UNIT}};min-width: {{SIZE}}{{UNIT}};',
				],
			]
		);        
        
		$this->add_responsive_control(
			'before_icon_height',
			[
				'label' => __( 'Height', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .before-icon' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'before_icon_line_height',
			[
				'label' => __( 'Line Height', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .before-icon' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        
        $this->add_responsive_control(
            'before_icon_size',
            [
                'label' => __( 'Size', 'codexse' ),
                'type'  => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .before-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],           
                'condition' => [
                    'icon_type!' => 'text',
                ]
            ]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'before_icon_typography',
                'selector' => '{{WRAPPER}} .testimonial-item .before-icon',                
                'condition' => [
                    'icon_type' => 'text',
                ]
            ]
        );
        
        $this->add_control(
            'before_icon_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .before-icon' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'before_icon_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .testimonial-item .before-icon',
            ]
        );        
        $this->add_responsive_control(
            'before_font_size',
            [
                'label' => __( 'Size', 'codexse' ),
                'type'  => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .before-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],           
                'condition' => [
                    'before_icon_type!' => 'img',
                ]
            ]
        );
         $this->add_responsive_control(
            'before_icon_floting',
            [
                'label' => __( 'Float', 'codexse' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'codexse' ),
                        'icon' => 'eicon-arrow-left',
                    ],
                    'none; display: block' => [
                        'title' => __( 'None', 'codexse' ),
                        'icon' => 'eicon-arrow-up',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'codexse' ),
                        'icon' => 'eicon-arrow-right',
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .before-icon' => 'float: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'before_icon_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .before-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'before_icon_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .before-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'before_icon_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item .before-icon',
            ]
        );
        $this->add_responsive_control(
            'before_icon_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .before-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'before_icon_shadow',
                'label' => __( 'Box Shadow', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item .before-icon',
            ]
        );
        
        $this->end_controls_tab(); // Hover Style tab end
        $this->start_controls_tab( 'description_after_tab',
			[
				'label' => __( 'After', 'codexse' ),
			]
		);             
        $this->add_control(
            'after_icon_type',
            [
                'label' => __('Icon Type','codexse'),
                'type' =>Controls_Manager::CHOOSE,
                'options' =>[
                    'img' =>[
                        'title' =>__('Image','codexse'),
                        'icon' =>'eicon-image-bold',
                    ],
                    'icon' =>[
                        'title' =>__('Icon','codexse'),
                        'icon' =>'eicon-icon-box',
                    ],
                    'text' =>[
                        'title' =>__('Text','codexse'),
                        'icon' =>'eicon-animation-text',
                    ],
                ],
                'default' => 'icon',
            ]
        );

        $this->add_control(
            'after_image',
            [
                'label' => __('Image','codexse'),
                'type'=>Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'after_icon_type' => 'img',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'after_image_size',
                'default' => 'large',
                'separator' => 'none',
                'condition' => [
                    'after_icon_type' => 'img',
                ]
            ]
        );

        $this->add_control(
            'after_font_icon',
            [
                'label'       => __( 'Icon', 'codexse' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => true,
                'condition' => [
                    'after_icon_type' => 'icon',
                ]
            ]
        );

        $this->add_control(
            'after_text_icon',
            [
                'label' => __( 'Text', 'codexse' ),
                'type'=>Controls_Manager::TEXT,
				'default' => __( '"','codexse' ),
				'condition' => [
					'after_icon_type' => 'text'
				]
            ]
        );


		$this->add_responsive_control(
			'after_icon_width',
			[
				'label' => __( 'Width', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .after-icon' => 'width: {{SIZE}}{{UNIT}};min-width: {{SIZE}}{{UNIT}};',
				],
			]
		);        
        
		$this->add_responsive_control(
			'after_icon_height',
			[
				'label' => __( 'Height', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .after-icon' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'after_icon_line_height',
			[
				'label' => __( 'Line Height', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .after-icon' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        
        $this->add_responsive_control(
            'after_icon_size',
            [
                'label' => __( 'Size', 'codexse' ),
                'type'  => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .after-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],           
                'condition' => [
                    'icon_type!' => 'text',
                ]
            ]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'after_icon_typography',
                'selector' => '{{WRAPPER}} .testimonial-item .after-icon',                
                'condition' => [
                    'icon_type' => 'text',
                ]
            ]
        );
        
        $this->add_control(
            'after_icon_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .after-icon' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'after_icon_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .testimonial-item .after-icon',
            ]
        );        
        $this->add_responsive_control(
            'after_font_size',
            [
                'label' => __( 'Size', 'codexse' ),
                'type'  => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .after-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],           
                'condition' => [
                    'after_icon_type!' => 'img',
                ]
            ]
        );  
         $this->add_responsive_control(
            'after_icon_floting',
            [
                'label' => __( 'Float', 'codexse' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'codexse' ),
                        'icon' => 'eicon-arrow-left',
                    ],
                    'none; display: block; text-align: right' => [
                        'title' => __( 'None', 'codexse' ),
                        'icon' => 'eicon-arrow-down',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'codexse' ),
                        'icon' => 'eicon-arrow-right',
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .after-icon' => 'float: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'after_icon_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .after-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'after_icon_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .after-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'after_icon_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item .after-icon',
            ]
        );
        $this->add_responsive_control(
            'after_icon_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .after-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'after_icon_shadow',
                'label' => __( 'Box Shadow', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item .after-icon',
            ]
        );   
        
        $this->end_controls_tab(); // Hover Style tab end
        $this->end_controls_tabs();// Box Style tabs end 
        
        
        $this->end_controls_section();

        // Icon Style tab section
        $this->start_controls_section(
            'box_image_section',
            [
                'label' => __( 'Thumbnail', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->start_controls_tabs('box_image_style_tab');
        
        $this->start_controls_tab( 'box_image_normal',
			[
				'label' => __( 'Normal', 'codexse' ),
			]
		);        
        
		$this->add_responsive_control(
			'image_width',
			[
				'label' => __( 'Width', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .thumbnail' => 'width: {{SIZE}}{{UNIT}};min-width: {{SIZE}}{{UNIT}};',
				],
			]
		);        
        
		$this->add_responsive_control(
			'image_height',
			[
				'label' => __( 'Height', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .thumbnail' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'image_line_height',
			[
				'label' => __( 'Line Height', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .thumbnail' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        
        $this->add_responsive_control(
            'image_size',
            [
                'label' => __( 'Size', 'codexse' ),
                'type'  => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .thumbnail' => 'font-size: {{SIZE}}{{UNIT}};',
                ],           
                'condition' => [
                    'image_type!' => 'text',
                ]
            ]
        );
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'image_typography',
                'selector' => '{{WRAPPER}} .testimonial-item .thumbnail',                
                'condition' => [
                    'image_type' => 'text',
                ]
            ]
        );
        
        $this->add_control(
            'image_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .thumbnail' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'image_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .testimonial-item .thumbnail',
            ]
        );
        $this->add_responsive_control(
            'image_alignment',
            [
                'label' => __( 'Float', 'codexse' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'codexse' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'none' => [
                        'title' => __( 'None', 'codexse' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'codexse' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .thumbnail' => 'float: {{VALUE}};',
                ],
                'separator' =>'before',
            ]
        );
        $this->add_responsive_control(
            'image_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .thumbnail' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'image_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .thumbnail' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item .thumbnail',
            ]
        );
        $this->add_responsive_control(
            'image_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .thumbnail' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_shadow',
                'label' => __( 'Box Shadow', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item .thumbnail',
            ]
        );        
        $this->add_control(
			'box_image_transition',
			[
				'label' => __( 'Transition Duration', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0.3,
				],
				'range' => [
					'px' => [
						'max' => 3,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .thumbnail' => 'transition-duration: {{SIZE}}s',
				],
			]
		);
        $this->end_controls_tab(); // Hover Style tab end
        $this->start_controls_tab( 'image_hover_tab',
			[
				'label' => __( 'Hover', 'codexse' ),
			]
		);        
        $this->add_control(
            'image_hover_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .thumbnail:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'image_hover_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .testimonial-item .thumbnail:hover',
            ]
        );               
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'image_hover_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item .thumbnail:hover',
            ]
        );
        $this->add_responsive_control(
            'image_hover_radius',
            [
                'label' => esc_html__( 'Border Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .thumbnail:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_hover_shadow',
                'label' => __( 'Box Shadow', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item .thumbnail:hover',
            ]
        );        
        
        $this->end_controls_tab(); // Hover Style tab end
        $this->start_controls_tab( 'box_hover_image_tab',
			[
				'label' => __( 'Box Hover', 'codexse' ),
			]
		);        
        $this->add_control(
            'box_hover_image_color',
            [
                'label' => __( 'Hover Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item:hover .thumbnail' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'box_hover_image_background',
                'label' => __( 'Background', 'codexse' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .testimonial-item:hover .thumbnail',
            ]
        );               
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'box_hover_image_border',
                'label' => __( 'Border', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item:hover .thumbnail',
            ]
        );
        $this->add_responsive_control(
            'box_hover_image_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item:hover .thumbnail' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_hover_image_shadow',
                'label' => __( 'Box Shadow', 'codexse' ),
                'selector' => '{{WRAPPER}} .testimonial-item:hover .thumbnail',
            ]
        );        
        
        $this->end_controls_tab(); // Hover Style tab end
        $this->end_controls_tabs();// Box Style tabs end  
        $this->end_controls_section();



        // Icon Box Style tab section
        $this->start_controls_section(
            'box_title_section',
            [
                'label' => __( 'Name', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,  
            ]
        );
        
        $this->start_controls_tabs('box_title_style_tab');
        
        $this->start_controls_tab( 'box_title_normal',
			[
				'label' => __( 'Normal', 'codexse' ),
			]
		);        
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'image_box_title_typography',
                'selector' => '{{WRAPPER}} .testimonial-item .title',
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'title_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'title_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
                
		$this->add_control(
			'image_box_title_transition',
			[
				'label' => __( 'Transition Duration', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0.3,
				],
				'range' => [
					'px' => [
						'max' => 3,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .title' => 'transition-duration: {{SIZE}}s',
				],
			]
		);
        $this->add_responsive_control(                                                                                                                          
            'title_alignment',                                                                                                                             
            [                                                                                                                                                   
                'label' => __( 'Alignment', 'codexse' ),                                                                                                        
                'type' => Controls_Manager::CHOOSE,                                                                                                             
                'options' => [                                                                                                                                  
                    'left' => [                                                                                                                                 
                        'title' => __( 'Left', 'codexse' ),                                                                                                     
                        'icon' => 'eicon-text-align-left',                                                                                                      
                    ],                                                                                                                                          
                    'center' => [                                                                                                                               
                        'title' => __( 'Center', 'codexse' ),                                                                                                   
                        'icon' => 'eicon-text-align-center',                                                                                                    
                    ],                                                                                                                                          
                    'right' => [                                                                                                                                
                        'title' => __( 'Right', 'codexse' ),                                                                                                    
                        'icon' => 'eicon-text-align-right',                                                                                                     
                    ],                                                                                                                                          
                ],                                                                                                                                              
                'selectors' => [                                                                                                                                
                    '{{WRAPPER}} .testimonial-item .title' => 'text-align: {{VALUE}};'                                                                         
                ],                                                                                                                                              
                'separator' =>'before',                                                                                                                         
            ]                                                                                                                                                   
        );  
        $this->end_controls_tab(); // Hover Style tab end
         
        $this->start_controls_tab( 'title_hover_tab',
			[
				'label' => __( 'Hover', 'codexse' ),
			]
		);        
        
        $this->add_control(
            'title_hover_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .title:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_tab(); // Hover Style tab end
        $this->start_controls_tab( 'box_title_hover_tab',
			[
				'label' => __( 'Box Hover', 'codexse' ),
			]
		);        
        
        $this->add_control(
            'box_hover_title_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item:hover .title' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_tab(); // Hover Style tab end
        $this->end_controls_tabs();// Box Style tabs end  
        $this->end_controls_section();



                
        // Icon Box Style tab section
        $this->start_controls_section(
            'box_position_section',
            [
                'label' => __( 'Position', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs('box_position_style_tab');
        
        $this->start_controls_tab( 'box_position_normal',
			[
				'label' => __( 'Normal', 'codexse' ),
			]
		);        
        
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'icon_box_position_typography',
                'selector' => '{{WRAPPER}} .testimonial-item .position',
            ]
        );
        $this->add_control(
            'position_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .position' => 'color: {{VALUE}};',
                ],
            ]
        );
                
        $this->add_responsive_control(
            'position_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .position' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'position_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .position' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
		$this->add_control(
			'icon_box_position_transition',
			[
				'label' => __( 'Transition Duration', 'codexse' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0.3,
				],
				'range' => [
					'px' => [
						'max' => 3,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-item .position' => 'transition-duration: {{SIZE}}s',
				],
			]
		);
        
        $this->end_controls_tab(); // Hover Style tab end
         
        $this->start_controls_tab( 'position_hover_tab',
			[
				'label' => __( 'Hover', 'codexse' ),
			]
		);        
        
        $this->add_control(
            'position_hover_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item .position:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_tab(); // Hover Style tab end
        $this->start_controls_tab( 'box_position_hover_tab',
			[
				'label' => __( 'Box Hover', 'codexse' ),
			]
		);        
        
        $this->add_control(
            'box_hover_position_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-item:hover .position' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_tab(); // Hover Style tab end
        $this->end_controls_tabs();// Box Style tabs end 
        $this->end_controls_section();

        $this->start_controls_section(
            "section_rating", 
            [
                "label" => __("Rating", "codexse"),
                "tab" => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs("counter_rating_tabs");
        $this->start_controls_tab(
            "counter_rating_tab", 
            [
                "label" => __("Normal", "codexse"),
            ]
        );
        $this->add_control(
            "counter_rating_color", 
            [
                "label" => __("Color", "codexse"),
                "type" => Controls_Manager::COLOR,
                "selectors" => ["{{WRAPPER}} .feed-rating" => "color: {{VALUE}};"],
            ]
        );
        $this->add_responsive_control(
            "counter_rating_margin", 
            [
                "label" => __("Margin", "codexse"),
                "type" => Controls_Manager::DIMENSIONS,
                "size_units" => ["px", "%", "em"],
                "selectors" => [
                    "{{WRAPPER}} .feed-rating" =>
                        "margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};",
                ],
                "separator" => "before",
            ]
        );
        $this->add_responsive_control(
            "counter_rating_padding", 
            [
                "label" => __("Padding", "codexse"),
                "type" => Controls_Manager::DIMENSIONS,
                "size_units" => ["px", "%", "em"],
                "selectors" => [
                    "{{WRAPPER}} .feed-rating" =>
                        "padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};",
                ],
                "separator" => "before",
            ]
        );

        $this->add_control(
            "counter_rating_transition", 
            [
                "label" => __("Transition Duration", "codexse"),
                "type" => Controls_Manager::SLIDER,
                "default" => ["size" => 0.3],
                "range" => ["px" => ["max" => 3, "step" => 0.1]],
                "selectors" => [
                    "{{WRAPPER}} .feed-rating" => "transition-duration: {{SIZE}}s",
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab("counter_rating_hover_tab", [
            "label" => __("Hover", "codexse"),
        ]);
        $this->add_control(
            "counter_rating_hover_color", 
            [
                "label" => __("Color", "codexse"),
                "type" => Controls_Manager::COLOR,
                "selectors" => [
                    "{{WRAPPER}} .feed-rating:hover" => "color: {{VALUE}};",
                ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            "box_hover_rating_tab", 
            [
                "label" => __("Box Hover", "codexse"),
            ]
        );
        $this->add_control(
            "box_hover_rating_color", 
            [
                "label" => __("Color", "codexse"),
                "type" => Controls_Manager::COLOR,
                "selectors" => [
                    "{{WRAPPER}}:hover .feed-rating" => "color: {{VALUE}};",
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();




                                                                                                                                                                    
        // Style Slider arrow style start                                                                                                                           
        $this->start_controls_section(                                                                                                                              
            'slider_arrow_style',                                                                                                                                   
            [                                                                                                                                                       
                'label'     => __( 'Arrow', 'codexse' ),                                                                                                            
                'tab'       => Controls_Manager::TAB_STYLE,                                                                                                         
                'condition' =>[                                                                                                                                     
                    'slider_on' => 'yes',                                                                                                                           
                    'sl_navigation'  => 'yes',                                                                                                                      
                ],                                                                                                                                                  
            ]                                                                                                                                                       
        );                                                                                                                                                          
                                                                                                                                                                    
            $this->start_controls_tabs( 'slider_arrow_style_tabs' );                                                                                                
                                                                                                                                                                    
                // Normal tab Start                                                                                                                                 
                $this->start_controls_tab(                                                                                                                          
                    'slider_arrow_style_normal_tab',                                                                                                                
                    [                                                                                                                                               
                        'label' => __( 'Normal', 'codexse' ),                                                                                                       
                    ]                                                                                                                                               
                );                                                                                                                                                  
                                                                                                                                                                    
                    $this->add_control(                                                                                                                             
                        'slider_arrow_color',                                                                                                                       
                        [                                                                                                                                           
                            'label' => __( 'Color', 'codexse' ),                                                                                                    
                            'type' => Controls_Manager::COLOR,                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'color: {{VALUE}};',                                                              
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                    $this->add_responsive_control(                                                                                                                  
                        'slider_arrow_gap',                                                                                                                         
                        [                                                                                                                                           
                            'label' => __( 'Arrow Gap', 'codexse' ),                                                                                                
                            'type' => Controls_Manager::SLIDER,                                                                                                     
                            'size_units' => [ 'px' ],                                                                                                               
                            'range' => [                                                                                                                            
                                'px' => [                                                                                                                           
                                    'min' => -100,                                                                                                                  
                                    'max' => 100,                                                                                                                   
                                    'step' => 1,                                                                                                                    
                                ]                                                                                                                                   
                            ],                                                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow.swiper-prev' => 'left: {{SIZE}}{{UNIT}};',                                            
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow.swiper-next' => 'right: {{SIZE}}{{UNIT}};',                                           
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_responsive_control(                                                                                                                  
                        'slider_arrow_fontsize',                                                                                                                    
                        [                                                                                                                                           
                            'label' => __( 'Font Size', 'codexse' ),                                                                                                
                            'type' => Controls_Manager::SLIDER,                                                                                                     
                            'size_units' => [ 'px', '%' ],                                                                                                          
                            'range' => [                                                                                                                            
                                'px' => [                                                                                                                           
                                    'min' => 0,                                                                                                                     
                                    'max' => 100,                                                                                                                   
                                    'step' => 1,                                                                                                                    
                                ],                                                                                                                                  
                                '%' => [                                                                                                                            
                                    'min' => 0,                                                                                                                     
                                    'max' => 100,                                                                                                                   
                                ],                                                                                                                                  
                            ],                                                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'font-size: {{SIZE}}{{UNIT}};',                                                   
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_group_control(                                                                                                                       
                        Group_Control_Background::get_type(),                                                                                                       
                        [                                                                                                                                           
                            'name' => 'slider_arrow_background',                                                                                                    
                            'label' => __( 'Background', 'codexse' ),                                                                                               
                            'types' => [ 'classic', 'gradient' ],                                                                                                   
                            'selector' => '{{WRAPPER}} .swiper-navigation .swiper-arrow',                                                                           
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_group_control(                                                                                                                       
                        Group_Control_Border::get_type(),                                                                                                           
                        [                                                                                                                                           
                            'name' => 'slider_arrow_border',                                                                                                        
                            'label' => __( 'Border', 'codexse' ),                                                                                                   
                            'selector' => '{{WRAPPER}} .swiper-navigation .swiper-arrow',                                                                           
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_responsive_control(                                                                                                                  
                        'slider_border_radius',                                                                                                                     
                        [                                                                                                                                           
                            'label' => esc_html__( 'Border Radius', 'codexse' ),                                                                                    
                            'type' => Controls_Manager::DIMENSIONS,                                                                                                 
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',                  
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_responsive_control(                                                                                                                  
                        'slider_arrow_width',                                                                                                                       
                        [                                                                                                                                           
                            'label' => __( 'Width', 'codexse' ),                                                                                                    
                            'type' => Controls_Manager::SLIDER,                                                                                                     
                            'size_units' => [ 'px', '%' ],                                                                                                          
                            'range' => [                                                                                                                            
                                'px' => [                                                                                                                           
                                    'min' => 0,                                                                                                                     
                                    'max' => 1000,                                                                                                                  
                                    'step' => 1,                                                                                                                    
                                ],                                                                                                                                  
                                '%' => [                                                                                                                            
                                    'min' => 0,                                                                                                                     
                                    'max' => 100,                                                                                                                   
                                ],                                                                                                                                  
                            ],                                                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'width: {{SIZE}}{{UNIT}};',                                                       
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_responsive_control(                                                                                                                  
                        'slider_arrow_height',                                                                                                                      
                        [                                                                                                                                           
                            'label' => __( 'Height', 'codexse' ),                                                                                                   
                            'type' => Controls_Manager::SLIDER,                                                                                                     
                            'size_units' => [ 'px', '%' ],                                                                                                          
                            'range' => [                                                                                                                            
                                'px' => [                                                                                                                           
                                    'min' => 0,                                                                                                                     
                                    'max' => 1000,                                                                                                                  
                                    'step' => 1,                                                                                                                    
                                ],                                                                                                                                  
                                '%' => [                                                                                                                            
                                    'min' => 0,                                                                                                                     
                                    'max' => 100,                                                                                                                   
                                ],                                                                                                                                  
                            ],                                                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',                       
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_responsive_control(                                                                                                                  
                        'slider_arrow_line_height',                                                                                                                 
                        [                                                                                                                                           
                            'label' => __( 'Line Height', 'codexse' ),                                                                                              
                            'type' => Controls_Manager::SLIDER,                                                                                                     
                            'size_units' => [ 'px', '%' ],                                                                                                          
                            'range' => [                                                                                                                            
                                'px' => [                                                                                                                           
                                    'min' => 0,                                                                                                                     
                                    'max' => 1000,                                                                                                                  
                                    'step' => 1,                                                                                                                    
                                ],                                                                                                                                  
                                '%' => [                                                                                                                            
                                    'min' => 0,                                                                                                                     
                                    'max' => 100,                                                                                                                   
                                ],                                                                                                                                  
                            ],                                                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'line-height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',                  
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_responsive_control(                                                                                                                  
                        'slider_arrow_padding',                                                                                                                     
                        [                                                                                                                                           
                            'label' => __( 'Padding', 'codexse' ),                                                                                                  
                            'type' => Controls_Manager::DIMENSIONS,                                                                                                 
                            'size_units' => [ 'px', '%', 'em' ],                                                                                                    
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],                                                                                                                                      
                            'separator' =>'before',                                                                                                                 
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                $this->end_controls_tab(); // Normal tab end                                                                                                        
                                                                                                                                                                    
                // Hover tab Start                                                                                                                                  
                $this->start_controls_tab(                                                                                                                          
                    'slider_arrow_style_hover_tab',                                                                                                                 
                    [                                                                                                                                               
                        'label' => __( 'Hover', 'codexse' ),                                                                                                        
                    ]                                                                                                                                               
                );                                                                                                                                                  
                                                                                                                                                                    
                    $this->add_control(                                                                                                                             
                        'slider_arrow_hover_color',                                                                                                                 
                        [                                                                                                                                           
                            'label' => __( 'Color', 'codexse' ),                                                                                                    
                            'type' => Controls_Manager::COLOR,                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow:hover' => 'color: {{VALUE}};',                                                        
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_group_control(                                                                                                                       
                        Group_Control_Background::get_type(),                                                                                                       
                        [                                                                                                                                           
                            'name' => 'slider_arrow_hover_background',                                                                                              
                            'label' => __( 'Background', 'codexse' ),                                                                                               
                            'types' => [ 'classic', 'gradient' ],                                                                                                   
                            'selector' => '{{WRAPPER}} .swiper-navigation .swiper-arrow:hover',                                                                     
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_group_control(                                                                                                                       
                        Group_Control_Border::get_type(),                                                                                                           
                        [                                                                                                                                           
                            'name' => 'slider_arrow_hover_border',                                                                                                  
                            'label' => __( 'Border', 'codexse' ),                                                                                                   
                            'selector' => '{{WRAPPER}} .swiper-navigation .swiper-arrow:hover',                                                                     
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_responsive_control(                                                                                                                  
                        'slider_arrow_hover_border_radius',                                                                                                         
                        [                                                                                                                                           
                            'label' => esc_html__( 'Border Radius', 'codexse' ),                                                                                    
                            'type' => Controls_Manager::DIMENSIONS,                                                                                                 
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-navigation .swiper-arrow:hover' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',            
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                $this->end_controls_tab(); // Hover tab end                                                                                                         
                                                                                                                                                                    
            $this->end_controls_tabs();                                                                                                                             
                                                                                                                                                                    
        $this->end_controls_section(); // Style Slider arrow style end                                                                                              
                                                                                                                                                                    
        // Style Pagination button tab section                                                                                                                      
        $this->start_controls_section(                                                                                                                              
            'post_slider_pagination_style_section',                                                                                                                 
            [                                                                                                                                                       
                'label' => __( 'Pagination', 'codexse' ),                                                                                                           
                'tab' => Controls_Manager::TAB_STYLE,                                                                                                               
                'condition'=>[                                                                                                                                      
                    'slider_on' => 'yes',                                                                                                                           
                    'slpaginate'=>'yes',                                                                                                                            
                ]                                                                                                                                                   
            ]                                                                                                                                                       
        );                                                                                                                                                          
                                                                                                                                                                    
            $this->start_controls_tabs('pagination_style_tabs');                                                                                                    
            $this->add_responsive_control(                                                                                                                          
                'pagination_alignment',                                                                                                                             
                [                                                                                                                                                   
                    'label' => __( 'Alignment', 'codexse' ),                                                                                                        
                    'type' => Controls_Manager::CHOOSE,                                                                                                             
                    'options' => [                                                                                                                                  
                        'left' => [                                                                                                                                 
                            'title' => __( 'Left', 'codexse' ),                                                                                                     
                            'icon' => 'eicon-text-align-left',                                                                                                      
                        ],                                                                                                                                          
                        'center' => [                                                                                                                               
                            'title' => __( 'Center', 'codexse' ),                                                                                                   
                            'icon' => 'eicon-text-align-center',                                                                                                    
                        ],                                                                                                                                          
                        'right' => [                                                                                                                                
                            'title' => __( 'Right', 'codexse' ),                                                                                                    
                            'icon' => 'eicon-text-align-right',                                                                                                     
                        ],                                                                                                                                          
                    ],                                                                                                                                              
                    'selectors' => [                                                                                                                                
                        '{{WRAPPER}} .swiper-pagination-bullet' => 'text-align: {{VALUE}};'                                                                         
                    ],                                                                                                                                              
                    'separator' =>'before',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                $this->start_controls_tab(                                                                                                                          
                    'pagination_style_normal_tab',                                                                                                                  
                    [                                                                                                                                               
                        'label' => __( 'Normal', 'codexse' ),                                                                                                       
                    ]                                                                                                                                               
                );                                                                                                                                                  
                                                                                                                                                                    
                    $this->add_responsive_control(                                                                                                                  
                        'slider_pagination_height',                                                                                                                 
                        [                                                                                                                                           
                            'label' => __( 'Height', 'codexse' ),                                                                                                   
                            'type' => Controls_Manager::SLIDER,                                                                                                     
                            'size_units' => [ 'px', '%' ],                                                                                                          
                            'range' => [                                                                                                                            
                                'px' => [                                                                                                                           
                                    'min' => 0,                                                                                                                     
                                    'max' => 1000,                                                                                                                  
                                    'step' => 1,                                                                                                                    
                                ],                                                                                                                                  
                                '%' => [                                                                                                                            
                                    'min' => 0,                                                                                                                     
                                    'max' => 100,                                                                                                                   
                                ],                                                                                                                                  
                            ],                                                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}};',                                                             
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_responsive_control(                                                                                                                  
                        'slider_pagination_width',                                                                                                                  
                        [                                                                                                                                           
                            'label' => __( 'Width', 'codexse' ),                                                                                                    
                            'type' => Controls_Manager::SLIDER,                                                                                                     
                            'size_units' => [ 'px', '%' ],                                                                                                          
                            'range' => [                                                                                                                            
                                'px' => [                                                                                                                           
                                    'min' => 0,                                                                                                                     
                                    'max' => 1000,                                                                                                                  
                                    'step' => 1,                                                                                                                    
                                ],                                                                                                                                  
                                '%' => [                                                                                                                            
                                    'min' => 0,                                                                                                                     
                                    'max' => 100,                                                                                                                   
                                ],                                                                                                                                  
                            ],                                                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}};',                                                              
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_group_control(                                                                                                                       
                        Group_Control_Background::get_type(),                                                                                                       
                        [                                                                                                                                           
                            'name' => 'pagination_background',                                                                                                      
                            'label' => __( 'Background', 'codexse' ),                                                                                               
                            'types' => [ 'classic', 'gradient' ],                                                                                                   
                            'selector' => '{{WRAPPER}} .swiper-pagination-bullet',                                                                                  
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_responsive_control(                                                                                                                  
                        'pagination_margin',                                                                                                                        
                        [                                                                                                                                           
                            'label' => __( 'Margin', 'codexse' ),                                                                                                   
                            'type' => Controls_Manager::DIMENSIONS,                                                                                                 
                            'size_units' => [ 'px', '%', 'em' ],                                                                                                    
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-pagination-bullet' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',        
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_group_control(                                                                                                                       
                        Group_Control_Border::get_type(),                                                                                                           
                        [                                                                                                                                           
                            'name' => 'pagination_border',                                                                                                          
                            'label' => __( 'Border', 'codexse' ),                                                                                                   
                            'selector' => '{{WRAPPER}} .swiper-pagination-bullet',                                                                                  
                        ]                                                                                                                                           
                    );                                                                                                                                              
                                                                                                                                                                    
                    $this->add_responsive_control(                                                                                                                  
                        'pagination_border_radius',                                                                                                                 
                        [                                                                                                                                           
                            'label' => esc_html__( 'Border Radius', 'codexse' ),                                                                                    
                            'type' => Controls_Manager::DIMENSIONS,                                                                                                 
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-pagination-bullet' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',                         
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                    $this->add_responsive_control(                                                                                                                  
                        'pagination_opacity',                                                                                                                       
                        [                                                                                                                                           
                            'label' => __( 'Opacity (%)', 'codexse' ),                                                                                              
                            'type' => Controls_Manager::SLIDER,                                                                                                     
                            'range' => [                                                                                                                            
                                'px' => [                                                                                                                           
                                    'max' => 1,                                                                                                                     
                                    'step' => 0.01,                                                                                                                 
                                ],                                                                                                                                  
                            ],                                                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-pagination-bullet' => 'opacity: {{SIZE}}',                                                                     
                                                                                                                                                                    
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                $this->end_controls_tab(); // Normal Tab end                                                                                                        
                                                                                                                                                                    
                $this->start_controls_tab(                                                                                                                          
                    'pagination_style_active_tab',                                                                                                                  
                    [                                                                                                                                               
                        'label' => __( 'Active', 'codexse' ),                                                                                                       
                    ]                                                                                                                                               
                );                                                                                                                                                  
                                                                                                                                                                    
                    $this->add_group_control(                                                                                                                       
                        Group_Control_Background::get_type(),                                                                                                       
                        [                                                                                                                                           
                            'name' => 'pagination_hover_background',                                                                                                
                            'label' => __( 'Background', 'codexse' ),                                                                                               
                            'types' => [ 'classic', 'gradient' ],                                                                                                   
                            'selector' => '{{WRAPPER}} .swiper-pagination-bullet:hover, {{WRAPPER}} .swiper-pagination-bullet.swiper-pagination-bullet-active',     
                        ]                                                                                                                                           
                    );                                                                                                                                              
                    $this->add_responsive_control(                                                                                                                  
                        'slider_pagination_active_width',                                                                                                           
                        [                                                                                                                                           
                            'label' => __( 'Width', 'codexse' ),                                                                                                    
                            'type' => Controls_Manager::SLIDER,                                                                                                     
                            'size_units' => [ 'px', '%' ],                                                                                                          
                            'range' => [                                                                                                                            
                                'px' => [                                                                                                                           
                                    'min' => 0,                                                                                                                     
                                    'max' => 1000,                                                                                                                  
                                    'step' => 1,                                                                                                                    
                                ],                                                                                                                                  
                                '%' => [                                                                                                                            
                                    'min' => 0,                                                                                                                     
                                    'max' => 100,                                                                                                                   
                                ],                                                                                                                                  
                            ],                                                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'width: {{SIZE}}{{UNIT}};',                              
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                    $this->add_responsive_control(                                                                                                                  
                        'slider_pagination_active_height',                                                                                                          
                        [                                                                                                                                           
                            'label' => __( 'Height', 'codexse' ),                                                                                                   
                            'type' => Controls_Manager::SLIDER,                                                                                                     
                            'size_units' => [ 'px', '%' ],                                                                                                          
                            'range' => [                                                                                                                            
                                'px' => [                                                                                                                           
                                    'min' => 0,                                                                                                                     
                                    'max' => 1000,                                                                                                                  
                                    'step' => 1,                                                                                                                    
                                ],                                                                                                                                  
                                '%' => [                                                                                                                            
                                    'min' => 0,                                                                                                                     
                                    'max' => 100,                                                                                                                   
                                ],                                                                                                                                  
                            ],                                                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'height: {{SIZE}}{{UNIT}};',                             
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                    $this->add_responsive_control(                                                                                                                  
                        'pagination_active_opacity',                                                                                                                
                        [                                                                                                                                           
                            'label' => __( 'Opacity (%)', 'codexse' ),                                                                                              
                            'type' => Controls_Manager::SLIDER,                                                                                                     
                            'range' => [                                                                                                                            
                                'px' => [                                                                                                                           
                                    'max' => 1,                                                                                                                     
                                    'step' => 0.01,                                                                                                                 
                                ],                                                                                                                                  
                            ],                                                                                                                                      
                            'selectors' => [                                                                                                                        
                                '{{WRAPPER}} .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'opacity: {{SIZE}}',                                     
                            ],                                                                                                                                      
                        ]                                                                                                                                           
                    );                                                                                                                                              
                $this->end_controls_tab(); // Hover Tab end                                                                                                         
            $this->end_controls_tabs();                                                                                                                             
        $this->end_controls_section();                                                                                                                              
                                                                                                                                                                    
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function render( $instance = [] ) {      
        $column = "col-lg-4 col-md-6";                                                                                                   
        $settings   = $this->get_settings_for_display();                                                                                                            
        // Carousel Attribute                                                                                                                                       
        $this->add_render_attribute( 'wrapper_attributes', 'class', ['codexse-custom-carousel', $settings['boxstyle'] ] ); 

        $client = [];
        foreach ( $settings['testimonial_list'] as $item ):
            if(Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_imagesize', 'testimonial_image' )){
                $client[] = Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_imagesize', 'testimonial_image' );
            }else{
                $client[] = '<img src="'.CODEXSE_ASSETS.'/images/user_placeholder.jpg" alt="" />';
            }
        endforeach;
        if( $settings['slider_on'] == 'yes' ){                                                                                                                      
            $this->add_render_attribute( 'wrapper_attributes', 'class', 'swiper-container' );                                                                       
            $slider_settings = [                                                                                                                                    
                'sleffect' => $settings['sleffect'],                                                                                                                
                'sldirection' => $settings['sldirection'],                                                                                                                
                'slloop' => ('yes' === $settings['slloop']),                                                                                               
                'slpaginate' => ('yes' === $settings['slpaginate']),                                                                                                               
                'slautolay' => ('yes' === $settings['slautolay']),                                                                                                  
                'slautolaydelay' => absint($settings['slautolaydelay']), 
                'slanimation_speed' => absint($settings['slanimation_speed']),   
                'coverflow_rotate' => absint($settings['coverflow_rotate']),    
                'coverflow_stretch' => absint($settings['coverflow_stretch']),    
                'coverflow_depth' => absint($settings['coverflow_depth']),                                                                                                   
                'coverflow_shadow' => $settings['coverflow_shadow'],              
                'slcustom_arrow' => ('yes' === $settings['slider_custom_arrow']),                                                                                   
                'sltarget_id' => $settings['slider_target_id'],                                                                                                     
                'sldisplay_columns' => $settings['sldisplay_columns'],                                                                                              
                'slcenter' => ('yes' === $settings['slcenter']),                                                                                           
                'slcenter_padding' => $settings['slcenter_padding'],                                                                                                
                'laptop_width' => $settings['sllaptop_width'],                                                                                                      
                'laptop_padding' => $settings['sllaptop_padding'],                                                                                                  
                'laptop_display_columns' => $settings['sllaptop_display_columns'],                                                                                  
                'tablet_width' => $settings['sltablet_width'],                                                                                                      
                'tablet_padding' => $settings['sltablet_padding'],                                                                                                  
                'tablet_display_columns' => $settings['sltablet_display_columns'],                                                                                  
                'mobile_width' => $settings['slmobile_width'],                                                                                                      
                'mobile_padding' => $settings['slmobile_padding'],                                                                                                  
                'mobile_display_columns' => $settings['slmobile_display_columns'],                                                                                                            
                'image_pagination_sw' => ('yes' === $settings['image_pagination_sw']),                                                                           
                'image_pagination_id' => $settings['image_pagination_id'],      
                'client_images' => $client,                                                                                                     
            ];                                                                                                                                                      
            $this->add_render_attribute( 'wrapper_attributes', 'data-settings', wp_json_encode( $slider_settings ) );                                               
        }else {
            $this->add_render_attribute( 'wrapper_attributes', 'class', ['row', esc_attr($settings['grid_space'])] );
            if($settings['masonry'] == 'yes'){
                $this->add_render_attribute( 'wrapper_attributes', 'class', 'masonry_lists' );
            }
            switch ($settings['item_column']) {
                case "1grid":
                    $column = "col-lg-12";
                    break;
                case "2grid":
                    $column = "col-lg-6 col-md-12";
                    break;
                case "3grid":
                    $column = "col-lg-4 col-md-6";
                    break;
                default:
                    $column = "col-xl-3 col-lg-4 col-md-6";
            }
        }
        echo '<div '.$this->get_render_attribute_string( "wrapper_attributes" ).' >';                                                                               
            if($settings['slider_on'] == 'yes'){
                echo '<div class="swiper-wrapper">';                                                                                                                        
                    foreach ( $settings['testimonial_list'] as $item ):
                        echo '<div class="swiper-slide elementor-repeater-item-'.$item['_id'].'">';                                                                                                                  
                            echo '<div class="testimonial-item" >';
              					echo '<div class="testimonial-header">';
                                  if(Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_imagesize', 'testimonial_image' )){
                                      echo '<div class="thumbnail">';
                                      echo Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_imagesize', 'testimonial_image' );
                                      echo '</div>';
                                  }else{
                                    echo '<div class="thumbnail">';
                                    echo '<img src="'.CODEXSE_ASSETS.'/images/user_placeholder.jpg" alt="" />';
                                    echo '</div>';
                                  }
                                  echo '<div class="testimonial-info">';
                                    if( !empty($item['testimonial_name']) ){
                                      echo '<h3 class="title">'.esc_html($item['testimonial_name']).'</h3>';
                                    }                      
                                    if( !empty($item['testimonial_position']) ){
                                      echo '<div class="position">'.esc_html($item['testimonial_position']).'</div>';
                                    }
                                  echo '</div>';
              					echo '</div>';
                                if( !empty($item['testimonial_description']) ){
                                    echo '<div class="description">';
                                    if( $settings['before_icon_type'] == 'img' and !empty(Group_Control_Image_Size::get_attachment_image_html( $settings, 'before_image_size', 'before_image' )) ){
                                        echo '<span class="before-icon">'.Group_Control_Image_Size::get_attachment_image_html( $settings, 'before_image_size', 'before_image' ).'</span>';
                                    }elseif( $settings['before_icon_type'] == 'icon' && !empty($settings['before_font_icon']['value']) ){
                                        echo sprintf( '<span class="before-icon" >%1$s</span>', Codexse_Icon_manager::render_icon( $settings['before_font_icon'], [ 'aria-hidden' => 'true' ] ) );
                                    }elseif( $settings['before_icon_type'] == 'text' && !empty($settings['before_text_icon']) ){
                                        echo sprintf( '<span class="before-icon" >%1$s</span>', $settings['before_text_icon']);
                                    }
                                    echo esc_html($item['testimonial_description']);
                                    if( $settings['after_icon_type'] == 'img' and !empty(Group_Control_Image_Size::get_attachment_image_html( $settings, 'after_image_size', 'after_image' )) ){
                                        echo '<span class="after-icon">'.Group_Control_Image_Size::get_attachment_image_html( $settings, 'after_image_size', 'after_image' ).'</span>';
                                    }elseif( $settings['after_icon_type'] == 'icon' && !empty($settings['after_font_icon']['value']) ){
                                        echo sprintf( '<span class="after-icon" >%1$s</span>', Codexse_Icon_manager::render_icon( $settings['after_font_icon'], [ 'aria-hidden' => 'true' ] ) );
                                    }elseif( $settings['after_icon_type'] == 'text' && !empty($settings['after_text_icon']) ){
                                        echo sprintf( '<span class="after-icon" >%1$s</span>', $settings['after_text_icon']);
                                    }
                                    echo '</div>';
                                }
                                if ($item["rating_switch"] == "yes"):
                                  echo '<div class="feed-rating">';
                                    echo '<span class="star front"></span>';
                                    echo '<span class="star back" style="width: '. esc_attr( $item["rating"]["size"] * 20 ) .'%"></span>';
                                  echo '</div>';
                                  echo '<span class="feed-interval">'.esc_html($item['testimonial_interval']).'</span>';
                                endif;
                            echo '</div>';                                                                                                                                 
                        echo '</div>';                                                                                                                                      
                    endforeach;                                                                                                                                             
                echo '</div>';                                                                                                                                              
                if( $settings['sl_navigation'] == 'yes' && $settings['slider_custom_arrow'] != 'yes' ){                                                                       
                    echo '<div class="swiper-navigation" >';                                                                                                                
                        echo '<div class="swiper-arrow swiper-prev"><i class="'.esc_attr($settings['sl_nav_prev_icon']).'" ></i></div>';                                    
                        echo '<div class="swiper-arrow swiper-next"><i class="'.esc_attr($settings['sl_nav_next_icon']).'" ></i></div>';                                    
                    echo '</div>';                                                                                                                                          
                }                                                                                                                                                           
                if( $settings['slpaginate'] == 'yes' ){                                                                                                                      
                    echo '<div class="swiper-pagination"></div>';                                                                                                           
                }           
            }else {                                                                                        
                foreach ( $settings['testimonial_list'] as $item ):   
                    echo '<div class="'.$column.' elementor-repeater-item-'.$item['_id'].'">';                                                                                                                 
                        echo '<div class="testimonial-item" >';
              					echo '<div class="testimonial-header">';
                                  if(Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_imagesize', 'testimonial_image' )){
                                      echo '<div class="thumbnail">';
                                      echo Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_imagesize', 'testimonial_image' );
                                      echo '</div>';
                                  }
                                  echo '<div class="testimonial-info">';
                                    if( !empty($item['testimonial_name']) ){
                                      echo '<h3 class="title">'.esc_html($item['testimonial_name']).'</h3>';
                                    }                      
                                    if( !empty($item['testimonial_position']) ){
                                      echo '<div class="position">'.esc_html($item['testimonial_position']).'</div>';
                                    }
                                  echo '</div>';
              					echo '</div>';
                                if( !empty($item['testimonial_description']) ){
                                    echo '<div class="description">';
                                    if( $settings['before_icon_type'] == 'img' and !empty(Group_Control_Image_Size::get_attachment_image_html( $settings, 'before_image_size', 'before_image' )) ){
                                        echo '<span class="before-icon">'.Group_Control_Image_Size::get_attachment_image_html( $settings, 'before_image_size', 'before_image' ).'</span>';
                                    }elseif( $settings['before_icon_type'] == 'icon' && !empty($settings['before_font_icon']['value']) ){
                                        echo sprintf( '<span class="before-icon" >%1$s</span>', Codexse_Icon_manager::render_icon( $settings['before_font_icon'], [ 'aria-hidden' => 'true' ] ) );
                                    }elseif( $settings['before_icon_type'] == 'text' && !empty($settings['before_text_icon']) ){
                                        echo sprintf( '<span class="before-icon" >%1$s</span>', $settings['before_text_icon']);
                                    }
                                    echo esc_html($item['testimonial_description']);
                                    if( $settings['after_icon_type'] == 'img' and !empty(Group_Control_Image_Size::get_attachment_image_html( $settings, 'after_image_size', 'after_image' )) ){
                                        echo '<span class="after-icon">'.Group_Control_Image_Size::get_attachment_image_html( $settings, 'after_image_size', 'after_image' ).'</span>';
                                    }elseif( $settings['after_icon_type'] == 'icon' && !empty($settings['after_font_icon']['value']) ){
                                        echo sprintf( '<span class="after-icon" >%1$s</span>', Codexse_Icon_manager::render_icon( $settings['after_font_icon'], [ 'aria-hidden' => 'true' ] ) );
                                    }elseif( $settings['after_icon_type'] == 'text' && !empty($settings['after_text_icon']) ){
                                        echo sprintf( '<span class="after-icon" >%1$s</span>', $settings['after_text_icon']);
                                    }
                                    echo '</div>';
                                }                                
                                if ($item["rating_switch"] == "yes"):
                                    echo '<div class="feed-rating">';
                                      echo '<span class="star front"></span>';
                                      echo '<span class="star back" style="width: '. esc_attr( $item["rating"]["size"] * 20 ) .'%"></span>';
                                    echo '</div>';
                                    echo '<span class="feed-interval">'.esc_html($item['testimonial_interval']).'</span>';
                                endif;
                            echo '</div>';    
                    echo '</div>';
                endforeach;
            }            
        echo '</div>';                                                                                                                                              
    }                                                                                                                                                               
                                                                                                                                                                    
}                                                                                                                                                                   
                                                                                                                                                                    
