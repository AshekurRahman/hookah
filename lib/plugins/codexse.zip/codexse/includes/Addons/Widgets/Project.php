<?php                                                                                                                                                               
namespace Elementor;                                                                                                                                                
                                                                                                                                                                    
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly                                                                                                    
                                                                                                                                                                    
class Codexse_Elementor_Widget_Project extends Widget_Base {                                                                                                       
                                                                                                                                                                    
    public function get_name() {                                                                                                                                    
        return 'codexse-project-addons';                                                                                                                           
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_title() {                                                                                                                                   
        return __( 'Project', 'codexse' );                                                                                                                  
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_icon() {                                                                                                                                    
        return 'codexse-icon eicon-gallery-grid';                                                                                                                    
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_categories() {                                                                                                                              
        return [ 'codexse-addons' ];                                                                                                                                
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_style_depends() {                                                                                                                           
        return [                                                                                                                                                    
            'swiper',                                                                                                                                        
            'codexse-carousel',                                                                                             
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_script_depends() {                                                                                                                          
        return [                                                                                                                                                    
            'swiper-slider',                                                                                                                                        
            'codexse-carousel',                                                                                                                                     
            'codexse-lax',                                                                                                                                     
            'codexse-lax-active',                                                                                                                                     
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function register_controls() {
        
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Project Settings', 'codexse' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        
            $this->add_control(
                'slider_on',
                [
                    'label'         => __( 'Slider', 'codexse' ),
                    'type'          => Controls_Manager::SWITCHER,
                    'label_on'      => __( 'On', 'codexse' ),
                    'label_off'     => __( 'Off', 'codexse' ),
                    'return_value'  => 'yes',
                    'default'       => 'no',
                ]
            );
        
        
            $this->add_control(
                'item_column',
                [
                    'label' => __( 'Column', 'codexse' ),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        '1grid' => [
                            'title' => __( 'One Column', 'codexse' ),
                            'icon' => 'icon-grid-1',
                        ],
                        '2grid' => [
                            'title' => __( 'Two Columns', 'codexse' ),
                            'icon' => 'icon-grid-2',
                        ],
                        '3grid' => [
                            'title' => __( 'Three Columns', 'codexse' ),
                            'icon' => 'icon-grid-3',
                        ],
                        '4grid' => [
                            'title' => __( 'Four Columns', 'codexse' ),
                            'icon' => 'icon-grid-4',
                        ],
                    ],
                    'default' => '3grid',
                    'toggle' => true,
                    'condition' => [
                        'slider_on!' => 'yes',
                    ]
                ]
            );
        
            $this->add_control(
                'grid_space',
                [
                    'label' => esc_html__( 'Grid Space', 'codexse' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'g-4',
                    'options' => [
                        'g-1'  => __( 'One', 'codexse' ),
                        'g-2'  => __( 'Two', 'codexse' ),
                        'g-3'  => __( 'Three', 'codexse' ),
                        'g-4'  => __( 'Four', 'codexse' ),
                        'g-5'  => __( 'Five', 'codexse' ),
                    ],
                    'condition' => [
                        'slider_on!' => 'yes',
                    ]
                ]
            );

            $this->add_control(
                'masonry',
                [
                    'label'         => __( 'Masonry', 'codexse' ),
                    'type'          => Controls_Manager::SWITCHER,
                    'label_on'      => __( 'On', 'codexse' ),
                    'label_off'     => __( 'Off', 'codexse' ),
                    'return_value'  => 'yes',
                    'default'       => 'no',
                    'condition' => [
                        'slider_on!' => 'yes',
                    ]
                ]
            );
        
            $this->add_control(
                'post_categories',
                [
                    'label' => esc_html__( 'Categories', 'codexse' ),
                    'type' => Controls_Manager::SELECT2,
                    'label_block' => true,
                    'multiple' => true,
                    'options' => codexse_get_taxonomies('category'),
                ]
            );
            $this->add_control(
                'title_list',
                [
                    'label' => esc_html__( 'Title', 'codexse' ),
                    'type' => Controls_Manager::SELECT2,
                    'multiple' => true,
                    'options' => codexse_get_title('project'),
                    'separator'=>'before',
                ]
            );
            $this->add_control(
                'post_limit',
                [
                    'label' => __('Limit', 'codexse'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 10,
                    'separator'=>'before',
                ]
            );

            $this->add_control(
                'custom_order',
                [
                    'label' => esc_html__( 'Custom order', 'codexse' ),
                    'type' => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );

            $this->add_control(
                'postorder',
                [
                    'label' => esc_html__( 'Order', 'codexse' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'DESC',
                    'options' => [
                        'DESC'  => esc_html__('Descending','codexse'),
                        'ASC'   => esc_html__('Ascending','codexse'),
                    ],
                    'condition' => [
                        'custom_order!' => 'yes',
                    ]
                ]
            );

            $this->add_control(
                'orderby',
                [
                    'label' => esc_html__( 'Orderby', 'codexse' ),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'none',
                    'options' => [
                        'none'          => esc_html__('None','codexse'),
                        'ID'            => esc_html__('ID','codexse'),
                        'date'          => esc_html__('Date','codexse'),
                        'name'          => esc_html__('Name','codexse'),
                        'title'         => esc_html__('Title','codexse'),
                        'comment_count' => esc_html__('Comment count','codexse'),
                        'rand'          => esc_html__('Random','codexse'),
                    ],
                    'condition' => [
                        'custom_order' => 'yes',
                    ]
                ]
            );

            $this->add_control(
                'show_thumb',
                [
                    'label' => esc_html__( 'Thumbnail', 'codexse' ),
                    'type' => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );   
            $this->add_control(
                'thumbnail_size',
                [
                    'label' => esc_html__( 'Image Size', 'codexse' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'thumbnail' => esc_html__('Thumbnail','codexse'),
                        'medium' => esc_html__('Medium','codexse'),
                        'large' => esc_html__('Large','codexse'),
                        'full' => esc_html__('Full','codexse'),
                    ],
                    'default' => 'large',
                    'condition' => [
                        'show_thumb' => 'yes',
                    ]
                ]
            );
             $this->add_control(
                'show_title',
                [
                    'label' => esc_html__( 'Title', 'codexse' ),
                    'type' => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );

            $this->add_control(
                'title_length',
                [
                    'label' => __( 'Title Length', 'codexse' ),
                    'type' => Controls_Manager::NUMBER,
                    'step' => 1,
                    'default' => 5,
                    'condition'=>[
                        'show_title'=>'yes',
                    ]
                ]
            );
            $this->add_control(
                'title_line',
                [
                    'label' => __( 'Title Column', 'codexse' ),
                    'type' => Controls_Manager::NUMBER,
                    'step' => 1,
                    'selectors' => [
                        '{{WRAPPER}} .post-box .title a' => '-webkit-line-clamp: {{VALUE}};line-clamp: {{VALUE}};',
                    ],
                    'condition'=>[
                        'show_title' => 'yes',
                    ]
                ]
            );

            $this->add_control(
                'show_content',
                [
                    'label' => esc_html__( 'Description', 'codexse' ),
                    'type' => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );

            $this->add_control(
                'content_length',
                [
                    'label' => __( 'Description Length', 'codexse' ),
                    'type' => Controls_Manager::NUMBER,
                    'step' => 1,
                    'default' => 50,
                    'condition'=>[
                        'show_content'=>'yes',
                    ]
                ]
            );

            $this->add_control(
                'show_button',
                [
                    'label' => esc_html__( 'Show Button', 'codexse' ),
                    'type' => Controls_Manager::SWITCHER,
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );

            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Button Text', 'codexse' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __( 'Read More', 'codexse' ),
                    'placeholder' => __( 'Read More', 'codexse' ),
                    'label_block'=>true,
                    'condition'=>[
                        'show_button'=>'yes',
                    ]
                ]
            );

            $this->add_control(
                'button_icon_type',
                [
                    'label' => __('Button Icon','codexse'),
                    'type' =>Controls_Manager::CHOOSE,
                    'options' =>[
                        'img' =>[
                            'title' =>__('Image','codexse'),
                            'icon' =>'eicon-image-bold',
                        ],
                        'icon' =>[
                            'title' =>__('Icon','codexse'),
                            'icon' =>'eicon-icon-box',
                        ],
                        'none' =>[
                            'title' =>__('None','codexse'),
                            'icon' =>'eicon-warning',
                        ],
                    ],
                    'default' => 'none',
                ]
            );

            $this->add_control(
                'button_img',
                [
                    'label' => __('Image','codexse'),
                    'type'=>Controls_Manager::MEDIA,
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                    'condition' => [
                        'button_icon_type' => 'img',
                    ]
                ]
            );

            $this->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name' => 'button_img_size',
                    'default' => 'large',
                    'separator' => 'none',
                    'condition' => [
                        'button_icon_type' => 'img',
                    ]
                ]
            );

            $this->add_control(
                'button_icon',
                [
                    'label'       => __( 'Icon', 'codexse' ),
                    'type'        => Controls_Manager::ICONS,
                    'label_block' => true,
                    'condition' => [
                        'button_icon_type' => 'icon',
                    ]
                ]
            );
        
            $this->add_responsive_control(
                'area_width',
                [
                    'label' => __( 'Width', 'codexse' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%', 'vw', 'vh', 'em' ],                                                                                               
                    'condition'=>[                                                                                                                                      
                        'slider_on'=>'yes',                                                                                                                             
                    ],       
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .swiper-wrapper' => 'width: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );  

            $this->add_responsive_control(
                'area_height',
                [
                    'label' => __( 'Height', 'codexse' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%', 'vw', 'vh', 'em' ],                                                                                               
                    'condition'=>[                                                                                                                                      
                        'slider_on'=>'yes',                                                                                                                             
                    ],       
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .swiper-wrapper' => 'height: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            
                                                                                                                                                                   
            $this->add_control(                                                                                                                                     
                'lax_scroll_active',                                                                                                                                    
                [                                                                                                                                                   
                    'label' => esc_html__( 'Lax Scroll', 'codexse' ),                                                                                                    
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
             
        $this->end_controls_section(); 
                                                                                                                                                               
        $this->start_controls_section(                                                                                                                              
            'slider_option',                                                                                                                                        
            [                                                                                                                                                       
                'label' => esc_html__( 'Slider Option', 'codexse' ),                                                                                                
                'condition'=>[                                                                                                                                      
                    'slider_on'=>'yes',                                                                                                                             
                ]                                                                                                                                                   
            ]                                                                                                                                                       
        );                                                                                                                                                          
            $this->add_control(                                                                                                                                     
                'sl_navigation',                                                                                                                                    
                [                                                                                                                                                   
                    'label' => esc_html__( 'Arrow', 'codexse' ),                                                                                                    
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slider_custom_arrow',                                                                                                                              
                [                                                                                                                                                   
                    'label' => esc_html__( 'Custom Arrow', 'codexse' ),                                                                                             
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                 'slider_target_id',                                                                                                                                
                 [                                                                                                                                                  
                     'label'     => __( 'Arrows ID', 'codexse' ),                                                                                                   
                     'type'      => Controls_Manager::TEXT,                                                                                                         
                     'title' => __( 'Take arrow id from "Custom Navigation" addons and paste here!', 'codexse' ),                                                   
                     'condition' => [                                                                                                                               
                        'slider_custom_arrow' => 'yes',                                                                                                            
                        'sl_navigation'=>'yes',                                                                                                                     
                     ]                                                                                                                                              
                 ]                                                                                                                                                  
             );                                                                                                                                                     
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sl_nav_prev_icon',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Previus Icon', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::ICON,                                                                                                               
                    'default' => 'fa fa-angle-left',                                                                                                                
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                        'slider_custom_arrow!'=>'yes',                                                                                                              
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sl_nav_next_icon',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Next Arrow', 'codexse' ),                                                                                                       
                    'type' => Controls_Manager::ICON,                                                                                                               
                    'default' => 'fa fa-angle-right',                                                                                                               
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                        'slider_custom_arrow!'=>'yes',                                                                                                              
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slpaginate',                                                                                                                                       
                [                                                                                                                                                   
                    'label' => esc_html__( 'Paginate', 'codexse' ),                                                                                                 
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sleffect',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Effect', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'slide',                                                                                                                           
                    'options' => [                                                                                                                                  
                        'slide'  => __( 'Slide', 'codexse' ),                                                                                                       
                        'fade'  => __( 'Fade', 'codexse' ),                                                                                                         
                        'cube'  => __( 'Cube', 'codexse' ),                                                                                                         
                        'coverflow'  => __( 'Coverflow', 'codexse' ),                                                                                               
                        'flip'  => __( 'Flip', 'codexse' ),                                                                                                         
                    ],                                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                     
            $this->add_control(                                                                                                                                     
                'sldirection',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Direction', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'horizontal',                                                                                                                           
                    'options' => [                                                                                                                                  
                        'horizontal'  => __( 'Horizontal', 'codexse' ),                                                                                                       
                        'vertical'  => __( 'Vertical', 'codexse' ),                                                                                                
                    ],                                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slloop',                                                                                                                                           
                [                                                                                                                                                   
                    'label' => esc_html__( 'Loop', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
            $this->add_control(                                                                                                                                     
                'slautolay',                                                                                                                                        
                [                                                                                                                                                   
                    'label' => esc_html__( 'Autoplay', 'codexse' ),                                                                                                 
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slautolaydelay',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Autoplay Delay', 'codexse'),                                                                                                     
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 6500,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slcenter',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Center', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sldisplay_columns',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 3,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slcenter_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slanimation_speed',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Slide Speed', 'codexse'),                                                                                                        
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 1000,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_laptop',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Laptop', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Laptop Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to laptop.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 1200,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 3,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_tablet',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Tablet', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Tablet Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to tablet.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 992,                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 2,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 768,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_mobile',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Mobile Phone', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Mobile Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to mobile.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 768,                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 4,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 1,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
        $this->end_controls_section();
    }                                                                                                                                                               
                                                                                                                                                                    
 
    protected function render($instance = []) {
        $settings = $this->get_settings_for_display();
        $args = [
            'post_type' => 'project',
            'post_status' => 'publish',
            'post__in' => $settings['title_list'],
            'ignore_sticky_posts' => 1,
            'posts_per_page' => !empty($settings['post_limit']) ? $settings['post_limit'] : 3,
            'order' => $this->get_settings_for_display('postorder'),
            'orderby' => $this->get_settings_for_display('custom_order') === 'yes' ? $this->get_settings_for_display('orderby') : '',
            'tax_query' => [],
        ];
        $post_cats = str_replace(' ', '', !empty($settings['post_categories']) ? $settings['post_categories'] : '');
        if (!empty($post_cats)) {
            $field_name = is_numeric($post_cats[0]) ? 'term_id' : 'slug';
            $args['tax_query'][] = [
                'taxonomy' => 'category',
                'terms' => $post_cats,
                'field' => $field_name,
                'include_children' => false,
            ];
        }
        $post = new \WP_Query($args);
    
        if ($settings['lax_scroll_active'] === 'yes') {
            $this->add_render_attribute('wrapper_attributes', 'data-lax-preset', 'blurIn fadeIn zoomIn');
            $this->add_render_attribute('wrapper_attributes', 'class', 'lax');
        }
    
        if ($settings['slider_on'] === 'yes') {
            $this->add_render_attribute('wrapper_attributes', 'class', 'swiper-container');
            $slider_settings = [
                'sleffect' => $settings['sleffect'],
                'sldirection' => $settings['sldirection'],
                'slloop' => $settings['slloop'] === 'yes',
                'slautolay' => $settings['slautolay'] === 'yes',
                'slautolaydelay' => absint($settings['slautolaydelay']),
                'slanimation_speed' => absint($settings['slanimation_speed']),
                'slcustom_arrow' => $settings['slider_custom_arrow'] === 'yes',
                'sltarget_id' => $settings['slider_target_id'],
                'sldisplay_columns' => $settings['sldisplay_columns'],
                'slcenter' => $settings['slcenter'] === 'yes',
                'slcenter_padding' => $settings['slcenter_padding'],
            ];
            $slider_responsive_settings = array_intersect_key($settings, array_flip(['sllaptop_width', 'sllaptop_padding', 'sllaptop_display_columns', 'sltablet_width', 'sltablet_padding', 'sltablet_display_columns', 'slmobile_width', 'slmobile_padding', 'slmobile_display_columns']));
            $slider_settings = array_merge($slider_settings, $slider_responsive_settings);
            $this->add_render_attribute('wrapper_attributes', 'data-settings', wp_json_encode($slider_settings));
        } else {
            $this->add_render_attribute('wrapper_attributes', 'class', ['row g-3 g-md-4', esc_attr($settings['grid_space'])]);
            if ($settings['masonry'] === 'yes') {
                $this->add_render_attribute('wrapper_attributes', 'class', 'masonrys');
            }
            switch ($settings['item_column']) {
                case '1grid':
                    $column = 'col-lg-12';
                    break;
                case '2grid':
                    $column = 'col-lg-6 col-md-12';
                    break;
                case '3grid':
                    $column = 'col-4';
                    break;
                default:
                    $column = 'col-xl-3 col-lg-4 col-md-6';
            }
        }
    
        if ($post->have_posts()) {
            echo '<div ' . $this->get_render_attribute_string("wrapper_attributes") . ' >';
            if ($settings['slider_on'] === 'yes') {
                echo '<div class="swiper-wrapper">';
                while ($post->have_posts()) {
                    $post->the_post();
                    echo '<div class="swiper-slide">';
                    echo $this->project__content();
                    echo '</div>';
                }
                wp_reset_postdata();
                echo '</div>';
                if ($settings['sl_navigation'] && $settings['slider_custom_arrow'] !== 'yes') {
                    echo '<div class="swiper-navigation" >';
                    echo '<div class="swiper-arrow swiper-prev"><i class="' . esc_attr($settings['sl_nav_prev_icon']) . '" ></i></div>';
                    echo '<div class="swiper-arrow swiper-next"><i class="' . esc_attr($settings['sl_nav_next_icon']) . '" ></i></div>';
                    echo '</div>';
                }
                if ($settings['slpaginate']) {
                    echo '<div class="swiper-pagination"></div>';
                }
            } else {
                while ($post->have_posts()) {
                    $post->the_post();
                    echo '<div class="' . $column . '">';
                    echo $this->project__content();
                    echo '</div>';
                }
            }
            echo '</div>';
        } else {
            get_template_part('components/post-formats/post', 'none');
        }
    }

    
    public function project__content(){
        $output .= '<div class="project__item">';
            if (has_post_thumbnail()) {
                $output .= '<div class="project__thumbnail">';
                $output .= get_the_post_thumbnail(get_the_ID(), 'large');
                $output .= '</div>';
            }
            $output .= '<h4 class="project__title"><a href="'.get_the_permalink().'">' . get_the_title() . '</a></h4>';
            $output .= '<div class="project__content">';
                $output .= get_the_excerpt();
            $output .= '</div>';
            $output .= '<a href="'.get_the_permalink().'" class="project__button" >'.__('View More','codexse').'</a>';
        $output .= '</div>';

        return $output; // Return the generated HTML
    }                                                                                                                                                          
                                                                                                                                                                    
}