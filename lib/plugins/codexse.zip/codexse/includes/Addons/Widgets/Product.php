<?php
namespace Elementor;

if (!defined("ABSPATH")) {
    exit();
} // Exit if accessed directly
class Codexse_Elementor_Widget_Product extends Widget_Base
{
    public function get_name()
    {
        return "codexse-product-addons";
    }

    public function get_title()
    {
        return __("Product", "codexse-addons");
    }

    public function get_icon()
    {
        return "codexse-icon eicon-products";
    }

    public function get_categories()
    {
        return ["codexse-addons"];
    }

    public function get_style_depends()
    {
        return ["swiper", "codexse-carousel", "codexse-grid", "codexse-product"];
    }

    public function get_script_depends()
    {
        return ["swiper", "codexse-carousel"];
    }

    public function get_keywords() {
        return [ 'codexse', 'product', 'shop', 'woocommerce', 'WordPress Elementor WooCommerce plugin', 'Product carousel for Elementor', 'WooCommerce product grid', 'Elementor WooCommerce integration', 'Custom product widget for Elementor', 'Elementor product showcase', 'WooCommerce Elementor templates', 'Elementor product slider', 'Best Elementor WooCommerce widgets', 'Elementor WooCommerce builder' ];
    }

    protected function register_controls()
    {
        $this->start_controls_section("product_content", [
            "label" => __("Product Settings", "codexse-addons"),
        ]);

        $this->add_control("product_categories", [
            "label" => esc_html__("Product Categories", "codexse"),
            "type" => Controls_Manager::SELECT2,
            "label_block" => true,
            "multiple" => true,
            "options" => codexse_get_taxonomies("product_cat"),
        ]);

        $this->add_control("product_limit", [
            "label" => __("Limit", "codexse"),
            "type" => Controls_Manager::NUMBER,
            "default" => 5,
            "separator" => "before",
        ]);

        $this->add_control("custom_order", [
            "label" => esc_html__("Custom order", "codexse"),
            "type" => Controls_Manager::SWITCHER,
            "return_value" => "yes",
            "default" => "no",
        ]);
        $this->add_control("product_order", [
            "label" => esc_html__("Order", "codexse"),
            "type" => Controls_Manager::SELECT,
            "default" => "DESC",
            "options" => [
                "DESC" => esc_html__("Descending", "codexse"),
                "ASC" => esc_html__("Ascending", "codexse"),
            ],
            "condition" => ["custom_order!" => "yes"],
        ]);
        $this->add_control("orderby", [
            "label" => esc_html__("Orderby", "codexse"),
            "type" => Controls_Manager::SELECT,
            "default" => "none",
            "options" => [
                "none" => esc_html__("None", "codexse"),
                "ID" => esc_html__("ID", "codexse"),
                "date" => esc_html__("Date", "codexse"),
                "name" => esc_html__("Name", "codexse"),
                "title" => esc_html__("Title", "codexse"),
                "comment_count" => esc_html__("Comment count", "codexse"),
                "rand" => esc_html__("Random", "codexse"),
            ],
            "condition" => ["custom_order" => "yes"],
        ]);

        $this->add_control("slider_on", [
            "label" => __("Slider", "codexse-addons"),
            "type" => Controls_Manager::SWITCHER,
            "label_on" => __("On", "codexse-addons"),
            "label_off" => __("Off", "codexse-addons"),
            "return_value" => "yes",
            "default" => "yes",
            "separator" => "after",
        ]);

        $this->add_control("item_column", [
            "label" => __("Column", "codexse"),
            "type" => Controls_Manager::CHOOSE,
            "options" => [
                "1grid" => [
                    "title" => __("One Column", "codexse"),
                    "icon" => "icon-grid-1",
                ],
                "2grid" => [
                    "title" => __("Two Columns", "codexse"),
                    "icon" => "icon-grid-2",
                ],
                "3grid" => [
                    "title" => __("Three Columns", "codexse"),
                    "icon" => "icon-grid-3",
                ],
                "4grid" => [
                    "title" => __("Four Columns", "codexse"),
                    "icon" => "icon-grid-4",
                ],
            ],
            "default" => "3grid",
            "toggle" => true,
            "condition" => ["slider_on!" => "yes"],
        ]);

        $this->add_control("grid_space", [
            "label" => esc_html__("Grid Space", "codexse"),
            "type" => Controls_Manager::SELECT,
            "default" => "g-4",
            "options" => [
                "g-1" => __("One", "codexse"),
                "g-2" => __("Two", "codexse"),
                "g-3" => __("Three", "codexse"),
                "g-4" => __("Four", "codexse"),
                "g-5" => __("Five", "codexse"),
            ],
            "condition" => ["slider_on!" => "yes"],
        ]);

        $this->add_control("masonry", [
            "label" => __("Masonry", "codexse"),
            "type" => Controls_Manager::SWITCHER,
            "label_on" => __("On", "codexse"),
            "label_off" => __("Off", "codexse"),
            "return_value" => "yes",
            "default" => "no",
            "condition" => ["slider_on!" => "yes"],
        ]);

        $this->end_controls_section();
                                                                                                                                           
        $this->start_controls_section(                                                                                                                              
            'slider_option',                                                                                                                                        
            [                                                                                                                                                       
                'label' => esc_html__( 'Slider Option', 'codexse' ),                                                                                                
                'condition'=>[                                                                                                                                      
                    'slider_on'=>'yes',                                                                                                                             
                ]                                                                                                                                                   
            ]                                                                                                                                                       
        );                                                                                                                                                          
            $this->add_control(                                                                                                                                     
                'sl_navigation',                                                                                                                                    
                [                                                                                                                                                   
                    'label' => esc_html__( 'Arrow', 'codexse' ),                                                                                                    
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slider_custom_arrow',                                                                                                                              
                [                                                                                                                                                   
                    'label' => esc_html__( 'Custom Arrow', 'codexse' ),                                                                                             
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                 'slider_target_id',                                                                                                                                
                 [                                                                                                                                                  
                     'label'     => __( 'Arrows ID', 'codexse' ),                                                                                                   
                     'type'      => Controls_Manager::TEXT,                                                                                                         
                     'title' => __( 'Take arrow id from "Custom Navigation" addons and paste here!', 'codexse' ),                                                   
                     'condition' => [                                                                                                                               
                        'slider_custom_arrow' => 'yes',                                                                                                            
                        'sl_navigation'=>'yes',                                                                                                                     
                     ]                                                                                                                                              
                 ]                                                                                                                                                  
             );                                                                                                                                                     
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sl_nav_prev_icon',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Previus Icon', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::ICON,                                                                                                               
                    'default' => 'fa fa-angle-left',                                                                                                                
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                        'slider_custom_arrow!'=>'yes',                                                                                                              
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sl_nav_next_icon',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Next Arrow', 'codexse' ),                                                                                                       
                    'type' => Controls_Manager::ICON,                                                                                                               
                    'default' => 'fa fa-angle-right',                                                                                                               
                    'condition'=>[                                                                                                                                  
                        'sl_navigation'=>'yes',                                                                                                                     
                        'slider_custom_arrow!'=>'yes',                                                                                                              
                    ]                                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slpaginate',                                                                                                                                       
                [                                                                                                                                                   
                    'label' => esc_html__( 'Paginate', 'codexse' ),                                                                                                 
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sleffect',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Effect', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'slide',                                                                                                                           
                    'options' => [                                                                                                                                  
                        'slide'  => __( 'Slide', 'codexse' ),                                                                                                       
                        'fade'  => __( 'Fade', 'codexse' ),                                                                                                         
                        'cube'  => __( 'Cube', 'codexse' ),                                                                                                         
                        'coverflow'  => __( 'Coverflow', 'codexse' ),                                                                                               
                        'flip'  => __( 'Flip', 'codexse' ),                                                                                                         
                    ],                                                                                                                                              
                ]                                                                                                                                                   
            );   

            $this->add_control(                                                                                                                                     
                'coverflow_option_heading',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Coverflow Options', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'before',   
                    'condition' => [
                        'sleffect' => 'coverflow',
                    ]                                                                                                                      
                ]                                                                                                                                                   
            );            
                                                                                                                                                                                
            $this->add_control(                                                                                                                                     
                'coverflow_rotate',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Rotate', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 360,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 0,      
                    'condition' => [
                        'sleffect' => 'coverflow',
                    ]                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                                                   
            $this->add_control(                                                                                                                                     
                'coverflow_stretch',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Stretch', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 9999,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 0,      
                    'condition' => [
                        'sleffect' => 'coverflow',
                    ]                                                                                                                                 
                ]                                                                                                                                                   
            );              
                                                                                                                                                                     
            $this->add_control(                                                                                                                                     
                'coverflow_depth',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Depth', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 9999,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 0,      
                    'condition' => [
                        'sleffect' => 'coverflow',
                    ],                                                                                                                                          
                ]                                                                                                                                                   
            );                                                                                                                                                                  
            $this->add_control(                                                                                                                                     
                'coverflow_shadow',                                                                                                                                           
                [                                                                                                                                                   
                    'label' => esc_html__( 'Shadow', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                   
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slloop',                                                                                                                                           
                [                                                                                                                                                   
                    'label' => esc_html__( 'Loop', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );  

            $this->add_control(                                                                                                                                     
                'slautolay',                                                                                                                                        
                [                                                                                                                                                   
                    'label' => esc_html__( 'Autoplay', 'codexse' ),                                                                                                 
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'yes',                                                                                                                             
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slautolaydelay',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Autoplay Delay', 'codexse'),                                                                                                     
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 6500,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slcenter',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Center', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SWITCHER,                                                                                                           
                    'return_value' => 'yes',                                                                                                                        
                    'default' => 'no',                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sldisplay_columns',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 1,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slcenter_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slanimation_speed',                                                                                                                                
                [                                                                                                                                                   
                    'label' => __('Slide Speed', 'codexse'),                                                                                                        
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 1000,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                   
            $this->add_control(                                                                                                                                     
                'sldirection',                                                                                                                                         
                [                                                                                                                                                   
                    'label' => esc_html__( 'Direction', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::SELECT,                                                                                                             
                    'default' => 'horizontal',                                                                                                                           
                    'options' => [                                                                                                                                  
                        'horizontal'  => __( 'horizontal', 'codexse' ),                                                                                                       
                        'vertical'  => __( 'vertical', 'codexse' ),                                                                                                       
                    ],                                                                                                                                              
                ]                                                                                                                                                   
            );        
        
            $this->add_responsive_control(
                'slider_height',
                [
                    'label' => __( 'Height', 'codexse' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%', 'vh', 'vw' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                        'vh' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                        'vw' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .swiper-container' => 'height: {{SIZE}}{{UNIT}};',
                    ],
                    'condition' => [
                        'sldirection' => 'vertical',
                    ]
                ]
            );                                                                                                                                                  
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_laptop',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Laptop', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Laptop Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to laptop.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 1200,                                                                                                                              
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 3,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sllaptop_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_tablet',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Tablet', 'codexse' ),                                                                                                           
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Tablet Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to tablet.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 992,                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 8,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 2,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'sltablet_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 768,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'heading_mobile',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __( 'Mobile Phone', 'codexse' ),                                                                                                     
                    'type' => Controls_Manager::HEADING,                                                                                                            
                    'separator' => 'after',                                                                                                                         
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_width',                                                                                                                                   
                [                                                                                                                                                   
                    'label' => __('Mobile Resolution', 'codexse'),                                                                                                  
                    'description' => __('The resolution to mobile.', 'codexse'),                                                                                    
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'default' => 768,                                                                                                                               
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_display_columns',                                                                                                                         
                [                                                                                                                                                   
                    'label' => __('Slider Items', 'codexse'),                                                                                                       
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 1,                                                                                                                                     
                    'max' => 4,                                                                                                                                     
                    'step' => 1,                                                                                                                                    
                    'default' => 1,                                                                                                                                 
                ]                                                                                                                                                   
            );                                                                                                                                                      
                                                                                                                                                                    
            $this->add_control(                                                                                                                                     
                'slmobile_padding',                                                                                                                                 
                [                                                                                                                                                   
                    'label' => __( 'Center padding', 'codexse' ),                                                                                                   
                    'type' => Controls_Manager::NUMBER,                                                                                                             
                    'min' => 0,                                                                                                                                     
                    'max' => 500,                                                                                                                                   
                    'step' => 1,                                                                                                                                    
                    'default' => 30,                                                                                                                                
                ]                                                                                                                                                   
            );                                                                                                                                                      
        $this->end_controls_section();                                                                                                                              
                                                                                                                                                                    

    }

    protected function render($instance = [])
    {
        $column = "col-lg-4 col-md-6";
        $settings = $this->get_settings_for_display();
        $custom_order_ck = $this->get_settings_for_display("custom_order");
        $orderby = $this->get_settings_for_display("orderby");
        $product_order = $this->get_settings_for_display("product_order");

        // Carousel Attribute
        $this->add_render_attribute(
            "wrapper_attributes",
            "class",
            "codexse-custom-carousel woocommerce"
        );
        if ($settings["slider_on"] == "yes") {                                                                                                                  
            $this->add_render_attribute( 'wrapper_attributes', 'class', 'swiper-container' );                                                                       
            $slider_settings = [                                                                                                                                    
                'sleffect' => $settings['sleffect'],                                                                                                                
                'sldirection' => $settings['sldirection'],                                                                                                                
                'slloop' => ('yes' === $settings['slloop']),                                                                                               
                'slpaginate' => ('yes' === $settings['slpaginate']),                                                                                                               
                'slautolay' => ('yes' === $settings['slautolay']),                                                                                                  
                'slautolaydelay' => absint($settings['slautolaydelay']), 
                'slanimation_speed' => absint($settings['slanimation_speed']),   
                'coverflow_rotate' => absint($settings['coverflow_rotate']),    
                'coverflow_stretch' => absint($settings['coverflow_stretch']),    
                'coverflow_depth' => absint($settings['coverflow_depth']),                                                                                                   
                'coverflow_shadow' => $settings['coverflow_shadow'],              
                'slcustom_arrow' => ('yes' === $settings['slider_custom_arrow']),                                                                                   
                'sltarget_id' => $settings['slider_target_id'],                                                                                                     
                'sldisplay_columns' => $settings['sldisplay_columns'],                                                                                              
                'slcenter' => ('yes' === $settings['slcenter']),                                                                                           
                'slcenter_padding' => $settings['slcenter_padding'],                                                                                                
                'laptop_width' => $settings['sllaptop_width'],                                                                                                      
                'laptop_padding' => $settings['sllaptop_padding'],                                                                                                  
                'laptop_display_columns' => $settings['sllaptop_display_columns'],                                                                                  
                'tablet_width' => $settings['sltablet_width'],                                                                                                      
                'tablet_padding' => $settings['sltablet_padding'],                                                                                                  
                'tablet_display_columns' => $settings['sltablet_display_columns'],                                                                                  
                'mobile_width' => $settings['slmobile_width'],                                                                                                      
                'mobile_padding' => $settings['slmobile_padding'],                                                                                                  
                'mobile_display_columns' => $settings['slmobile_display_columns'],                                                                                  
            ];                                                                                                                                                      
            $this->add_render_attribute( 'wrapper_attributes', 'data-settings', wp_json_encode( $slider_settings ) );  
        } else {
            $this->add_render_attribute("wrapper_attributes", "class", [
                "row",
                esc_attr($settings["grid_space"]),
            ]);
            if ($settings["masonry"] == "yes") {
                $this->add_render_attribute(
                    "wrapper_attributes",
                    "class",
                    "masonry_lists"
                );
            }
            switch ($settings["item_column"]) {
                case "1grid":
                    $column = "col-lg-12";
                    break;
                case "2grid":
                    $column = "col-lg-6 col-md-12";
                    break;
                case "3grid":
                    $column = "col-lg-4 col-md-6";
                    break;
                default:
                    $column = "col-xl-3 col-lg-4 col-md-6";
            }
        }

        // Query
        $args = [
            "post_type" => "product",
            "post_status" => "publish",
            "ignore_sticky_posts" => 1,
            "posts_per_page" => !empty($settings["product_limit"])
                ? $settings["product_limit"]
                : 3,
            "order" => $product_order,
        ];

        // Custom Order
        if ($custom_order_ck == "yes") {
            $args["orderby"] = $orderby;
        }
        $product_cats = $settings["product_categories"];

        $product_cats = str_replace(" ", "", $product_cats);
        if (!empty($product_cats)) {
            if (is_array($product_cats) and count($product_cats) > 0) {
                $field_name = is_numeric($product_cats[0]) ? "term_id" : "slug";
                $args["tax_query"] = [
                    [
                        "taxonomy" => "product_cat",
                        "terms" => $product_cats,
                        "field" => $field_name,
                        "include_children" => false,
                    ],
                ];
            }
        }
        $product_query = new \WP_Query($args);

        if ($product_query->have_posts()):
            echo "<div ".$this->get_render_attribute_string("wrapper_attributes")." >";
            if ($settings["slider_on"] == "yes") {
                echo '<div class="swiper-wrapper">';
                while ($product_query->have_posts()):
                    $product_query->the_post();
                    echo '<div class="swiper-slide">';
                        $this->post__content();
                    echo "</div>";
                endwhile;
                echo "</div>";
                if (
                    $settings["sl_navigation"] == 'yes' &&
                    $settings["slider_custom_arrow"] != 'yes'
                ) {
                    echo '<div class="swiper-navigation" >';
                    echo '<div class="swiper-arrow swiper-prev"><i class="' .
                        esc_attr($settings["sl_nav_prev_icon"]) .
                        '" ></i></div>';
                    echo '<div class="swiper-arrow swiper-next"><i class="' .
                        esc_attr($settings["sl_nav_next_icon"]) .
                        '" ></i></div>';
                    echo "</div>";
                }
                if ($settings["slpaginate"] == 'yes') {
                    echo '<div class="swiper-pagination"></div>';
                }
            } else {
                while ($product_query->have_posts()):
                    $product_query->the_post();
                    echo '<div class="' . $column . '">';
                        $this->post__content();
                    echo "</div>";
                endwhile;
            }
            echo "</div>";
            wp_reset_query();
        else:
            esc_html_e("Products empty.", "codexse");
        endif;
    }

    protected function post__content() {
        ob_start(); // Start output buffering
        ?>
            <div class="product__item">
                <?php
                /**
                 * Hook: woocommerce_before_shop_loop_item.
                 *
                 * @hooked woocommerce_template_loop_product_link_open - 10
                 */
                do_action( 'woocommerce_before_shop_loop_item' );

                echo '<figure class="product__thumb">';
                /**
                 * Hook: woocommerce_before_shop_loop_item_title.
                 *
                 * @hooked woocommerce_show_product_loop_sale_flash - 10
                 * @hooked woocommerce_template_loop_product_thumbnail - 10
                 */
                do_action( 'woocommerce_before_shop_loop_item_title' );
                echo '</figure>';

                echo '<div class="product__content">';
                    /**
                     * Hook: woocommerce_shop_loop_item_title.
                     *
                     * @hooked woocommerce_template_loop_product_title - 10
                     */
                    do_action( 'woocommerce_shop_loop_item_title' );


                    echo '<div class="rating__price">';
                        /**
                         * Hook: woocommerce_after_shop_loop_item_title.
                         *
                         * @hooked woocommerce_template_loop_rating - 5
                         * @hooked woocommerce_template_loop_price - 10
                         */
                        do_action( 'woocommerce_after_shop_loop_item_title' );
                    echo '</div>';
                echo '</div>';
                    /**
                     * Hook: woocommerce_after_shop_loop_item.
                     *
                     * @hooked woocommerce_template_loop_product_link_close - 5
                     * @hooked woocommerce_template_loop_add_to_cart - 10
                     */
                    do_action( 'woocommerce_after_shop_loop_item' );
                ?>
            </div>
        <?php
        $output = ob_get_clean(); // Get the buffered content and clean the buffer
        echo $output; // Return the buffered content
    }
}