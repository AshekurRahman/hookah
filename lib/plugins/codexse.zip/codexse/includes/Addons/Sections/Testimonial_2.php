<?php                                                                                                                                                               
namespace Elementor;                                                                                                                                                
                                                                                                                                                                    
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly                                                                                                    
                                                                                                                                                                    
class Codexse_Elementor_Widget_Testimonial_2 extends Widget_Base {                                                                                                       
                                                                                                                                                                    
    public function get_name() {                                                                                                                                    
        return 'codexse-testimonial-section-2';                                                                                                                           
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_title() {                                                                                                                                   
        return __( 'Testimonial 2', 'codexse' );                                                                                                                  
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_icon() {                                                                                                                                    
        return 'codexse-img testimonial_2';                                                                                                                    
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_categories(){
        return ["codexse-section"];
    }                                                                                                                                                             
                                                                                                                                                                    
    public function get_style_depends() {                                                                                                                           
        return [                                                                                                                                                    
            'swiper',                                                                                                                                        
            'codexse-carousel',
            'codexse-testimonial'                                                                                                               
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    public function get_script_depends() {                                                                                                                          
        return [                                                                                                                                                    
            'swiper-slider',                                                                                                                                        
            'codexse-carousel',                                                                                                                                     
        ];                                                                                                                                                          
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function register_controls() {                                                                                                                        
                                                                                                                                                                    
        $this->start_controls_section(                                                                                                                              
            'testimonial_content',                                                                                                                                      
            [                                                                                                                                                       
                'label' => __( 'Testimonial', 'codexse' ),                                                                                                      
            ]                                                                                                                                                       
        );                                                                                                                         
            $this->add_control(                                                                                                                                 
                'section_title',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Section Title', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXT,                                                                                                            
                    'placeholder' => __('Enter type section title.','codexse'),                                                                                        
                    'default' => __('Reviews From Our Customers','codexse'),
                ]                                                                                                                                                   
            );                                                                                                                   
            $this->add_control(                                                                                                                                 
                'section_desc',                                                                                                                              
                [                                                                                                                                                   
                    'label'   => __( 'Section Description', 'codexse' ),                                                                                                   
                    'type'    => Controls_Manager::TEXTAREA,                                                                                                            
                    'placeholder' => __('Enter type section description.','codexse'),                                                                                        
                    'default' => __('It is a long established fact that a reader will be distracted by the readable content.','codexse'),
                ]                                                                                                                                                   
            );      


            $this->add_control(
                'quote_image',
                [
                    'label'  => __( 'Quote Image', 'codexse' ),
                    'type'   => Controls_Manager::MEDIA,
                    'default' => [
                        'url' => CODEXSE_ASSETS . '/images/ts2-quote.png',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name'      => 'quote_image_size',
                    'default'   => 'large',
                    'separator' => 'after',
                ]
            );                                                                                                                             
                                                                                                                                                                    
            $repeater = new Repeater();

            $repeater->add_control(
                'testimonial_description',
                [
                    'label'       => __( 'Feedback', 'codexse' ),
                    'type'        => Controls_Manager::TEXTAREA,
                    'placeholder' => __( 'Enter your client feedback message.', 'codexse' ),
                ]
            );

            $repeater->add_control(
                'testimonial_name',
                [
                    'label'       => __( 'Name', 'codexse' ),
                    'type'        => Controls_Manager::TEXT,
                    'placeholder' => __( 'Enter your client name.', 'codexse' ),
                ]
            );

            $repeater->add_control(
                'testimonial_position',
                [
                    'label'      => __( 'Position', 'codexse' ),
                    'type'       => Controls_Manager::TEXT,
                    'placeholder' => __( 'Enter your client position.', 'codexse' ),
                    'separator'  => 'after',
                ]
            );

            $repeater->add_control(
                'testimonial_image',
                [
                    'label'  => __( 'Main Image', 'codexse' ),
                    'type'   => Controls_Manager::MEDIA,
                    'default' => [
                        'url' => CODEXSE_ASSETS . '/images/testimonial2_main_4.png',
                    ],
                ]
            );

            $repeater->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name'      => 'testimonial_image_size',
                    'default'   => 'large',
                    'separator' => 'after',
                ]
            );

            $repeater->add_control(
                'testimonial_thumb_image',
                [
                    'label'  => __( 'Thumbnail Image', 'codexse' ),
                    'type'   => Controls_Manager::MEDIA,
                    'default' => [
                        'url' => CODEXSE_ASSETS . '/images/testimonial2_thum_4.png',
                    ],
                ]
            );

            $repeater->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                    'name'      => 'testimonial_thumb_image_size',
                    'default'   => 'large',
                    'separator' => 'after',
                ]
            );

            $repeater->add_control(
                'thumb_color',
                [
                    'label'     => __('Thumb Background Color', 'codexse'),
                    'type'      => Controls_Manager::COLOR,
                    'default'   => '#49C5EA',
                    'selectors' => [
                        '{{WRAPPER}} .testimonial-navigate-slide {{CURRENT_ITEM}} .thumbnail, {{WRAPPER}} .testimonial-photo-slide {{CURRENT_ITEM}} .thumbnail .bg' => 'background-color: {{VALUE}};',
                    ],
                ]
            );

            $repeater->add_control(
                "rating_switch",
                [
                    "label"      => __("Show rating star", "codexse"),
                    "type"       => Controls_Manager::SWITCHER,
                    "default"    => "no",
                    "label_on"   => __("Show", "codexse"),
                    "label_off"  => __("Hide", "codexse"),
                ]
            );

            $repeater->add_control(
                "rating",
                [
                    "label"      => __("Rating", "codexse"),
                    "type"       => Controls_Manager::SLIDER,
                    "default"    => ["size" => 3],
                    "range"      => ["px" => ["max" => 5, "step" => 0.1]],
                    "condition"  => ["rating_switch" => "yes"],
                ]
            );
                                                                                                                                                  
            $this->add_control(
                'testimonial_list',
                [
                    'type'    => Controls_Manager::REPEATER,
                    'fields'  => $repeater->get_controls(),
                    'default' => [
                        [
                            'testimonial_description' => __('I recently acquired a Landshop watch, and I am compelled to share my overwhelmingly positive experience with this exquisite timepiece. From the moment I first laid eyes on the Landshop watch, I was captivated by its stunning design and meticulous craftsmanship.','codexse'),
                            'testimonial_name'        => __('Helena Paitora','codexse'),
                            'testimonial_position'    => __('Digital Marketer','codexse'),
                            'testimonial_image'	=> [
                                'url' => CODEXSE_ASSETS . '/images/testimonial2_main_1.png',
                            ],
                            'testimonial_thumb_image'	=> [
                                'url' => CODEXSE_ASSETS . '/images/testimonial2_thum_1.png',
                            ],
                            'thumb_color'     => '#E4DFFF',
                        ],
                        [
                            'testimonial_description' => __('I recently acquired a Landshop watch, and I am compelled to share my overwhelmingly positive experience with this exquisite timepiece. From the moment I first laid eyes on the Landshop watch, I was captivated by its stunning design and meticulous craftsmanship.','codexse'),
                            'testimonial_name'        => __('Helena Paitora','codexse'),
                            'testimonial_position'    => __('Digital Marketer','codexse'),
                            'testimonial_image'	=> [
                                'url' => CODEXSE_ASSETS . '/images/testimonial2_main_2.png',
                            ],
                            'testimonial_thumb_image'	=> [
                                'url' => CODEXSE_ASSETS . '/images/testimonial2_thum_2.png',
                            ],
                            'thumb_color'     => '#EDA0A8',
                        ],
                        [
                            'testimonial_description' => __('I recently acquired a Landshop watch, and I am compelled to share my overwhelmingly positive experience with this exquisite timepiece. From the moment I first laid eyes on the Landshop watch, I was captivated by its stunning design and meticulous craftsmanship.','codexse'),
                            'testimonial_name'        => __('Helena Paitora','codexse'),
                            'testimonial_position'    => __('Digital Marketer','codexse'),
                            'testimonial_image'	=> [
                                'url' => CODEXSE_ASSETS . '/images/testimonial2_main_3.png',
                            ],
                            'testimonial_thumb_image'	=> [
                                'url' => CODEXSE_ASSETS . '/images/testimonial2_thum_3.png',
                            ],
                            'thumb_color'     => '#F5CA48',
                        ],
                    ],
                    'title_field' => '{{{ testimonial_name }}}',
                ]
            );
                                                                                                                                                               
                                                                                                                                                               
        $this->end_controls_section(); 
        
                
        $this->start_controls_section(
            'section_title_style',
            [
                'label' => __( 'Section Title', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );        
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'section_title_typo',
                'selector' => '{{WRAPPER}} .testimonial_slider_2 .section-title .title',
            ]
        );
        $this->add_control(
            'section_title_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial_slider_2 .section-title .title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'section_title_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial_slider_2 .section-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'section_title_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial_slider_2 .section-title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        $this->end_controls_section();


                
        $this->start_controls_section(
            'section_desc_style',
            [
                'label' => __( 'Section Title', 'codexse' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );        
        
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'section_desc_typo',
                'selector' => '{{WRAPPER}} .testimonial_slider_2 .section-title .desc',
            ]
        );
        $this->add_control(
            'section_desc_color',
            [
                'label' => __( 'Color', 'codexse' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial_slider_2 .section-title .desc' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'section_desc_margin',
            [
                'label' => __( 'Margin', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial_slider_2 .section-title .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        
        $this->add_responsive_control(
            'section_desc_padding',
            [
                'label' => __( 'Padding', 'codexse' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial_slider_2 .section-title .desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );
        $this->end_controls_section();                                                                                                                              
    }                                                                                                                                                               
                                                                                                                                                                    
    protected function render( $instance = [] ) {                                                                                   
        $settings   = $this->get_settings_for_display(); ?>
        <!-- Testimonial-Area-Start -->
        <section class="testimonial_slider_2">
            <div class="container-fluid elementor-container">
                <div class="row align-items-end g-3 g-lg-4 g-xl-5">
                    <div class="col-lg-4">
                        <?php if(!empty($settings['section_title'])): ?>
                            <div class="section-title">
                                <h2 class="title"><?php echo esc_html($settings['section_title']); ?></h2>
                                <div class="desc"><?php echo wp_kses_post($settings['section_desc']); ?></div>
                            </div>
                        <?php endif; ?>
                        <div class="testimonial-navigate-slide  swiper-container">
                            <div class="swiper-wrapper">
                                <?php foreach( $settings['testimonial_list'] as $item ): ?>
                                    <div class="swiper-slide elementor-repeater-item-<?php echo esc_attr( $item['_id'] ); ?>">
                                        <?php     
                                            if(Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_thumb_image_size', 'testimonial_thumb_image' )){
                                                echo '<div class="thumbnail">';
                                                echo Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_thumb_image_size', 'testimonial_thumb_image' );
                                                echo '</div>';
                                            }
                                        ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 d-none d-lg-block">
                        <div class="testimonial-photo-slide swiper-container">
                            <div class="swiper-wrapper">
                                <?php foreach( $settings['testimonial_list'] as $item ): ?>
                                    <div class="swiper-slide">
                                        <figure class="single-image elementor-repeater-item-<?php echo esc_attr( $item['_id'] ); ?>">
                                            <?php           
                                                if(Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_image_size', 'testimonial_image' )){
                                                    echo '<div class="thumbnail">';
                                                        echo '<span class="bg"></span>';
                                                        echo Group_Control_Image_Size::get_attachment_image_html( $item, 'testimonial_image_size', 'testimonial_image' );
                                                    echo '</div>';
                                                }
                                            ?>
                                        </figure>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="testimonial-content-slide  swiper-container">
                            <div class="swiper-wrapper">
                                <?php foreach( $settings['testimonial_list'] as $item ): ?>
                                    <div class="swiper-slide">
                                        <div class="testimonial-box elementor-repeater-item-<?php echo esc_attr( $item['_id'] ); ?>">
                                            <div class="testimonial-header">
                                                <?php           
                                                    if(Group_Control_Image_Size::get_attachment_image_html( $settings, 'quote_image_size', 'quote_image' )){
                                                        echo '<div class="quote">';
                                                            echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'quote_image_size', 'quote_image' );
                                                        echo '</div>';
                                                    }
                                                ?>
                                                <?php
                                                    if ($item["rating_switch"] == "yes"):
                                                        echo '<div class="feed-rating">';
                                                            echo '<span class="star front"></span>';
                                                            echo '<span class="star back" style="width: '. esc_attr( $item["rating"]["size"] * 20 ) .'%"></span>';
                                                        echo '</div>';
                                                    endif;
                                                ?>
                                            </div>
                                            <div class="testimonial-body">
                                                <?php
                                                    if( !empty($item['testimonial_description']) ){
                                                        echo '<div class="description">';
                                                            echo esc_html($item['testimonial_description']);
                                                        echo '</div>';
                                                    }
                                                ?>
                                                <?php
                                                    echo '<div class="testimonial-info">';
                                                        if( !empty($item['testimonial_name']) ){
                                                        echo '<h3 class="title">'.esc_html($item['testimonial_name']).'</h3>';
                                                        }                      
                                                        if( !empty($item['testimonial_position']) ){
                                                        echo '<div class="position">'.esc_html($item['testimonial_position']).'</div>';
                                                        }
                                                    echo '</div>';
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="slider-controls testimonial-navigation">
                                <button type="button" class="control next"><i class="fa-regular fa-angle-left"></i></button>
                                <button type="button" class="control prev"><i class="fa-regular fa-angle-right"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Testimonial-Area-End -->
        <?php                                                                                                                                                
    }     
    
    
    public function on_add_to_editor() {
        // Override the default behavior when added to the editor
        $this->add_wrapper_attributes();
    }

    protected function add_wrapper_attributes() {
        // You can add wrapper attributes here if needed
    }

    public function get_render_wrapper_attributes() {
        // Return an empty string to prevent the default wrapper
        return '';
    }

    public function get_render_inner_wrapper_attributes() {
        // Return an empty string to prevent the default inner wrapper
        return '';
    }
                                                                                                                                                                    
}                                                                                                                                                                   
                                                                                                                                                                    
