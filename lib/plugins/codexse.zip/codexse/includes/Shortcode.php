<?php

namespace Codexse;

/*
 * Shortcode Handler Class
 */
class Shortcode {

    public function __construct() {
        add_shortcode('project_grid', [ $this, 'display_project_grid_shortcode' ] );
        add_action('wp_enqueue_scripts', [ $this, 'enqueue_scripts' ]);
        add_action('wp_ajax_filter_projects', [ $this, 'filter_projects_callback' ]);
        add_action('wp_ajax_nopriv_filter_projects', [ $this, 'filter_projects_callback' ]);
    }

    public function display_project_grid_shortcode() {
        $args = array(
            'post_type'      => 'project',
            'posts_per_page' => -1, // Display all projects. Change as needed.
            // Add any additional arguments like sorting, filtering, etc.
        );
        $query = new \WP_Query($args);

        if ($query->have_posts()) :

            // Output category filter buttons
            $categories = get_categories(array('taxonomy' => 'category'));
            $output = '<div class="category__filter">';
            $output .= '<button class="category__button active" data-category="all">All</button>';
            foreach ($categories as $category) {
                if($category->slug != 'uncategorized' ){
                    $output .= '<button class="category__button" data-category="' . $category->slug . '">' . $category->name . '</button>';
                }
            }
            $output .= '</div>';

            $output .= '<div class="project__grid row g-4">';
            while ($query->have_posts()) : 
                $query->the_post();
                $output .= $this->project__content(); // Updated here
            endwhile;
            $output .= '</div>';
            wp_reset_postdata();
        else :
            $output = __('No projects found.', 'codexse');
        endif;

        return $output;
    }

    public function project__content(){
        $output = '<div class="col-md-4">'; // Added missing assignment
        $output .= '<div class="project__item">';
        if (has_post_thumbnail()) {
            $output .= '<div class="project__thumbnail">';
            $output .= get_the_post_thumbnail(get_the_ID(), 'large');
            $output .= '</div>';
        }
        $output .= '<h4 class="project__title"><a href="'.get_the_permalink().'">' . get_the_title() . '</a></h4>';
        $output .= '<div class="project__content">';
        $output .= get_the_excerpt();
        $output .= '</div>';
        $output .= '<a href="'.get_the_permalink().'" class="project__button" >'.__('View More','codexse').'</a>';
        $output .= '</div>';
        $output .= '</div>';

        return $output; // Return the generated HTML
    }

    public function enqueue_scripts() {
        wp_enqueue_script('project-grid-ajax', CODEXSE_ASSETS . '/js/project-grid-ajax.js', array('jquery'), null, true);
        wp_localize_script('project-grid-ajax', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
    }

    public function filter_projects_callback() {
        $category = $_POST['category'];

        if ($category != 'all') {
            $args = array(
                'post_type' => 'project',
                'posts_per_page' => -1, // Display all projects. Change as needed.
                'tax_query' => array(
                    array(
                        'taxonomy' => 'category',
                        'field' => 'slug',
                        'terms' => $category
                    )
                )
            );
        } else {
            $args = array(
                'post_type' => 'project',
                'posts_per_page' => -1, // Display all projects. Change as needed.
            );
        }
        

        $query = new \WP_Query($args);
        ob_start();
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                echo $this->project__content(); // Updated here
            }
        } else {
            echo __('No projects found.', 'codexse');
        }
        wp_reset_postdata();
        wp_die();
    }
}
