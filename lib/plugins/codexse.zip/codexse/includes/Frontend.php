<?php

namespace Codexse;

class Frontend
{
    function __construct(){
        if( class_exists('WooCommerce') ){
            require_once ( CODEXSE_PATH . '/includes/Frontend/Wishlist/Wishlist.php' );
            new Frontend\Wishlist\Wishlist();
        }

    }
}
