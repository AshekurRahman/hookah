<?php

namespace Codexse;

class Addons
{
    function __construct(){
        require_once CODEXSE_PATH . '/includes/Addons/IconManager.php';

        add_action( 'elementor/controls/controls_registered', [$this, 'new_fonts_add'], 10, 1 ); 

        // Register custom category
        add_action( 'elementor/elements/categories_registered', [ $this, 'add_category' ], '0' );
        
        // Init Widgets
        if ( codexse_is_elementor_version( '>=', '3.5.0' ) ) {
            add_action( 'elementor/widgets/register', [ $this, 'init_widgets' ] );
        }else{
            add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );
        }        
    }  
 
    // Custom-Font-Family-Add
    public function new_fonts_add($controls_registry){
        // retrieve fonts list from Elementor
        $fonts = $controls_registry->get_control( 'font' )->get_settings( 'options' );
        // add your new custom font
        $new_fonts = array_merge( [ 'NeueMontreal' => 'system' ], $fonts );
        // return the new list of fonts
        $controls_registry->get_control( 'font' )->set_settings( 'options', $new_fonts );
    }

    // Add custom category.
    public function add_category( $elements_manager ) {
        $elements_manager->add_category(
            'codexse-addons',
            [
                'title' => __( 'Codexse Addons', 'codexse' ),
                'icon' => 'eicon-button',
            ]
        );
        $elements_manager->add_category(
            'codexse-section',
            [
                'title' => __( 'Codexse Section', 'codexse' ),
                'icon' => 'eicon-container',
            ]
        );
    }
    
    public function init_widgets(){
        $widget_list = $this->get_widget_list();
        $widgets_manager = \Elementor\Plugin::instance()->widgets_manager;

        foreach($widget_list as $option_key => $option){

            if(strpos($option['title'], ' ') !== false){
                $widget_file_name = str_replace(' ', '_', $option['title']);
                $widget_class = "\Elementor\Codexse_Elementor_Widget_" . str_replace(' ', '_', $option['title']);
            }else{
                $widget_file_name = $option['title'];
                $widget_class = "\Elementor\Codexse_Elementor_Widget_" . $option['title'];
            }
            
            $widget_status = file_exists( CODEXSE_PATH .'/includes/Addons/Widgets/'.$widget_file_name.'.php' ) ? true : false ;
            $section_status = file_exists( CODEXSE_PATH .'/includes/Addons/Sections/'.$widget_file_name.'.php' ) ? true : false ;           

            if ( $widget_status ){
                require_once CODEXSE_PATH . '/includes/Addons/Widgets/'.$widget_file_name.'.php';                
                if ( codexse_is_elementor_version( '>=', '3.5.0' ) ){
                    $widgets_manager->register( new $widget_class() );
                }else{
                    $widgets_manager->register_widget_type( new $widget_class() );
                }                
            }elseif ( $section_status ){
                require_once CODEXSE_PATH . '/includes/Addons/Sections/'.$widget_file_name.'.php';                
                if ( codexse_is_elementor_version( '>=', '3.5.0' ) ){
                    $widgets_manager->register( new $widget_class() );
                }else{
                    $widgets_manager->register_widget_type( new $widget_class() );
                }                
            }
        }  
        if ( file_exists( CODEXSE_PATH . '/includes/Addons/Widgets/flotingeffect.php' ) ) {
            require_once CODEXSE_PATH . '/includes/Addons/Widgets/flotingeffect.php';  
        }     

    }

    private function get_widget_list(){
        $widget_list =[
            'button' =>[
                'title' => __('Button','codexse'),
            ],
            'carousel' =>[
                'title' => __('Carousel','codexse'),
            ],
            'Icon_Box' =>[
                'title' => __('Icon Box','codexse'),
            ],
            'Counter' =>[
                'title' => __('Counter','codexse'),
            ],
            'Lightbox' =>[
                'title' => __('Lightbox','codexse'),
            ],
            'Icon_List' =>[
                'title' => __('Icon List','codexse'),
            ],
            'Testimonial' =>[
                'title' => __('Testimonial','codexse'),
            ],
            'Team' =>[
                'title' => __('Team','codexse'),
            ],
            'Product' =>[
                'title' => __('Product','codexse'),
            ],
            'Accordion' =>[
                'title' => __('Accordion','codexse'),
            ],
            'Shortcode' =>[
                'title' => __('Shortcode','codexse'),
            ],
            'Tabs' =>[
                'title' => __('Tabs','codexse'),
            ],
            'News' =>[
                'title' => __('News','codexse'),
            ],
            'Project' =>[
                'title' => __('Project','codexse'),
            ],
            'Image' =>[
                'title' => __('Image','codexse'),
            ],
            'Navigation' =>[
                'title' => __('Navigation','codexse'),
            ],
            'Pagination' =>[
                'title' => __('Pagination','codexse'),
            ],
        ];
        return apply_filters( 'codexse_widget_list', $widget_list );
    }


}
