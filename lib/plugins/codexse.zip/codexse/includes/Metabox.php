<?php

namespace Codexse;

class Metabox
{
    function __construct(){
        require_once ( CODEXSE_PATH . '/includes/Metabox/ProjectMeta.php' );
        
        if ('project' == codexse_get_current_post_type()) {            
            new Metabox\ProjectMeta();
        }
    }
}
