<?php

namespace Codexse;

class PostType
{
    function __construct(){
       require_once ( CODEXSE_PATH . '/includes/PostType/Project.php' );                  
      	new PostType\Project();
    }
}
