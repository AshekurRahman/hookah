<?php

namespace Codexse;

class Widgets
{
    function __construct(){
        require_once ( CODEXSE_PATH . '/includes/Widgets/PopulerPosts.php' );
        new Widgets\PopulerPosts();

        require_once ( CODEXSE_PATH . '/includes/Widgets/ElementorTemplate.php' );
        new Widgets\ElementorTemplate();
        
        
        add_action('widgets_init', [ $this, 'widgets_init' ] );
    }
    
    public function widgets_init()
    {  
        register_widget( 'Codexse\Widgets\PopulerPosts' );      
        if (is_plugin_active( 'elementor/elementor.php' )) {
            register_widget( 'Codexse\Widgets\ElementorTemplate' );    
        }        
    }
}