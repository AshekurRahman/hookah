<?php

namespace Codexse\PostType;

class Project
{
    public function __construct() {
        add_action( 'init', array( $this, 'codexse_register_project_post_type' ) );
    }
  
    public function codexse_register_project_post_type() {
        $labels = array(
            'name'               => __('Project', 'codexse'),
            'singular_name'      => __('Project', 'codexse'),
            'add_new'            => __('Add New', 'codexse'),
            'add_new_item'       => __('Add New Project Item', 'codexse'),
            'edit_item'          => __('Edit Project Item', 'codexse'),
            'new_item'           => __('New Project Item', 'codexse'),
            'view_item'          => __('View Project Item', 'codexse'),
            'search_items'       => __('Search Project Items', 'codexse'),
            'not_found'          => __('No project items found', 'codexse'),
            'not_found_in_trash' => __('No project items found in trash', 'codexse'),
            'parent_item_colon'  => '',
            'menu_name'          => __('Project', 'codexse')
        );

        $args = array(
            'labels'              => $labels,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'query_var'           => true,
            'rewrite'             => array( 'slug' => 'project' ),
            'capability_type'     => 'post',
            'has_archive'         => true,
            'hierarchical'        => false,
            'menu_position'       => null,
            'supports'            => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'comments', 'revisions' ),
            'taxonomies'          => array( 'category', 'post_tag' )
        );

        register_post_type( 'project', $args );
    }
}