<?php

namespace Codexse\Metabox;

class ProjectMeta {
    public function __construct() {
        add_action('add_meta_boxes', array($this, 'add_project_meta'));
        add_action('save_post', array($this, 'save'));
    }

    public function add_project_meta($post_type) {
        $post_types = array('project');
        if (in_array($post_type, $post_types)) {
            add_meta_box(
                'codexse-project-meta',
                __('Project Information', 'codexse'),
                array($this, 'meta_box_function'),
                $post_type,
                'side',
                'high'
            );
        }
    }

    public function meta_box_function($post) {
        // Add a nonce field so we can check for it later.
        wp_nonce_field('codexse_nonce_check', 'codexse_nonce_check_value');

        // Use get_post_meta to retrieve an existing value from the database.
        $location = get_post_meta($post->ID, '_codexse_location', true);

        // Display the form, using the current value.
        echo '<div class="codexse-meta-items">';
        echo '<div class="codexse-meta-item codexse-location">';
        echo '<p class="post-attributes-label-wrapper">';
        echo '<label class="post-attributes-label" for="codexse_location">'.__('Project Location', 'codexse').'</label>';
        echo '</p>';
        echo '<input type="text" class="form-control" name="codexse_location" id="codexse_location" value="' . esc_attr($location) . '" />';
        echo '</div>';
        echo '</div>';
    }
       
    public function save($post_id) {
        // Check if our nonce is set.
        if (!isset($_POST['codexse_nonce_check_value'])) {
            return $post_id;
        }

        $nonce = $_POST['codexse_nonce_check_value'];

        // Verify that the nonce is valid.
        if (!wp_verify_nonce($nonce, 'codexse_nonce_check')) {
            return $post_id;
        }

        // If this is an autosave, our form has not been submitted,
        // so we don't want to do anything.
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return $post_id;
        }

        // Check the user's permissions.
        $post_type = get_post_type($post_id);
        if ('project' == $post_type) {
            if (!current_user_can('edit_post', $post_id)) {
                return $post_id;
            }
        }

        // Sanitize the user input.
        $location = sanitize_text_field($_POST['codexse_location']);

        // Update the meta field.
        update_post_meta($post_id, '_codexse_location', $location);
    }
}
